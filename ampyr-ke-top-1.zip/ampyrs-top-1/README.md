# AMPYR ke Top 1%

*Think differently. Beat the room.*

A multiplayer game show for about 40 people.

- **Host screen:** your laptop, connected to the TV or projector.
- **Players:** join from their phones or laptops by scanning a QR code or opening a web address. No app to install, no accounts.

This version runs **on the internet**, so players can use mobile data or any Wi-Fi. There's no router or IT firewall to deal with. (It can still run on a local network; see section 9.)

---

## 1. Put it online with Render (one-time, about 20 minutes)

**You need:** a free GitHub account, a Render account, and a payment card. Render's always-on plan costs about **$7 a month (≈ ₹600)** plus **$0.25 a month** for the 1 GB disk that keeps your data. It's charged only while the service exists, so you can delete it after the event.

**Step 1: Put the files on GitHub**
1. Sign in at https://github.com and click **New repository**.
2. Name it `ampyrs-top-1`, choose **Private**, and click **Create repository**.
3. On the new repository page, click **uploading an existing file**.
4. Unzip `ampyrs-top-1.zip` on your laptop and open the `ampyrs-top-1` folder.
5. Select **everything inside the folder** (the `data`, `public`, `scripts`, `src` and `test` folders, plus `package.json`, `package-lock.json`, `render.yaml`, `server.js` and the rest) and drag it all onto the GitHub page.
6. Click **Commit changes**.

**Step 2: Create the service on Render**
1. Sign up at https://render.com with **Sign in with GitHub**, and allow Render to see the `ampyrs-top-1` repository.
2. Click **New → Blueprint**, pick the `ampyrs-top-1` repository, and click **Connect**.
3. Render reads `render.yaml` and shows one web service and one disk. When it asks for **HOST_PIN**, type a number of **6–12 digits** that only you know, e.g. `482913`. This PIN protects the host controls, so don't use 123456.
4. Click **Apply**, and add your card when asked.
5. Wait 2–4 minutes until the service shows **Live**. Your address appears at the top, e.g. `https://ampyrs-top-1.onrender.com`. Yours may have extra letters on the end.

**Step 3: Check it works**
1. On your laptop, open `https://<your address>/host` and enter your HOST_PIN.
2. On your phone, with Wi-Fi **off** (mobile data only), open `https://<your address>`. If the join page appears, everything works.

The QR code on the lobby screen automatically uses your Render address. Nothing else needs configuring.

---

## 2. Rehearse with Demo mode (do this before the event)

1. **Switch to demo.** On the host screen's setup page, choose **Demo mode**, then **Open demo lobby**.
2. **Add players.** Click **More**, then **Add 40 demo players**. Simulated players labelled DEMO PLAYER join.
3. **Join with real devices too.** Scan the QR code with your phone, and try one office laptop on the office Wi-Fi as well.
4. **Play the whole game with Space.** The demo players answer and make exit choices by themselves.
5. **Check the results.** At the end, click **Show host results** and download the CSV.

Demo mode is a separate room with its own code. It never touches the live game. Use **Reset game** to run it again.

---

## 3. Event day checklist

- [ ] **Venue internet:** the room has working internet for the host laptop. Wired or a reliable Wi-Fi is best, and a phone hotspot works as a backup for the host.
- [ ] **Open early:** open `https://<your address>/host` **10 minutes early**, enter your PIN, press **F** for full screen, and drag the browser to the projector.
- [ ] **Mode:** check **Live game** is selected, then click **Open lobby**.
- [ ] **Join:** players scan the QR code, or type the address shown under it, then enter their full name.
- [ ] **Start:** click **Start game**. Registration locks unless you turn on **Late joining**.

Players can be on mobile data or office Wi-Fi, and they don't all need the same network.

---

## 4. Running the show

Press **Space** to advance. It always triggers the gold button in the control panel.

| Key | Action |
|---|---|
| Space | Next step (gold button) |
| P | Pause / resume (stops the clock) |
| M | Mute / unmute sounds |
| F | Full screen |
| C | Show more or fewer controls |
| H | During the final question: who has answered (this shows on the projector) |

**Every question, including the final, has 60 seconds.** All phones and the big screen use the server's clock. A player who hasn't answered at zero is eliminated.

**Each question:**
1. Start question
2. Lock answers (happens automatically at time-up)
3. **If an exit offer is due:** make the offer, wait for decisions, then confirm decisions (see below)
4. Show what the room thought
5. Reveal answer
6. Show explanation
7. Show survivors
8. After Q5 and Q10 only: show players still in
9. Next question

**Exit offers (₹1,000)**
- **When they happen:**
  - **Offer 1:** on the first question that *starts* with 5 or fewer players.
  - **Offer 2:** on a *later* question that starts with 3 or fewer.
  - **If the count drops from above 5 to 3 or fewer in one go:** offer 1 happens on the next question and offer 2 on the one after.
  - **The gold button tells you:** when one is due, it reads **Make exit offer 1** (or 2) straight after the answers lock.
- **Timing:** the offer comes *after* answers lock and *before* the answer is revealed. Nobody knows yet whether they were right.
- **Who gets it:** only players who locked an answer. Anyone who ran out of time is out anyway.
- **The choices, made privately on each phone:**

  | Choice | Answer turns out | Result |
  |---|---|---|
  | Take ₹1,000 | Right or wrong | Gets ₹1,000, game over for them |
  | Stay | Right | Keeps playing and gets ₹1,000 |
  | Stay | Wrong | Eliminated, nothing |

- **Players who don't decide** before you click **Confirm decisions** are treated as staying.
- **Banked money is kept.** A player who stays and is right keeps that ₹1,000 even if they're knocked out later. Someone who stays and is right at both offers gets ₹2,000.
- **An offer can fall on the final question** if that's the first time 5 or fewer are left. Players then choose between a sure ₹1,000 and the final prize.

**Speed rule**
- **What it does:** on a question where it applies, if *everyone* still playing answers correctly and there are at least 2 of them, the single slowest answer is eliminated. A wrong answer is out as usual. If anyone was wrong, nobody goes out on speed.
- **When it starts:**
  - **Automatically at offer 2:** when offer 2 is made, the big screen and phones announce the rule change. It applies from the next question.
  - **Manually:** the host can switch it on at any time with **More → Speed rule: Off/On**. If a question is running, it starts with the next one; otherwise with the question about to start. The **Get ready** screen announces it.
- **Exceptions:**
  - **Exact ties:** if the slowest two arrived at exactly the same moment, nobody goes out on speed.
  - **A lone player** is never eliminated for being slowest.
- **How speed is measured:** from the moment the question opens to the moment the answer reaches the server. Paused time doesn't count.
- **Effect on the final:** with the speed rule on, at most one player can win.

**Players still in the game:** after Q5 and Q10, the gold button after the survivor count becomes **Show players still in**. The big screen then lists everyone still playing, alphabetically so it doesn't look like a ranking.
- **Phones:** they don't receive the list.
- **Other questions:** **More → Show players still in** brings the list up after any of them.
- **Skipping it:** **More → Skip the player list** moves on without it.
- **Changing how often:** set it in **Game settings**. 0 switches it off.

**The final question (Q13):**
- **Timer:** 60 seconds, like every other question.
- **Ending the game:** after the reveal, **Distribute final prize** ends the game and shows the winners.

**Other controls:**
- **Pause** freezes the timer and blocks answers.
- **End game** stops immediately and awards no final prize. Exit-offer money already confirmed still stands.
- **Reset game** clears everything and creates a new room code.

---

## 5. Prize rules (how the engine works)

**Basics:**
- **No running balances.** Phones never show a running total. They show the ₹1,000 offer, and tell a player when they've banked it by staying and being right.
- **Money is tracked in paise.** The total paid can never exceed the configured prize (default ₹10,000). A game with an invalid configuration cannot start.

**Exit offers:**
- **Every offer pays exactly ₹1,000.** There is no cap or sharing: each leaver, and each stayer who is right, gets the full amount.
- **The most they can cost:** at most 5 people can collect at offer 1 and 3 at offer 2, so exit offers can never total more than **₹8,000**.
- **The final prize is therefore always at least ₹2,000.**
- **Configuration check:** if you change the amount or the player counts in settings, the game refuses to start any configuration that could pay out ₹10,000 or more before the final.

**The final prize:**
- **Final prize = total prize − all exit-offer money actually paid.**
- **Without the speed rule,** winners split it equally, floored to the paisa. For example, ₹8,000 ÷ 3 = ₹2,666.66 each, and the 2 paise left over are not paid.
- **With the speed rule on,** there is at most one winner.

**If nobody answers Q13 correctly** (you choose in settings):
- **Default:** the final prize is shared equally among the players who started the last question played.
- **Alternative:** it is not awarded and stays with the organiser.

**Paying people:** the game only calculates. **Show host results → Who to pay** (and the CSV) lists every payment: who, what for, how much.

---

## 6. Editing questions and settings

- **Settings:** on the setup screen, **Game settings** covers the game name, prize, time per question, exit offer amount, the player counts that trigger each offer, how often names are shown, the player limit and the no-winner rule.
- **Questions:** the **Questions** tab lets you edit, add, delete and reorder.
  - The first 13 questions are played in order, and the last one is the final.
  - Each question needs four different options and one correct answer.
  - Leave the timer blank to use the default for its position.
- **Restore defaults:** **Restore the 13 original questions** brings back the built-in set.
- **Where it's saved:** questions are stored in `data/questions.json` and settings in `data/config.json`.
- **When editing locks:** you can edit only before the game starts.

The built-in questions are original. Five are designed so the most popular answer is wrong: Q3, Q4, Q7, Q9 and Q12. When that happens the big screen shows **The room got tricked!**

---

---

## 7. Recovery

**A phone drops out or the browser closes.** The player opens the same address again and is put straight back where they were. Their status and any locked answer are kept. Eliminated players cannot re-enter, and nobody can answer twice.

**The host laptop's browser closes, or the venue internet drops.** Reopen `https://<your address>/host` and enter your PIN. The game runs on Render, not on your laptop, so nothing is lost. Players keep going as soon as their connection returns.

**Render restarts the service.** This happens after a redeploy, and rarely for maintenance. The live game is saved to the disk after every change:
- A question that was open comes back **paused** with its remaining time.
- Press **P** to resume.

**Edited questions and settings** are saved on the same disk, so they survive restarts and redeploys.

---

## 8. Troubleshooting

| Problem | Fix |
|---|---|
| Render deploy fails with "HOST_PIN is missing" | Render dashboard → your service → **Environment** → add `HOST_PIN` (6–12 digits) → **Save, rebuild and deploy**. |
| Host screen says "Incorrect host PIN" | Use the HOST_PIN from Render's **Environment** tab. After 8 wrong tries the host screen locks for 15 minutes. |
| Office laptops can't open the address, but phones on mobile data can | The office web filter may be blocking `onrender.com`. Ask IT to allow your address, or add a custom domain in Render (Settings → Custom Domains). |
| Page loads but updates are slow on office Wi-Fi | The office proxy is probably blocking WebSockets. The game falls back to a slower connection automatically and still works. Ask IT to allow WebSockets to your address if it's noticeable. |
| "Room is full" | Raise **Player limit** in Game settings (up to 200). |
| No sound | Click anywhere on the host page once (browsers need a click first) and check it says **Sound on**. |
| QR code shows the wrong address | Render sets it automatically. If you use a custom domain, add `PUBLIC_URL` = `https://your.domain` in Render's Environment tab and redeploy. |

**Important: keep Render at one instance.** The game holds its live state in a single server process. Two instances would split players between two separate games. `render.yaml` sets this for you, so don't change it in the dashboard.

---

## 9. Privacy and security

**What's stored:**
- Player full names only.
- No email, phone number or employee ID is ever asked for.

**Where it's stored:**
- On your Render service, in the Singapore region, for as long as the service exists.
- Check with IT if AMPYR policy requires approval for this.

**How it's protected:**
- **Encryption:** all traffic is HTTPS.
- **Host controls:** they need your HOST_PIN, and wrong guesses are rate-limited.
- **Room codes** are random (e.g. `AMPYR-W4KS`), so strangers on the internet can't guess their way in.
- **Registration** locks when the game starts.
- **Phones only send three things:** "join", "answer X" and "exit / continue". The server decides everything, and correct answers stay on the server until the reveal.

**After the event:**
1. Download the results CSV.
2. Click **New game (reset)** to clear all players.
3. In Render, delete the service and its disk. This stops billing and removes all data.

**Running it locally instead (no internet).** Install Node.js, unzip, open a terminal in the folder, and run `npm install` then `npm start` (or double-click `start-windows.bat`). The host screen is then `http://localhost:3000/host`, and players must be on the same Wi-Fi as the laptop. Local mode switches on automatically whenever no public address is configured.

---

## 10. Results

After the game, **Show host results** displays:
- Total players and the number eliminated at each question
- What happened at each exit offer: who left, who stayed and was right, who stayed and was wrong
- Who to pay, for what and how much, including every ₹1,000 offer payment
- How many reached Q13 and how many answered it correctly
- The winners and the full prize reconciliation
- The correct-answer percentage and A/B/C/D distribution for every question

**Download results (CSV)** saves it all, including the payout list with names, for finance. Players never see these analytics.

---

---

## 11. For the technically curious

| Command | What it checks |
|---|---|
| `npm test` | Game rules, prize maths, timers, pause, demo game |
| `npm run loadtest` | 100 simulated phones play a complete game against a throwaway server on port 3999. Your real data is not touched. |

**Project layout:**
- `server.js`: HTTP server, Socket.IO, host PIN, QR code and CSV export
- `src/game.js`: the authoritative game state machine
- `src/prize.js`: the prize engine and configuration validation
- `public/`: the host screen (`host.html`) and the player page (`index.html`)

**Security model:**
- **The server decides everything:** who is active, whether an answer is correct, eliminations, exits and payouts.
- **Phones only send** "join", "answer X" and "exit / continue".
- **Correct answers stay on the server** until the reveal.

Sound effects are generated in the browser. No music or audio from any TV programme is used.
