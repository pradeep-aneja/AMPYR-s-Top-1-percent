'use strict';
/**
 * PRIZE ENGINE
 * All money is handled internally in integer paise so rounding can never
 * push the total paid above the configured prize pool.
 *
 * Rules (see README "Prize rules"):
 *  - Final prize pool = Total prize − all exit payouts actually paid.
 *  - An exit offer is a per-player amount (e.g. ₹2,000).
 *  - Each exit round may use at most `exitCapPct` % of the pool remaining at
 *    that moment (the "exit fund"). If the players who exit would together
 *    exceed that fund, the fund is shared equally among them.
 *  - Final winners split the final pool equally, floored to the paisa.
 *    Any leftover paise (at most winners−1) are reported as rounding residue.
 */

const toPaise = (rupees) => Math.round(Number(rupees) * 100);
const toRupees = (paise) => Math.round(paise) / 100;

function formatINR(paise) {
  const r = toRupees(paise);
  return '₹' + r.toLocaleString('en-IN', {
    minimumFractionDigits: Number.isInteger(r) ? 0 : 2,
    maximumFractionDigits: 2,
  });
}

/** Payout for one exit round. */
function exitRoundPayout({ remainingPaise, amountPaise, exiters, capPct }) {
  if (exiters <= 0 || amountPaise <= 0) {
    return { perPlayerPaise: 0, totalPaise: 0, fundPaise: 0, capped: false };
  }
  const fundPaise = Math.floor((remainingPaise * capPct) / 100);
  const fullCost = amountPaise * exiters;
  if (fullCost <= fundPaise) {
    return { perPlayerPaise: amountPaise, totalPaise: fullCost, fundPaise, capped: false };
  }
  const per = Math.floor(fundPaise / exiters);
  return { perPlayerPaise: per, totalPaise: per * exiters, fundPaise, capped: true };
}

/** Equal split of a pool among n winners, never exceeding the pool. */
function equalSplit(poolPaise, n) {
  if (n <= 0) return { eachPaise: 0, residuePaise: poolPaise };
  const each = Math.floor(poolPaise / n);
  return { eachPaise: each, residuePaise: poolPaise - each * n };
}

/** How many players can take a given exit at full value. */
function fullValueExitCapacity(remainingPaise, amountPaise, capPct) {
  if (amountPaise <= 0) return Infinity;
  return Math.floor(Math.floor((remainingPaise * capPct) / 100) / amountPaise);
}

const NO_WINNER_RULES = {
  split_last_standing: 'Split equally among the players who started the last question played',
  retained: 'Prize stays with the organiser (not awarded)',
};

/**
 * Validate config + questions before a game may start.
 * Returns { errors: string[], warnings: string[] }.
 */
function validateGame(config, questions) {
  const errors = [];
  const warnings = [];
  const c = config || {};
  const n = Number(c.questionCount);

  if (!Number.isInteger(n) || n < 3 || n > 30) {
    errors.push('Question count must be a whole number between 3 and 30.');
  }
  const qs = Array.isArray(questions) ? questions : [];
  if (Number.isInteger(n) && qs.length < n) {
    errors.push(`The game needs ${n} questions but only ${qs.length} exist. Add ${n - qs.length} more in the Questions tab.`);
  }
  qs.slice(0, Number.isInteger(n) ? n : qs.length).forEach((q, i) => {
    const label = `Question ${i + 1}`;
    if (!q || !String(q.question || '').trim()) errors.push(`${label} has no question text.`);
    const opts = ['optionA', 'optionB', 'optionC', 'optionD'].map((k) => String((q && q[k]) || '').trim());
    if (opts.some((o) => !o)) errors.push(`${label} must have exactly four filled options (A–D).`);
    const lower = opts.filter(Boolean).map((o) => o.toLowerCase());
    if (new Set(lower).size !== lower.length) errors.push(`${label} has two identical options.`);
    if (!['A', 'B', 'C', 'D'].includes(q && q.correctAnswer)) errors.push(`${label} needs exactly one correct answer (A, B, C or D).`);
    if (q && q.timer != null && q.timer !== '' && (!Number.isInteger(Number(q.timer)) || q.timer < 5 || q.timer > 600)) {
      errors.push(`${label} has an invalid timer override (use 5–600 seconds, or leave blank to use the default).`);
    }
  });

  const total = toPaise(c.totalPrize);
  const amt = toPaise(c.exitAmount);
  const first = Number(c.firstOfferAt);
  const second = Number(c.secondOfferAt);

  if (!Number.isFinite(total) || total < 100 || total > toPaise(10000000)) {
    errors.push('Total prize must be between ₹1 and ₹1,00,00,000.');
  }
  if (!(amt >= 0)) errors.push('The exit offer amount cannot be negative.');
  if (!Number.isInteger(first) || first < 1 || first > 200) errors.push('"First exit offer when players left" must be a whole number from 1 upwards.');
  if (!Number.isInteger(second) || second < 1 || second > 200) errors.push('"Second exit offer when players left" must be a whole number from 1 upwards.');
  if (errors.length === 0 && second >= first) {
    errors.push(`The second exit offer (at ${second} players or fewer) must trigger at fewer players than the first (${first}).`);
  }
  if (errors.length === 0 && amt > 0) {
    // At most `first` people can collect at offer 1 and `second` at offer 2
    // (each leaver, plus each stayer who answers correctly, receives the amount once per offer).
    const maxExit = amt * (first + second);
    if (maxExit >= total) {
      errors.push(`Exit offers could pay up to ${formatINR(maxExit)} (${formatINR(amt)} × ${first + second} players), leaving nothing for the final prize of ${formatINR(total)}.`);
    } else {
      warnings.push(`Exit offers pay ${formatINR(amt)} each and can total at most ${formatINR(maxExit)}, so the final prize is always at least ${formatINR(total - maxExit)}.`);
    }
  }

  const t = Number(c.timerSecs);
  if (!Number.isInteger(t) || t < 5 || t > 600) errors.push('Time per question must be 5–600 seconds.');

  const every = Number(c.showActiveEvery);
  if (!Number.isInteger(every) || every < 0 || every > 30) errors.push('"Show names still in" must be every 0–30 questions (0 switches it off).');

  const limit = Number(c.playerLimit);
  if (!Number.isInteger(limit) || limit < 2 || limit > 200) errors.push('Player limit must be between 2 and 200.');
  if (!NO_WINNER_RULES[c.noWinnerRule]) errors.push('Choose what happens to the prize if nobody wins.');
  if (!String(c.gameName || '').trim()) errors.push('Game name cannot be empty.');

  return { errors, warnings };
}

module.exports = {
  toPaise, toRupees, formatINR, exitRoundPayout, equalSplit,
  fullValueExitCapacity, validateGame, NO_WINNER_RULES,
};
