'use strict';
/**
 * AMPYR ke Top 1% — authoritative game engine (rules v2).
 *
 * Exit offers (C2, C3, C4, C8):
 *  - Offer 1 is made on the first question that STARTS with ≤ firstOfferAt players.
 *  - Offer 2 is made on a LATER question that starts with ≤ secondOfferAt players.
 *  - The offer comes after answers lock and before the answer is revealed, and only
 *    to players who locked an answer. Non-answerers are simply eliminated.
 *  - Leave: +exitAmount, out of the game regardless of the answer.
 *  - Stay + correct: continues and banks +exitAmount (kept even if knocked out later).
 *  - Stay + wrong: eliminated, no money.
 * Speed rule (C5, C6, C7):
 *  - Switches on when offer 2 is made, or when the host switches it on. It applies from
 *    the NEXT question (or the upcoming one if no question is running).
 *  - On a question where it applies: if everyone still playing answered correctly and at
 *    least 2 are playing, the single slowest correct answer is eliminated. Exact ties: nobody.
 * Money: everything in integer paise. Total paid can never exceed the configured prize.
 */
const crypto = require('crypto');
const EventEmitter = require('events');
const prize = require('./prize');
const { cleanText, writeAtomic, readJSON } = require('./store');

const STATE_VERSION = 2;
const OPTS = ['A', 'B', 'C', 'D'];
const GRACE_MS = 400; // network latency allowance after the deadline

const P = {
  SETUP: 'SETUP',
  LOBBY: 'LOBBY',
  QUESTION_READY: 'QUESTION_READY',
  QUESTION_OPEN: 'QUESTION_OPEN',
  FINAL_QUESTION: 'FINAL_QUESTION',
  QUESTION_LOCKED: 'QUESTION_LOCKED',
  EXIT_DECISION: 'EXIT_DECISION',
  EXIT_RESULT: 'EXIT_RESULT',
  ROOM_DISTRIBUTION: 'ROOM_DISTRIBUTION',
  ANSWER_REVEAL: 'ANSWER_REVEAL',
  EXPLANATION: 'EXPLANATION',
  SURVIVOR_UPDATE: 'SURVIVOR_UPDATE',
  ACTIVE_LIST: 'ACTIVE_LIST',
  GAME_COMPLETE: 'GAME_COMPLETE',
};
const OPEN_PHASES = new Set([P.QUESTION_OPEN, P.FINAL_QUESTION]);
const QUESTION_VISIBLE = new Set([
  P.QUESTION_OPEN, P.FINAL_QUESTION, P.QUESTION_LOCKED, P.EXIT_DECISION, P.EXIT_RESULT,
  P.ROOM_DISTRIBUTION, P.ANSWER_REVEAL, P.EXPLANATION, P.SURVIVOR_UPDATE,
]);
const REVEALED = new Set([P.ANSWER_REVEAL, P.EXPLANATION, P.SURVIVOR_UPDATE, P.ACTIVE_LIST]);
const DIST_VISIBLE = new Set([P.ROOM_DISTRIBUTION, P.ANSWER_REVEAL, P.EXPLANATION, P.SURVIVOR_UPDATE]);
const AFTER_REVEAL = new Set([P.ANSWER_REVEAL, P.EXPLANATION, P.SURVIVOR_UPDATE, P.ACTIVE_LIST]);

const DIFFICULTY_ACCURACY = {
  'very easy': 0.98, easy: 0.95, 'easy–moderate': 0.88, 'easy-moderate': 0.88, moderate: 0.88,
  'moderate–hard': 0.85, 'moderate-hard': 0.85, hard: 0.82, 'very hard': 0.8, elite: 0.78,
  'extremely difficult': 0.75, 'top 1%': 0.4,
};

const randId = (bytes = 9) => crypto.randomBytes(bytes).toString('hex');
const normName = (s) => String(s).toLowerCase().replace(/\s+/g, ' ').trim();
const CODE_CHARS = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // no 0/O, 1/I
const genCode = (prefix) => prefix + '-' + Array.from({ length: 4 }, () => CODE_CHARS[crypto.randomInt(CODE_CHARS.length)]).join('');

class GameRoom extends EventEmitter {
  constructor({ kind, store, persistFile = null }) {
    super();
    this.kind = kind; // 'live' | 'demo'
    this.store = store;
    this.persistFile = persistFile;
    this.timer = null;
    this.botTimers = [];
    this._persistT = null;
    this.reset();
    if (persistFile) this._load();
  }

  /* ---------------------------------------------------------------- state */
  reset() {
    this._clearTimers();
    this.s = {
      version: STATE_VERSION,
      phase: P.SETUP,
      code: genCode(this.kind === 'demo' ? 'DEMO' : 'AMPYR'),
      config: null, // snapshot at START_GAME
      questions: null, // snapshot at START_GAME
      qIndex: -1,
      players: {},
      joinOrder: [],
      deadline: null,
      paused: false,
      pausedRemaining: null,
      pauseStartedAt: null,
      allowLateJoin: false,
      history: [],
      offers: [],
      speed: { on: false, fromQ: null, source: null },
      paidPaise: 0, // all exit-offer money (leavers + correct stayers)
      final: null,
      startedAt: null,
      endedAt: null,
      endReason: null,
      startingPlayers: 0,
      dotOrder: [],
      activeListShown: {},
    };
    this.tokens = new Map();
    this._changed('reset');
  }

  get cfg() { return this.s.config || this.store.config; }
  get questions() { return this.s.questions || this.store.questions.slice(0, this.store.config.questionCount); }
  get qCount() { return this.s.config ? this.s.config.questionCount : this.store.config.questionCount; }
  get isFinal() { return this.s.qIndex === this.qCount - 1; }
  get currentQ() { return this.s.qIndex >= 0 ? this.questions[this.s.qIndex] : null; }
  get entry() { return this.s.history[this.s.qIndex] || null; }
  players() { return this.s.joinOrder.map((id) => this.s.players[id]).filter(Boolean); }
  active() { return this.players().filter((p) => p.status === 'active'); }
  offer(no) { return this.s.offers.find((o) => o.no === no) || null; }
  currentOffer() { const e = this.entry; return e && e.offer ? this.offer(e.offer) : null; }

  timerFor(i) {
    const q = this.questions[i];
    if (q && Number.isInteger(q.timer) && q.timer > 0) return q.timer;
    return this.cfg.timerSecs;
  }

  /** Which offer (1, 2 or none) is due on a question that starts with n players. */
  offerDueFor(n) {
    const c = this.cfg;
    if (!(c.exitAmount > 0)) return null;
    if (!this.offer(1) && n <= c.firstOfferAt) return 1;
    if (this.offer(1) && !this.offer(2) && n <= c.secondOfferAt) return 2;
    return null;
  }

  /** Is the speed rule in force for question number qn? */
  speedAppliesTo(qn) { return !!(this.s.speed.on && this.s.speed.fromQ != null && qn >= this.s.speed.fromQ); }

  joinLimit() { return this.kind === 'demo' ? 200 : this.store.config.playerLimit; }
  validation() { return prize.validateGame(this.store.config, this.store.questions); }

  /* -------------------------------------------------------------- players */
  join({ name }) {
    name = cleanText(name, 40).replace(/\s+/g, ' ');
    if (!name) return { ok: false, error: 'Enter your full name.' };
    if (name.split(' ').filter(Boolean).length < 2) return { ok: false, error: 'Please enter your full name: first name and surname.' };
    const ph = this.s.phase;
    if (ph === P.SETUP) return { ok: false, error: 'The host has not opened the lobby yet. Try again in a moment.' };
    if (ph === P.GAME_COMPLETE) return { ok: false, error: 'This game has finished.' };
    if (ph !== P.LOBBY) {
      if (!this.s.allowLateJoin) return { ok: false, error: 'The game has already started and registration is closed.' };
      if (this.isFinal) return { ok: false, error: 'The final question is under way. Registration is closed.' };
    }
    const limit = this.joinLimit();
    if (this.players().length >= limit) return { ok: false, error: `The room is full (${limit} players).` };
    const nn = normName(name);
    if (this.players().some((p) => normName(p.name) === nn)) {
      return { ok: false, error: `"${name}" has already joined. If that's someone else with the same name, add a middle name or initial.` };
    }
    const p = this._newPlayer(name, false);
    if (OPEN_PHASES.has(ph) && this.entry) this.entry.ids.push(p.id);
    this._changed('join');
    return { ok: true, playerId: p.id, token: p.token };
  }

  _newPlayer(name, isBot) {
    const p = {
      id: randId(6), token: randId(16), name, isBot,
      status: 'active', answers: {}, answerMs: {}, exitDecisions: {},
      eliminatedAt: null, eliminatedReason: null, exitedAt: null,
      awards: [], awardPaise: 0, prizePaise: 0, winner: false, joinedAt: Date.now(),
      lateJoin: this.s.phase !== P.LOBBY,
    };
    this.s.players[p.id] = p;
    this.s.joinOrder.push(p.id);
    this.tokens.set(p.token, p.id);
    if (this.s.phase !== P.LOBBY && this.s.phase !== P.SETUP) this.s.dotOrder.push(p.id);
    return p;
  }

  byToken(token) {
    const id = this.tokens.get(String(token || ''));
    return id ? this.s.players[id] : null;
  }

  answer(playerId, option) {
    const p = this.s.players[playerId];
    if (!p) return { ok: false, error: 'Player not found.' };
    if (!OPEN_PHASES.has(this.s.phase)) return { ok: false, error: 'Answers are closed.' };
    if (this.s.paused) return { ok: false, error: 'The game is paused.' };
    if (p.status !== 'active') return { ok: false, error: 'You are no longer in the game.' };
    if (!OPTS.includes(option)) return { ok: false, error: 'Invalid option.' };
    const e = this.entry;
    if (!e || !e.ids.includes(p.id)) return { ok: false, error: 'You are not playing this question.' };
    if (p.answers[this.s.qIndex]) return { ok: false, error: 'Your answer is already locked.' };
    const now = Date.now();
    if (this.s.deadline && now > this.s.deadline + GRACE_MS) return { ok: false, error: "Time's up." };
    p.answers[this.s.qIndex] = option;
    p.answerMs[this.s.qIndex] = now - e.startedAt - (e.pausedMs || 0); // server-measured thinking time
    this._changed('answer');
    return { ok: true };
  }

  decideExit(playerId, choice) {
    const p = this.s.players[playerId];
    if (!p) return { ok: false, error: 'Player not found.' };
    if (this.s.phase !== P.EXIT_DECISION) return { ok: false, error: 'There is no exit decision open.' };
    if (this.s.paused) return { ok: false, error: 'The game is paused.' };
    const o = this.currentOffer();
    if (!o || !o.offeredTo.includes(p.id) || p.status !== 'active') return { ok: false, error: 'This offer is not open to you.' };
    if (!['exit', 'continue'].includes(choice)) return { ok: false, error: 'Invalid choice.' };
    if (p.exitDecisions[o.question]) return { ok: false, error: 'Your decision is already locked.' };
    p.exitDecisions[o.question] = choice;
    this._changed('decision');
    return { ok: true };
  }

  /* ------------------------------------------------------------- host ops */
  action(type, payload = {}) {
    const s = this.s;
    const fail = (error) => ({ ok: false, error });
    const ph = s.phase;

    switch (type) {
      case 'OPEN_LOBBY': {
        if (ph !== P.SETUP) return fail('The lobby is already open.');
        const v = this.validation();
        if (v.errors.length) return fail('Fix the configuration first: ' + v.errors[0]);
        s.phase = P.LOBBY;
        s.allowLateJoin = false;
        break;
      }
      case 'BACK_TO_SETUP': {
        if (ph !== P.LOBBY) return fail('Only available from the lobby.');
        s.phase = P.SETUP;
        break;
      }
      case 'REMOVE_PLAYER': {
        if (ph !== P.LOBBY) return fail('Players can only be removed in the lobby.');
        const p = s.players[payload.playerId];
        if (!p) return fail('Player not found.');
        delete s.players[p.id];
        s.joinOrder = s.joinOrder.filter((id) => id !== p.id);
        this.tokens.delete(p.token);
        this.emit('kicked', p.id);
        break;
      }
      case 'SET_LATE_JOIN': {
        s.allowLateJoin = !!payload.value;
        break;
      }
      case 'SET_SPEED_RULE': {
        if (ph === P.GAME_COMPLETE) return fail('The game has ended.');
        if (payload.value) {
          if (s.speed.on) return fail('The speed rule is already on.');
          // Applies to the upcoming question if none is running, otherwise from the next one.
          const started = s.qIndex >= 0 && !!s.history[s.qIndex];
          const fromQ = s.qIndex < 0 ? 1 : started ? s.qIndex + 2 : s.qIndex + 1;
          s.speed = { on: true, fromQ, source: 'host', announcedAt: Date.now() };
        } else {
          s.speed = { on: false, fromQ: null, source: null };
        }
        break;
      }
      case 'START_GAME': {
        if (ph !== P.LOBBY) return fail('Open the lobby first.');
        const v = this.validation();
        if (v.errors.length) return fail('Fix the configuration first: ' + v.errors[0]);
        if (this.players().length < 1) return fail('At least one player must join before you start.');
        s.config = JSON.parse(JSON.stringify(this.store.config));
        s.questions = JSON.parse(JSON.stringify(this.store.questions.slice(0, s.config.questionCount)));
        s.startedAt = Date.now();
        s.startingPlayers = this.players().length;
        s.dotOrder = this._shuffle(this.players().map((p) => p.id));
        s.qIndex = 0;
        s.phase = P.QUESTION_READY;
        break;
      }
      case 'START_QUESTION': {
        if (ph !== P.QUESTION_READY) return fail('No question is ready to start.');
        const act = this.active();
        if (!act.length) return fail('No active players remain.');
        const secs = this.timerFor(s.qIndex);
        const number = s.qIndex + 1;
        s.history[s.qIndex] = {
          qIndex: s.qIndex, number, timer: secs,
          ids: act.map((p) => p.id), activeAtStart: act.length,
          offer: this.offerDueFor(act.length), offerDone: false,
          speedRule: this.speedAppliesTo(number),
          counts: null, correct: null, survived: null, eliminated: null, noAnswer: null,
          tricked: false, speedOut: null, speedTie: false, left: 0,
          startedAt: Date.now(), pausedMs: 0, lockedAt: null,
        };
        s.paused = false;
        s.pausedRemaining = null;
        s.deadline = Date.now() + secs * 1000;
        this._armTimer(secs * 1000);
        s.phase = this.isFinal ? P.FINAL_QUESTION : P.QUESTION_OPEN;
        if (this.kind === 'demo') this._botsAnswer();
        break;
      }
      case 'LOCK_ANSWERS': {
        if (!OPEN_PHASES.has(ph)) return fail('No question is open.');
        this._lock(payload.reason || 'host');
        return { ok: true };
      }
      case 'OFFER_EXIT': {
        if (ph !== P.QUESTION_LOCKED) return fail('Lock the answers first.');
        const e = this.entry;
        if (!e.offer || e.offerDone) return fail('There is no exit offer on this question.');
        const eligible = e.ids.map((id) => s.players[id]).filter((p) => p && p.status === 'active' && p.answers[s.qIndex]);
        s.offers.push({
          no: e.offer, question: e.number, amountPaise: prize.toPaise(s.config.exitAmount),
          offeredTo: eligible.map((p) => p.id), confirmed: false,
          leavers: [], stayers: [], undecided: 0, stayCorrect: [], stayWrong: [],
          paidLeavePaise: 0, paidStayPaise: 0,
        });
        if (e.offer === 2 && !s.speed.on) {
          s.speed = { on: true, fromQ: e.number + 1, source: 'offer', announcedAt: Date.now() };
        }
        s.phase = P.EXIT_DECISION;
        if (this.kind === 'demo') this._botsDecide();
        break;
      }
      case 'CONFIRM_EXIT': {
        if (ph !== P.EXIT_DECISION) return fail('No exit decision is open.');
        this._confirmExit();
        s.phase = P.EXIT_RESULT;
        break;
      }
      case 'SHOW_ROOM': {
        if (ph === P.QUESTION_LOCKED) {
          const e = this.entry;
          if (e.offer && !e.offerDone) return fail('Make the exit offer first: it comes before the answer is revealed.');
        } else if (ph !== P.EXIT_RESULT) return fail('Lock the answers first.');
        s.phase = P.ROOM_DISTRIBUTION;
        break;
      }
      case 'REVEAL_ANSWER': {
        if (ph === P.QUESTION_LOCKED || ph === P.EXIT_RESULT) {
          const r = this.action('SHOW_ROOM');
          if (!r.ok) return r;
        } else if (ph !== P.ROOM_DISTRIBUTION) return fail('Show the room first.');
        this._reveal();
        s.phase = P.ANSWER_REVEAL;
        break;
      }
      case 'SHOW_EXPLANATION': {
        if (![P.ANSWER_REVEAL, P.SURVIVOR_UPDATE, P.ACTIVE_LIST].includes(s.phase)) return fail('Reveal the answer first.');
        s.phase = P.EXPLANATION;
        break;
      }
      case 'SHOW_SURVIVORS': {
        if (![P.ANSWER_REVEAL, P.EXPLANATION, P.ACTIVE_LIST].includes(ph)) return fail('Reveal the answer first.');
        s.phase = P.SURVIVOR_UPDATE;
        break;
      }
      case 'SHOW_ACTIVE': {
        if (![P.SURVIVOR_UPDATE, P.EXPLANATION].includes(ph)) return fail('Show the survivors first.');
        if (this.isFinal) return fail('The game is over: show the winners instead.');
        if (!this.active().length) return fail('Nobody is left in the game.');
        s.activeListShown[s.qIndex] = true;
        s.phase = P.ACTIVE_LIST;
        break;
      }
      case 'NEXT_QUESTION': {
        if (![P.SURVIVOR_UPDATE, P.EXPLANATION, P.ACTIVE_LIST].includes(ph)) return fail('Finish this question first.');
        if (this.isFinal) return fail('That was the final question. Distribute the final prize.');
        if (!this.active().length) return fail('Nobody is left in the game. End the game to apply the no-winner rule.');
        s.qIndex += 1;
        s.phase = P.QUESTION_READY;
        break;
      }
      case 'DISTRIBUTE_FINAL': {
        const done = AFTER_REVEAL.has(ph);
        if (!done) return fail('Reveal the answer first.');
        if (!this.isFinal && this.active().length) return fail('There are still questions to play.');
        this._finalize('complete');
        break;
      }
      case 'PAUSE': {
        if (s.paused) return fail('Already paused.');
        if (ph === P.SETUP || ph === P.GAME_COMPLETE) return fail('Nothing to pause.');
        s.paused = true;
        s.pauseStartedAt = Date.now();
        if (s.deadline) {
          s.pausedRemaining = Math.max(0, s.deadline - Date.now());
          s.deadline = null;
          this._clearTimer();
        }
        this._clearBots();
        break;
      }
      case 'RESUME': {
        if (!s.paused) return fail('The game is not paused.');
        s.paused = false;
        if (OPEN_PHASES.has(ph) && this.entry && s.pauseStartedAt) this.entry.pausedMs += Date.now() - s.pauseStartedAt;
        s.pauseStartedAt = null;
        if (s.pausedRemaining != null && OPEN_PHASES.has(ph)) {
          const rem = Math.max(3000, s.pausedRemaining);
          s.deadline = Date.now() + rem;
          this._armTimer(rem);
        }
        s.pausedRemaining = null;
        if (this.kind === 'demo') {
          if (OPEN_PHASES.has(ph)) this._botsAnswer();
          if (ph === P.EXIT_DECISION) this._botsDecide();
        }
        break;
      }
      case 'END_GAME': {
        if (ph === P.SETUP) return fail('No game is running.');
        if (ph === P.GAME_COMPLETE) return fail('The game has already ended.');
        this._finalize('ended_by_host');
        break;
      }
      case 'RESET_GAME': {
        const ids = this.players().map((p) => p.id);
        this.reset();
        ids.forEach((id) => this.emit('kicked', id));
        return { ok: true };
      }
      case 'ADD_BOTS': {
        if (this.kind !== 'demo') return fail('Simulated players are only available in demo mode.');
        if (ph !== P.LOBBY) return fail('Open the demo lobby first.');
        const n = Math.max(1, Math.min(150, Number(payload.count) || 40));
        const existing = this.players().filter((p) => p.isBot).length;
        const add = Math.min(n, this.joinLimit() - this.players().length);
        if (add <= 0) return fail('The demo room is full (200).');
        for (let i = 0; i < add; i++) this._newPlayer(`DEMO PLAYER ${String(existing + i + 1).padStart(2, '0')}`, true);
        break;
      }
      case 'REMOVE_BOTS': {
        if (this.kind !== 'demo' || ph !== P.LOBBY) return fail('Only available in the demo lobby.');
        for (const p of this.players().filter((x) => x.isBot)) {
          delete s.players[p.id];
          this.tokens.delete(p.token);
        }
        s.joinOrder = s.joinOrder.filter((id) => s.players[id]);
        break;
      }
      default:
        return fail('Unknown action: ' + type);
    }
    this._changed(type);
    return { ok: true };
  }

  /* ------------------------------------------------------------ internals */
  _award(p, q, type, paise) {
    p.awards.push({ q, type, paise });
    p.awardPaise += paise;
    this.s.paidPaise += paise;
  }

  _lock(reason) {
    const s = this.s;
    const e = this.entry;
    this._clearTimer();
    this._clearBots();
    s.deadline = null;
    s.paused = false;
    s.pausedRemaining = null;
    const counts = { A: 0, B: 0, C: 0, D: 0, none: 0 };
    for (const id of e.ids) {
      const p = s.players[id];
      const a = p && p.answers[s.qIndex];
      if (a) counts[a] += 1; else counts.none += 1;
    }
    e.counts = counts;
    e.lockedAt = Date.now();
    e.lockReason = reason;
    s.phase = P.QUESTION_LOCKED;
    // An offer with nobody eligible (everyone timed out) is recorded as made, with no takers.
    if (e.offer && !e.ids.some((id) => s.players[id]?.status === 'active' && s.players[id].answers[s.qIndex])) {
      s.offers.push({ no: e.offer, question: e.number, amountPaise: prize.toPaise(s.config.exitAmount), offeredTo: [], confirmed: true, leavers: [], stayers: [], undecided: 0, stayCorrect: [], stayWrong: [], paidLeavePaise: 0, paidStayPaise: 0 });
      e.offerDone = true;
    }
    this._changed('lock');
  }

  _confirmExit() {
    const s = this.s;
    const e = this.entry;
    const o = this.currentOffer();
    const players = o.offeredTo.map((id) => s.players[id]).filter((p) => p && p.status === 'active');
    for (const p of players) {
      if (!p.exitDecisions[o.question]) { p.exitDecisions[o.question] = 'continue'; p.exitDefaulted = true; o.undecided += 1; }
      if (p.exitDecisions[o.question] === 'exit') {
        p.status = 'exited';
        p.exitedAt = o.question;
        this._award(p, o.question, 'left', o.amountPaise);
        o.leavers.push(p.id);
        o.paidLeavePaise += o.amountPaise;
      } else {
        o.stayers.push(p.id);
      }
    }
    o.confirmed = true;
    e.offerDone = true;
    e.left = o.leavers.length;
    this._clearBots();
  }

  _reveal() {
    const s = this.s;
    const e = this.entry;
    const q = this.currentQ;
    e.correct = q.correctAnswer;
    const o = e.offer ? this.currentOffer() : null;
    const playing = e.ids.map((id) => s.players[id]).filter((p) => p && p.status === 'active');
    let eliminated = 0;
    let noAnswer = 0;
    const right = [];
    for (const p of playing) {
      const a = p.answers[s.qIndex];
      if (a === q.correctAnswer) { right.push(p); continue; }
      p.status = 'eliminated';
      p.eliminatedAt = e.number;
      p.eliminatedReason = a ? 'wrong' : 'no-answer';
      if (!a) noAnswer += 1;
      eliminated += 1;
    }
    // Stayers who were right bank the offer amount.
    if (o) {
      for (const id of o.stayers) {
        const p = s.players[id];
        if (p.answers[s.qIndex] === q.correctAnswer) {
          this._award(p, o.question, 'stayed', o.amountPaise);
          o.stayCorrect.push(id);
          o.paidStayPaise += o.amountPaise;
        } else {
          o.stayWrong.push(id);
        }
      }
    }
    // Speed rule: everyone right and at least two playing → the single slowest is out.
    if (e.speedRule && playing.length >= 2 && right.length === playing.length) {
      const times = right.map((p) => p.answerMs[s.qIndex]);
      const slowest = Math.max(...times);
      const atSlowest = right.filter((p) => p.answerMs[s.qIndex] === slowest);
      if (atSlowest.length === 1) {
        const p = atSlowest[0];
        p.status = 'eliminated';
        p.eliminatedAt = e.number;
        p.eliminatedReason = 'slowest';
        e.speedOut = p.id;
        eliminated += 1;
      } else {
        e.speedTie = true;
      }
    }
    e.survived = this.active().filter((p) => e.ids.includes(p.id)).length;
    e.eliminated = eliminated;
    e.noAnswer = noAnswer;
    const c = e.counts;
    const top = OPTS.reduce((best, x) => (c[x] > c[best] ? x : best), 'A');
    e.mostPopular = c[top] > 0 ? top : null;
    e.tricked = !!e.mostPopular && e.mostPopular !== q.correctAnswer && c[top] > c[q.correctAnswer];
  }

  _finalize(reason) {
    const s = this.s;
    this._clearTimers();
    if (s.config == null) {
      s.config = JSON.parse(JSON.stringify(this.store.config));
      s.questions = JSON.parse(JSON.stringify(this.store.questions.slice(0, s.config.questionCount)));
    }
    const total = prize.toPaise(s.config.totalPrize);
    const pool = total - s.paidPaise;
    const finished = reason === 'complete';
    const last = s.history.filter(Boolean).slice(-1)[0];
    const winners = finished && this.isFinal && last && last.correct ? this.active() : [];
    const f = {
      reason, totalPaise: total, exitPaidPaise: s.paidPaise, finalPoolPaise: pool,
      winners: winners.map((p) => p.id), mode: null, recipients: [],
      eachPaise: 0, residuePaise: 0, retainedPaise: 0,
    };
    if (winners.length) {
      const sp = prize.equalSplit(pool, winners.length);
      winners.forEach((p) => { p.prizePaise = sp.eachPaise; p.winner = true; });
      Object.assign(f, { mode: 'winners', recipients: f.winners, eachPaise: sp.eachPaise, residuePaise: sp.residuePaise });
    } else if (finished && s.config.noWinnerRule === 'split_last_standing') {
      const ids = last ? last.ids.filter((id) => s.players[id] && s.players[id].status !== 'exited') : [];
      if (ids.length) {
        const sp = prize.equalSplit(pool, ids.length);
        ids.forEach((id) => { s.players[id].prizePaise = sp.eachPaise; });
        Object.assign(f, { mode: 'last_standing', recipients: ids, lastQuestion: last.number, eachPaise: sp.eachPaise, residuePaise: sp.residuePaise });
      } else {
        Object.assign(f, { mode: 'retained', retainedPaise: pool });
      }
    } else {
      Object.assign(f, { mode: finished ? 'retained' : 'not_awarded', retainedPaise: pool });
    }
    const paid = s.paidPaise + f.eachPaise * f.recipients.length;
    f.paidPaise = paid;
    f.reconciled = pool >= 0 && paid <= total && paid + f.residuePaise + f.retainedPaise === total;
    if (!f.reconciled) throw new Error('Prize reconciliation failed: payouts exceed or mismatch the pool.');
    s.final = f;
    s.endedAt = Date.now();
    s.endReason = reason;
    s.phase = P.GAME_COMPLETE;
  }

  _shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = crypto.randomInt(i + 1);
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  _armTimer(ms) {
    this._clearTimer();
    this.timer = setTimeout(() => {
      this.timer = null;
      if (OPEN_PHASES.has(this.s.phase) && !this.s.paused) this._lock('timeup');
    }, ms + GRACE_MS);
  }
  _clearTimer() { if (this.timer) clearTimeout(this.timer); this.timer = null; }
  _clearBots() { this.botTimers.forEach(clearTimeout); this.botTimers = []; }
  _clearTimers() { this._clearTimer(); this._clearBots(); }

  /* ------------------------------------------------------- demo players */
  _botsAnswer() {
    this._clearBots();
    const q = this.currentQ;
    const e = this.entry;
    const remainingMs = this.s.deadline ? this.s.deadline - Date.now() : 20000;
    const window = Math.max(1500, Math.min(remainingMs - 1500, 25000));
    const acc = DIFFICULTY_ACCURACY[String(q.difficulty || '').toLowerCase()] ?? 0.6;
    for (const id of e.ids) {
      const p = this.s.players[id];
      if (!p || !p.isBot || p.status !== 'active' || p.answers[this.s.qIndex]) continue;
      if (Math.random() < 0.02) continue;
      let pick = q.correctAnswer;
      if (Math.random() > acc) {
        const wrong = OPTS.filter((o) => o !== q.correctAnswer);
        pick = q.trapAnswer && q.trapAnswer !== q.correctAnswer && Math.random() < 0.75 ? q.trapAnswer : wrong[crypto.randomInt(wrong.length)];
      }
      this.botTimers.push(setTimeout(() => this.answer(id, pick), 600 + Math.random() * window));
    }
  }

  _botsDecide() {
    this._clearBots();
    const o = this.currentOffer();
    for (const id of o.offeredTo) {
      const p = this.s.players[id];
      if (!p || !p.isBot || p.exitDecisions[o.question]) continue;
      const choice = Math.random() < 0.3 ? 'exit' : 'continue';
      this.botTimers.push(setTimeout(() => this.decideExit(id, choice), 500 + Math.random() * 4000));
    }
  }

  /* ---------------------------------------------------------- persistence */
  _changed(reason) {
    this.emit('change', reason);
    if (this.persistFile) {
      clearTimeout(this._persistT);
      this._persistT = setTimeout(() => this._save(), 150);
    }
  }

  _save() {
    try { writeAtomic(this.persistFile, { savedAt: Date.now(), s: this.s }); } catch (err) { console.error('Could not save game state:', err.message); }
  }

  _load() {
    const saved = readJSON(this.persistFile, null);
    if (!saved || !saved.s || !saved.s.phase) return;
    if (saved.s.version !== STATE_VERSION) {
      console.log('Ignoring a saved game from an older version of the rules.');
      return;
    }
    this.s = saved.s;
    this.tokens = new Map(Object.values(this.s.players).map((p) => [p.token, p.id]));
    if (OPEN_PHASES.has(this.s.phase) && this.s.deadline) {
      this.s.pausedRemaining = Math.max(5000, this.s.deadline - saved.savedAt);
      this.s.deadline = null;
      this.s.paused = true;
      this.s.pauseStartedAt = Date.now();
    }
    console.log(`Restored live game ${this.s.code} (phase ${this.s.phase}, ${this.players().length} players).`);
  }

  /* --------------------------------------------------------------- views */
  _questionPublic(withAnswer) {
    const q = this.currentQ;
    if (!q) return null;
    const out = {
      number: this.s.qIndex + 1, text: q.question,
      options: { A: q.optionA, B: q.optionB, C: q.optionC, D: q.optionD },
      category: q.category, difficulty: q.difficulty,
    };
    if (withAnswer) { out.correct = q.correctAnswer; out.explanation = q.explanation; }
    return out;
  }

  _distribution() {
    const e = this.entry;
    if (!e || !e.counts) return null;
    const answered = OPTS.reduce((n, o) => n + e.counts[o], 0);
    const pct = {};
    OPTS.forEach((o) => { pct[o] = answered ? Math.round((e.counts[o] / answered) * 100) : 0; });
    return { pct, answered, noAnswer: e.counts.none, total: e.ids.length };
  }

  _common() {
    const s = this.s;
    const ph = s.phase;
    const revealed = REVEALED.has(ph);
    const e = this.entry;
    const answeredCount = e && OPEN_PHASES.has(ph) ? e.ids.filter((id) => s.players[id] && s.players[id].answers[s.qIndex]).length : null;
    const o = ph === P.EXIT_DECISION || ph === P.EXIT_RESULT ? this.currentOffer() : null;
    return {
      kind: this.kind,
      code: s.code,
      gameName: this.cfg.gameName,
      tagline: this.cfg.tagline,
      phase: ph,
      paused: s.paused,
      serverNow: Date.now(),
      qIndex: s.qIndex,
      qNumber: s.qIndex + 1,
      qTotal: this.qCount,
      isFinal: s.qIndex >= 0 && this.isFinal,
      timerSecs: s.qIndex >= 0 ? this.timerFor(s.qIndex) : null,
      deadline: s.deadline,
      pausedRemaining: s.pausedRemaining,
      question: QUESTION_VISIBLE.has(ph) ? this._questionPublic(revealed) : null,
      distribution: DIST_VISIBLE.has(ph) ? this._distribution() : null,
      result: revealed && e ? {
        correct: e.correct, survived: e.survived, eliminated: e.eliminated,
        activeAtStart: e.activeAtStart, tricked: e.tricked, noAnswer: e.noAnswer,
        speedOut: !!e.speedOut, speedTie: e.speedTie, left: e.left,
      } : null,
      lockReason: e && e.lockReason,
      remaining: this.active().length,
      joined: this.players().length,
      answered: answeredCount,
      answering: e && OPEN_PHASES.has(ph) ? e.ids.filter((id) => s.players[id]?.status === 'active').length : null,
      speed: {
        on: s.speed.on,
        fromQ: s.speed.fromQ,
        thisQuestion: !!(e && e.speedRule),
        // On the "get ready" screen: does the speed rule apply to the question about to start,
        // and is this the first question it applies to (so the rule change is announced)?
        readyApplies: ph === P.QUESTION_READY && this.speedAppliesTo(s.qIndex + 1),
        isNew: ph === P.QUESTION_READY && this.speedAppliesTo(s.qIndex + 1) && s.speed.fromQ === s.qIndex + 1,
        source: s.speed.source,
      },
      exitOffer: o ? {
        no: o.no, question: o.question, amountPaise: o.amountPaise,
        offered: o.offeredTo.length,
        decided: o.offeredTo.filter((id) => s.players[id]?.exitDecisions[o.question]).length,
        confirmed: o.confirmed,
        ruleChange: o.no === 2 && s.speed.on && s.speed.source === 'offer' && s.speed.fromQ === o.question + 1,
      } : null,
      allowLateJoin: s.allowLateJoin,
      complete: ph === P.GAME_COMPLETE ? {
        reason: s.final.reason, mode: s.final.mode,
        winners: s.final.winners.map((id) => s.players[id]?.name).filter(Boolean),
        finalPoolPaise: s.final.finalPoolPaise, eachPaise: s.final.eachPaise,
        recipients: s.final.recipients.length, lastQuestion: s.final.lastQuestion || null,
      } : null,
    };
  }

  playerView(p) {
    const c = this._common();
    const s = this.s;
    const e = this.entry;
    const inQ = !!(e && e.ids.includes(p.id));
    const myAnswer = s.qIndex >= 0 ? p.answers[s.qIndex] || null : null;
    const o = c.exitOffer ? this.currentOffer() : null;
    const view = {
      ...c,
      me: {
        id: p.id, name: p.name, status: p.status,
        eliminatedAt: p.eliminatedAt, eliminatedReason: p.eliminatedReason,
        exitedAt: p.exitedAt, winner: !!p.winner,
        inQuestion: inQ, answer: inQ ? myAnswer : null,
        exitDecision: e ? p.exitDecisions[e.number] || null : null,
        offered: !!(o && o.offeredTo.includes(p.id)),
        stayedThisQuestion: !!(e && e.offer && this.offer(e.offer)?.stayers.includes(p.id)),
        leftThisQuestion: p.exitedAt != null && e && p.exitedAt === e.number,
      },
    };
    if (c.result && inQ && !view.me.leftThisQuestion) {
      view.me.result = p.eliminatedReason === 'slowest' && p.eliminatedAt === e.number ? 'slowest'
        : myAnswer === c.result.correct ? 'correct' : myAnswer ? 'wrong' : 'no-answer';
    }
    if (!view.me.offered && view.exitOffer) view.exitOffer = { no: view.exitOffer.no, ruleChange: view.exitOffer.ruleChange };
    if (view.complete) view.complete = { reason: view.complete.reason, mode: view.complete.mode, winners: view.complete.winners };
    delete view.joined;
    delete view.answering;
    return view;
  }

  hostView() {
    const s = this.s;
    const c = this._common();
    const editable = s.phase === P.SETUP || s.phase === P.LOBBY;
    const e = this.entry;
    const totalPaise = prize.toPaise(this.cfg.totalPrize);
    const o = this.currentOffer();
    return {
      ...c,
      validation: editable ? this.validation() : null,
      store: editable ? { config: this.store.config, questions: this.store.questions } : null,
      players: this.players().map((p) => ({ id: p.id, name: p.name, status: p.status, isBot: p.isBot })),
      dots: (s.dotOrder.length ? s.dotOrder : s.joinOrder).map((id) => {
        const p = s.players[id];
        return p ? (p.status === 'active' ? 1 : p.status === 'exited' ? 2 : 0) : 0;
      }),
      startingPlayers: s.startingPlayers,
      offerDue: s.phase === P.QUESTION_LOCKED && !!(e && e.offer && !e.offerDone),
      offerNoDue: e && e.offer && !e.offerDone ? e.offer : null,
      finalThinking: s.phase === P.FINAL_QUESTION && e ? e.ids.map((id) => s.players[id]).filter((p) => p && p.status === 'active')
        .map((p) => ({ name: p.name, answered: !!p.answers[s.qIndex] })) : null,
      prize: {
        totalPaise, paidPaise: s.paidPaise, poolPaise: totalPaise - s.paidPaise,
        exitAmountPaise: prize.toPaise(this.cfg.exitAmount),
        maxExitPaise: prize.toPaise(this.cfg.exitAmount) * (this.cfg.firstOfferAt + this.cfg.secondOfferAt),
      },
      exitResult: s.phase === P.EXIT_RESULT && o ? { left: o.leavers.length, stayed: o.stayers.length, undecided: o.undecided } : null,
      activeNames: s.phase === P.ACTIVE_LIST ? this.active().map((p) => p.name).sort((x, y) => x.localeCompare(y, 'en', { sensitivity: 'base' })) : null,
      activeListDue: (() => {
        const every = this.cfg.showActiveEvery;
        return !!every && s.qIndex >= 0 && !this.isFinal && (s.qIndex + 1) % every === 0
          && !s.activeListShown[s.qIndex] && this.active().length > 0;
      })(),
      results: s.phase === P.GAME_COMPLETE ? this.results() : null,
    };
  }

  results() {
    const s = this.s;
    if (!s.config) return null;
    const qs = s.questions;
    const name = (id) => s.players[id]?.name;
    const lastEntry = s.history[qs.length - 1];
    return {
      totalPlayers: this.players().length,
      startingPlayers: s.startingPlayers,
      questions: s.history.filter(Boolean).map((e) => {
        const answered = e.counts ? OPTS.reduce((n, o) => n + e.counts[o], 0) : 0;
        return {
          number: e.number, text: qs[e.qIndex].question, category: qs[e.qIndex].category,
          correct: qs[e.qIndex].correctAnswer, activeAtStart: e.activeAtStart,
          counts: e.counts, answered, survived: e.survived, eliminated: e.eliminated,
          noAnswer: e.noAnswer, tricked: e.tricked, offer: e.offer, left: e.left,
          speedRule: e.speedRule, speedOut: e.speedOut ? name(e.speedOut) : null, speedTie: e.speedTie,
          correctPct: e.activeAtStart && e.counts ? Math.round((((e.counts[qs[e.qIndex].correctAnswer]) || 0) / e.activeAtStart) * 100) : null,
        };
      }),
      offers: s.offers.map((o) => ({
        no: o.no, question: o.question, amountPaise: o.amountPaise, offered: o.offeredTo.length,
        left: o.leavers.length, stayedCorrect: o.stayCorrect.length, stayedWrong: o.stayWrong.length,
        paidPaise: o.paidLeavePaise + o.paidStayPaise,
        leaverNames: o.leavers.map(name), stayCorrectNames: o.stayCorrect.map(name),
      })),
      speed: s.speed,
      reachedFinal: lastEntry ? lastEntry.activeAtStart : 0,
      finalCorrect: lastEntry && lastEntry.counts ? lastEntry.counts[qs[qs.length - 1].correctAnswer] || 0 : 0,
      final: s.final && {
        ...s.final,
        winnerNames: s.final.winners.map(name),
        recipientNames: s.final.recipients.map(name),
      },
      payouts: this.players().flatMap((p) => [
        ...p.awards.map((a) => ({ name: p.name, type: a.type === 'left' ? `Left with exit offer at Q${a.q}` : `Stayed and correct at Q${a.q}`, amountPaise: a.paise, isBot: p.isBot })),
        ...(p.prizePaise ? [{ name: p.name, type: p.winner ? 'Final prize (winner)' : 'Final prize (no-winner rule share)', amountPaise: p.prizePaise, isBot: p.isBot }] : []),
      ]),
      players: this.players().map((p) => ({
        name: p.name, status: p.winner ? 'winner' : p.status, eliminatedAt: p.eliminatedAt,
        eliminatedReason: p.eliminatedReason, exitedAt: p.exitedAt, totalPaise: p.awardPaise + p.prizePaise, isBot: p.isBot,
      })),
    };
  }
}

module.exports = { GameRoom, P, OPTS, STATE_VERSION };
