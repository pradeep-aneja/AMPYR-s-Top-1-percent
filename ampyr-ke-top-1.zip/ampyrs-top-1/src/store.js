'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CONFIG_VERSION = 3;
const DEFAULT_CONFIG = {
  configVersion: CONFIG_VERSION,
  gameName: 'AMPYR ke Top 1%',
  tagline: 'Think differently. Beat the room.',
  totalPrize: 10000,
  questionCount: 13,
  timerSecs: 60,          // every question, including the final
  exitAmount: 1000,       // paid to each leaver, and to each stayer who answers correctly
  firstOfferAt: 5,        // first exit offer: first question that starts with this many players or fewer
  secondOfferAt: 3,       // second exit offer: a later question that starts with this many or fewer
  showActiveEvery: 5,     // names still in the game after every 5th question (0 = never)
  playerLimit: 100,
  loneSurvivorQuestion: 'next', // one player left: 'next' question becomes the last, or jump to the 'final' question
};

const QUESTION_FIELDS = [
  'id', 'questionNumber', 'question', 'optionA', 'optionB', 'optionC', 'optionD',
  'correctAnswer', 'explanation', 'category', 'difficulty', 'timer', 'trapAnswer',
];

function writeAtomic(file, data) {
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}

function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function cleanText(v, max) {
  return String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}

function sanitizeQuestion(q, i) {
  const out = {};
  out.id = cleanText(q.id, 40) || 'q' + crypto.randomBytes(4).toString('hex');
  out.questionNumber = i + 1;
  out.question = cleanText(q.question, 600);
  for (const k of ['optionA', 'optionB', 'optionC', 'optionD']) out[k] = cleanText(q[k], 160);
  out.correctAnswer = ['A', 'B', 'C', 'D'].includes(q.correctAnswer) ? q.correctAnswer : '';
  out.explanation = cleanText(q.explanation, 1200);
  out.category = cleanText(q.category, 60);
  out.difficulty = cleanText(q.difficulty, 40);
  const t = q.timer === '' || q.timer == null ? null : Number(q.timer);
  out.timer = Number.isFinite(t) ? Math.round(t) : null;
  out.trapAnswer = ['A', 'B', 'C', 'D'].includes(q.trapAnswer) ? q.trapAnswer : null;
  return out;
}

function sanitizeConfig(c) {
  const d = DEFAULT_CONFIG;
  const num = (v, def) => (v === '' || v == null || !Number.isFinite(Number(v)) ? def : Number(v));
  const int = (v, def) => Math.round(num(v, def));
  return {
    configVersion: CONFIG_VERSION,
    gameName: cleanText(c.gameName ?? d.gameName, 40),
    tagline: cleanText(c.tagline ?? d.tagline, 80),
    totalPrize: num(c.totalPrize, d.totalPrize),
    questionCount: int(c.questionCount, d.questionCount),
    timerSecs: int(c.timerSecs, d.timerSecs),
    exitAmount: num(c.exitAmount, d.exitAmount),
    firstOfferAt: int(c.firstOfferAt, d.firstOfferAt),
    secondOfferAt: int(c.secondOfferAt, d.secondOfferAt),
    showActiveEvery: int(c.showActiveEvery, d.showActiveEvery),
    playerLimit: int(c.playerLimit, d.playerLimit),
    loneSurvivorQuestion: c.loneSurvivorQuestion === 'final' ? 'final' : 'next',
  };
}

class Store {
  constructor(dir) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
    this.configFile = path.join(dir, 'config.json');
    this.questionsFile = path.join(dir, 'questions.json');
    this.defaultQuestionsFile = fs.existsSync(path.join(dir, 'questions.default.json'))
      ? path.join(dir, 'questions.default.json')
      : path.join(__dirname, '..', 'data', 'questions.default.json');
    // Settings saved by an older version of the rules are replaced by the new defaults.
    const saved = readJSON(this.configFile, {});
    let base = DEFAULT_CONFIG;
    if (saved.configVersion === CONFIG_VERSION) base = { ...DEFAULT_CONFIG, ...saved };
    else if (saved.configVersion === 2) {
      // v2 → v3: keep the host's settings; the old default player limit of 40 becomes 100.
      base = { ...DEFAULT_CONFIG, ...saved, playerLimit: saved.playerLimit === 40 || saved.playerLimit == null ? 100 : saved.playerLimit };
    }
    this.config = sanitizeConfig(base);
    const qs = readJSON(this.questionsFile, null) || readJSON(this.defaultQuestionsFile, []);
    this.questions = qs.map(sanitizeQuestion);
  }
  saveConfig(c) {
    this.config = sanitizeConfig({ ...this.config, ...c });
    writeAtomic(this.configFile, this.config);
    return this.config;
  }
  saveQuestions(list) {
    if (!Array.isArray(list)) throw new Error('Questions must be a list.');
    if (list.length > 60) throw new Error('A maximum of 60 questions can be stored.');
    this.questions = list.map(sanitizeQuestion);
    writeAtomic(this.questionsFile, this.questions);
    return this.questions;
  }
  restoreDefaultQuestions() {
    this.questions = readJSON(this.defaultQuestionsFile, []).map(sanitizeQuestion);
    writeAtomic(this.questionsFile, this.questions);
    return this.questions;
  }
  restoreDefaultConfig() {
    this.config = sanitizeConfig(DEFAULT_CONFIG);
    writeAtomic(this.configFile, this.config);
    return this.config;
  }
}

module.exports = { Store, DEFAULT_CONFIG, QUESTION_FIELDS, sanitizeQuestion, cleanText, writeAtomic, readJSON };
