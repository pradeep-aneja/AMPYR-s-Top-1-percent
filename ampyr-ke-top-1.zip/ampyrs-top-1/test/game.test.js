'use strict';
const test = require('node:test');
const assert = require('node:assert');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { Store } = require('../src/store');
const { GameRoom } = require('../src/game');
const prize = require('../src/prize');

function freshStore(cfg) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 't1-'));
  fs.copyFileSync(path.join(__dirname, '..', 'data', 'questions.default.json'), path.join(dir, 'questions.default.json'));
  const st = new Store(dir);
  if (cfg) st.saveConfig(cfg);
  return st;
}
function must(r) { assert.ok(r.ok, r.error); return r; }
const WRONG = (q) => (q.correctAnswer === 'A' ? 'B' : 'A');

/** Set up a started game with n players named "PlayerN Surname". */
function game(n, cfg) {
  const st = freshStore(cfg);
  const g = new GameRoom({ kind: 'live', store: st });
  must(g.action('OPEN_LOBBY'));
  const ids = [];
  for (let i = 0; i < n; i++) ids.push(must(g.join({ name: `Player${i} Surname` })).playerId);
  must(g.action('START_GAME'));
  return { g, st, ids };
}

/**
 * Play the current question. plan(id) → 'right' | 'wrong' | 'none'.
 * times: {id: ms} sets server-measured answer times (for the speed rule).
 * decide: {id: 'exit'|'continue'} used if an exit offer is due.
 */
function play(g, plan, { times = {}, decide = {} } = {}) {
  must(g.action('START_QUESTION'));
  const q = g.currentQ;
  for (const p of g.active()) {
    const what = plan(p.id);
    if (what === 'none') continue;
    must(g.answer(p.id, what === 'right' ? q.correctAnswer : WRONG(q)));
    if (times[p.id] != null) p.answerMs[g.s.qIndex] = times[p.id];
  }
  must(g.action('LOCK_ANSWERS'));
  let offered = null;
  if (g.entry.offer && !g.entry.offerDone) {
    offered = g.entry.offer;
    must(g.action('OFFER_EXIT'));
    for (const [id, c] of Object.entries(decide)) if (g.currentOffer().offeredTo.includes(id)) must(g.decideExit(id, c));
    must(g.action('CONFIRM_EXIT'));
  }
  must(g.action('SHOW_ROOM'));
  must(g.action('REVEAL_ANSWER'));
  must(g.action('SHOW_SURVIVORS'));
  return offered;
}

test('defaults: renamed game, 60 s everywhere, ₹1,000 offers, list every 5', () => {
  const st = freshStore();
  assert.strictEqual(st.config.gameName, 'AMPYR ke Top 1%');
  assert.strictEqual(st.config.timerSecs, 60);
  assert.strictEqual(st.config.exitAmount, 1000);
  assert.strictEqual(st.config.firstOfferAt, 5);
  assert.strictEqual(st.config.secondOfferAt, 3);
  assert.strictEqual(st.config.showActiveEvery, 5);
  assert.strictEqual(st.config.playerLimit, 100);
  assert.strictEqual(st.config.noWinnerRule, undefined, 'the no-winner setting is gone');
  const v = prize.validateGame(st.config, st.questions);
  assert.deepStrictEqual(v.errors, []);
  assert.ok(v.warnings[0].includes('at most ₹8,000') && v.warnings[0].includes('at least ₹2,000'));
});

test('settings from the old version are replaced by the new defaults', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 't1-'));
  fs.writeFileSync(path.join(dir, 'config.json'), JSON.stringify({ gameName: "AMPYR'S TOP 1%", exitAfterQ2: 2000, timerEarly: 30 }));
  const st = new Store(dir);
  assert.strictEqual(st.config.gameName, 'AMPYR ke Top 1%');
  assert.strictEqual(st.config.timerSecs, 60);
});

test('invalid offer settings are blocked', () => {
  const st = freshStore();
  assert.ok(prize.validateGame({ ...st.config, firstOfferAt: 3, secondOfferAt: 3 }, st.questions).errors.some((e) => e.includes('fewer players than the first')));
  assert.ok(prize.validateGame({ ...st.config, exitAmount: 1250 }, st.questions).errors.some((e) => e.includes('leaving nothing')));
});

test('join: full name only, duplicates refused', () => {
  const st = freshStore();
  const g = new GameRoom({ kind: 'live', store: st });
  must(g.action('OPEN_LOBBY'));
  assert.strictEqual(g.join({ name: 'Pradeep' }).ok, false);
  must(g.join({ name: '  Asha   Verma ' }));
  assert.strictEqual(g.s.players[g.s.joinOrder[0]].name, 'Asha Verma');
  assert.strictEqual(g.join({ name: 'asha verma' }).ok, false);
  assert.strictEqual(g.players()[0].dept, undefined);
});

test('every question, including the final, has a 60 s timer', () => {
  const { g } = game(2, { questionCount: 3 });
  for (let i = 0; i < 3; i++) assert.strictEqual(g.timerFor(i), 60);
  g.s.qIndex = 2;
  must(g.action('START_QUESTION'));
  assert.strictEqual(g.s.phase, 'FINAL_QUESTION');
  assert.ok(g.s.deadline > Date.now() + 59000);
  g._clearTimers();
});

test('offer 1 at ≤5 players, offer 2 on a later question at ≤3; leave / stay-right / stay-wrong', () => {
  const { g, ids } = game(8);
  assert.strictEqual(play(g, (id) => (ids.indexOf(id) < 3 ? 'wrong' : 'right')), null);
  assert.strictEqual(g.active().length, 5);
  must(g.action('NEXT_QUESTION'));
  const [p3, p4, p5, p6, p7] = ids.slice(3);
  const plan = { [p3]: 'wrong', [p4]: 'right', [p5]: 'wrong', [p6]: 'none', [p7]: 'right' };
  must(g.action('START_QUESTION'));
  const q = g.currentQ;
  assert.strictEqual(g.entry.offer, 1);
  for (const [id, w] of Object.entries(plan)) if (w !== 'none') must(g.answer(id, w === 'right' ? q.correctAnswer : WRONG(q)));
  must(g.action('LOCK_ANSWERS'));
  assert.strictEqual(g.action('SHOW_ROOM').ok, false, 'offer must come before the reveal');
  must(g.action('OFFER_EXIT'));
  const o = g.currentOffer();
  assert.ok(!o.offeredTo.includes(p6), 'non-answerers are not offered');
  assert.strictEqual(g.decideExit(p6, 'exit').ok, false);
  assert.strictEqual(g.playerView(g.s.players[p3]).question.correct, undefined, 'answer stays hidden during the offer');
  must(g.decideExit(p3, 'exit'));
  must(g.decideExit(p4, 'continue'));
  must(g.decideExit(p5, 'continue'));
  assert.strictEqual(g.decideExit(p3, 'continue').ok, false, 'decision is final');
  must(g.action('CONFIRM_EXIT'));
  assert.strictEqual(g.s.players[p3].status, 'exited');
  must(g.action('SHOW_ROOM'));
  must(g.action('REVEAL_ANSWER'));
  assert.strictEqual(g.s.players[p3].awardPaise, 100000, 'leaver gets ₹1,000 even though wrong');
  assert.strictEqual(g.s.players[p4].awardPaise, 100000, 'stay + right banks ₹1,000');
  assert.strictEqual(g.s.players[p7].awardPaise, 100000, 'undecided counts as stay');
  assert.strictEqual(g.s.players[p5].status, 'eliminated');
  assert.strictEqual(g.s.players[p5].awardPaise, 0, 'stay + wrong gets nothing');
  assert.strictEqual(g.s.players[p6].eliminatedReason, 'no-answer');
  assert.strictEqual(g.s.paidPaise, 300000);
  assert.strictEqual(g.playerView(g.s.players[p3]).me.leftThisQuestion, true);
  must(g.action('SHOW_SURVIVORS'));
  must(g.action('NEXT_QUESTION'));
  assert.strictEqual(play(g, () => 'right', { decide: { [p4]: 'continue', [p7]: 'continue' } }), 2);
  assert.strictEqual(g.s.speed.on, true);
  assert.strictEqual(g.s.speed.fromQ, 4);
  assert.strictEqual(g.s.speed.source, 'offer');
  assert.strictEqual(g.entry.speedOut, null, 'speed rule does not apply to the question it is announced on');
  assert.strictEqual(g.s.players[p4].awardPaise, 200000, 'can bank at both offers');
  assert.strictEqual(g.s.paidPaise, 500000);
});

test('a jump from >5 to ≤3 gives offer 1 now and offer 2 on the next question', () => {
  const { g, ids } = game(8);
  play(g, (id) => (ids.indexOf(id) < 6 ? 'wrong' : 'right'));
  must(g.action('NEXT_QUESTION'));
  assert.strictEqual(play(g, () => 'right'), 1);
  must(g.action('NEXT_QUESTION'));
  assert.strictEqual(play(g, () => 'right'), 2);
});

test('speed rule: slowest out only when all right and 2+ playing; ties keep everyone; never the last player', () => {
  const { g, ids } = game(4, { firstOfferAt: 2, secondOfferAt: 1 });
  must(g.action('SET_SPEED_RULE', { value: true }));
  assert.strictEqual(g.s.speed.fromQ, 1, 'switched on before Q1 starts → applies to Q1');
  play(g, () => 'right', { times: { [ids[0]]: 5000, [ids[1]]: 9000, [ids[2]]: 30000, [ids[3]]: 12000 } });
  assert.strictEqual(g.s.players[ids[2]].eliminatedReason, 'slowest');
  assert.strictEqual(g.active().length, 3);
  must(g.action('NEXT_QUESTION'));
  play(g, (id) => (id === ids[3] ? 'wrong' : 'right'), { times: { [ids[0]]: 50000, [ids[1]]: 1000 } });
  assert.strictEqual(g.active().length, 2);
  assert.strictEqual(g.entry.speedOut, null, 'someone was wrong, so nobody goes on speed');
  must(g.action('NEXT_QUESTION'));
  play(g, () => 'right', { times: { [ids[0]]: 7000, [ids[1]]: 7000 } });
  assert.strictEqual(g.entry.speedTie, true);
  assert.strictEqual(g.active().length, 2);
  must(g.action('NEXT_QUESTION'));
  play(g, () => 'right', { times: { [ids[0]]: 8000, [ids[1]]: 3000 } });
  assert.strictEqual(g.active().length, 1);
  must(g.action('NEXT_QUESTION'));
  play(g, () => 'right');
  assert.strictEqual(g.active().length, 1, 'a lone player is never out for being slowest');
});

test('host switching the speed rule on mid-question applies it from the next question', () => {
  const { g } = game(3);
  must(g.action('START_QUESTION'));
  must(g.action('SET_SPEED_RULE', { value: true }));
  assert.strictEqual(g.s.speed.fromQ, 2);
  assert.strictEqual(g.entry.speedRule, false);
  g._clearTimers();
});

test('final: speed rule leaves one winner; payouts never exceed the prize; phones get no money', () => {
  const { g, ids } = game(6);
  must(g.action('SET_SPEED_RULE', { value: true }));
  for (let i = 0; i < 13; i++) {
    const times = Object.fromEntries(g.active().map((p, k) => [p.id, 1000 + k * 100 + i]));
    play(g, () => 'right', { times });
    if (g.isFinal) break;
    must(g.action('NEXT_QUESTION'));
  }
  must(g.action('DISTRIBUTE_FINAL'));
  const f = g.s.final;
  assert.strictEqual(f.mode, 'winners');
  assert.strictEqual(f.winners.length, 1);
  assert.ok(f.reconciled && f.paidPaise <= 1000000);
  assert.ok(g.s.paidPaise <= 800000);
  const pv = JSON.stringify(g.playerView(g.s.players[ids[0]]));
  assert.ok(!/awardPaise|prizePaise|finalPoolPaise|eachPaise|"token"/.test(pv));
});

test('worst case: everyone collects at both offers → ₹8,000 paid, final pool ₹2,000', () => {
  const { g } = game(5);
  play(g, () => 'right');
  assert.strictEqual(g.s.paidPaise, 500000);
  must(g.action('NEXT_QUESTION'));
  const act = g.active().map((p) => p.id);
  play(g, (id) => (act.indexOf(id) < 2 ? 'wrong' : 'right'));
  must(g.action('NEXT_QUESTION'));
  play(g, () => 'right');
  assert.strictEqual(g.s.paidPaise, 800000);
});

test('names still in are listed after every 5th question', () => {
  const { g } = game(30, { firstOfferAt: 2, secondOfferAt: 1 });
  const shown = [];
  for (let i = 0; i < 12; i++) {
    play(g, () => 'right');
    if (g.hostView().activeListDue) {
      must(g.action('SHOW_ACTIVE'));
      assert.strictEqual(g.hostView().activeNames.length, g.active().length);
      assert.strictEqual(g.playerView(g.active()[0]).activeNames, undefined);
      shown.push(i + 1);
    }
    must(g.action('NEXT_QUESTION'));
  }
  assert.deepStrictEqual(shown, [5, 10]);
});

test('no winner: the final prize is not awarded', () => {
  const { g, ids } = game(2, { questionCount: 3, firstOfferAt: 2, secondOfferAt: 1 });
  play(g, () => 'none');
  assert.strictEqual(g.active().length, 0);
  must(g.action('DISTRIBUTE_FINAL'));
  const f = g.s.final;
  assert.strictEqual(f.mode, 'retained');
  assert.strictEqual(f.retainedPaise, 1000000);
  assert.ok(f.reconciled);
  assert.deepStrictEqual(Object.keys(g.playerView(g.s.players[ids[0]]).complete).sort(), ['mode', 'reason', 'winners']);
});

test('one player left: the next question is their last; right wins, wrong means no winner', () => {
  for (const outcome of ['right', 'wrong']) {
    const { g, ids } = game(3, { firstOfferAt: 2, secondOfferAt: 1 });
    play(g, (id) => (id === ids[0] ? 'right' : 'wrong'));  // Q1: 3 → 1
    assert.strictEqual(g.active().length, 1);
    must(g.action('NEXT_QUESTION'));
    assert.strictEqual(g.s.qIndex, 1, 'Q2 is asked');
    assert.ok(g.isFinal && g.s.loneStand, 'and it is the last question');
    assert.strictEqual(g.playerView(g.s.players[ids[0]]).loneStand, true);
    assert.strictEqual(g.join({ name: 'Late Person' }).ok, false);
    play(g, () => outcome, { decide: { [ids[0]]: 'continue' } });
    assert.strictEqual(g.action('NEXT_QUESTION').ok, false, 'no more questions after the last one');
    must(g.action('DISTRIBUTE_FINAL'));
    const f = g.s.final;
    if (outcome === 'right') {
      assert.strictEqual(f.mode, 'winners');
      assert.deepStrictEqual(g.hostView().complete.winners, ['Player0 Surname']);
      assert.strictEqual(g.playerView(g.s.players[ids[0]]).me.winner, true);
    } else {
      assert.strictEqual(f.mode, 'retained');
      assert.strictEqual(g.s.players[ids[0]].status, 'eliminated');
    }
    assert.ok(f.reconciled);
    assert.strictEqual(g.results().lastQuestionNumber, 2);
  }
});

test('one player left with the "final question" setting: jumps to Q13', () => {
  const { g, ids } = game(2, { loneSurvivorQuestion: 'final' });
  play(g, (id) => (id === ids[0] ? 'right' : 'wrong'));
  must(g.action('NEXT_QUESTION'));
  assert.strictEqual(g.s.qIndex, 12);
  assert.ok(g.isFinal);
  play(g, () => 'right');
  must(g.action('DISTRIBUTE_FINAL'));
  assert.strictEqual(g.s.final.mode, 'winners');
});

test('a game that starts with one player goes straight to their last question', () => {
  const { g } = game(1);
  assert.ok(g.isFinal && g.s.loneStand && g.s.qIndex === 0);
});

test('v2 settings migrate: player limit 40 becomes 100, other choices kept', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 't1-'));
  fs.writeFileSync(path.join(dir, 'config.json'), JSON.stringify({ configVersion: 2, playerLimit: 40, timerSecs: 45, noWinnerRule: 'retained' }));
  const st = new Store(dir);
  assert.strictEqual(st.config.playerLimit, 100);
  assert.strictEqual(st.config.timerSecs, 45);
  assert.strictEqual(st.config.noWinnerRule, undefined);
});

test('timer auto-locks a question and silence is wrong', async () => {
  const { g } = game(1, { timerSecs: 5 });
  must(g.action('START_QUESTION'));
  await new Promise((r) => setTimeout(r, 5600));
  assert.strictEqual(g.s.phase, 'QUESTION_LOCKED');
  assert.strictEqual(g.entry.lockReason, 'timeup');
  must(g.action('REVEAL_ANSWER'));
  assert.strictEqual(g.active().length, 0);
});

test('pause stops the clock and is not counted as thinking time', () => {
  const { g, ids } = game(1);
  must(g.action('START_QUESTION'));
  must(g.action('PAUSE'));
  assert.strictEqual(g.answer(ids[0], 'B').ok, false);
  g.s.pauseStartedAt -= 4000;
  must(g.action('RESUME'));
  assert.ok(g.entry.pausedMs >= 4000);
  must(g.answer(ids[0], 'B'));
  assert.ok(g.s.players[ids[0]].answerMs[0] < 1000);
  g._clearTimers();
});

test('demo players play a whole game to the end', async () => {
  const st = freshStore({ timerSecs: 5, playerLimit: 100 });
  const g = new GameRoom({ kind: 'demo', store: st });
  must(g.action('OPEN_LOBBY'));
  must(g.action('ADD_BOTS', { count: 40 }));
  must(g.action('START_GAME'));
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  for (let qi = 0; qi < 13; qi++) {
    must(g.action('START_QUESTION'));
    await wait(5700);
    if (g.entry.offer && !g.entry.offerDone) {
      must(g.action('OFFER_EXIT'));
      await wait(4800);
      must(g.action('CONFIRM_EXIT'));
    }
    must(g.action('REVEAL_ANSWER'));
    must(g.action('SHOW_SURVIVORS'));
    if (qi === 12 || !g.active().length) break;
    must(g.action('NEXT_QUESTION'));
  }
  must(g.action('DISTRIBUTE_FINAL'));
  assert.ok(g.s.final.reconciled);
  console.log('    demo:', g.s.final.mode, 'winners', g.s.final.winners.length,
    '| offers at Q', g.s.offers.map((o) => o.question).join(','),
    '| paid ₹', g.s.paidPaise / 100, '| speed from Q', g.s.speed.fromQ);
});
