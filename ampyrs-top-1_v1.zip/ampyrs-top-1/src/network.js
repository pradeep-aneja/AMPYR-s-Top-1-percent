'use strict';
const os = require('os');

const VIRTUAL = /(vethernet|vmware|virtualbox|vbox|docker|br-|veth|hyper-v|loopback|tailscale|zerotier|utun|awdl|llw|wsl|hamachi|npcap)/i;

function scoreAddress(name, ip) {
  let s = 0;
  if (/^192\.168\./.test(ip)) s += 30;
  else if (/^10\./.test(ip)) s += 20;
  else if (/^172\.(1[6-9]|2\d|3[01])\./.test(ip)) s += 10;
  else if (/^169\.254\./.test(ip)) s -= 50; // link-local: no DHCP, usually wrong
  if (/(wi-?fi|wlan|wlp|en0|wireless|airport)/i.test(name)) s += 15;
  if (/(ethernet|eth|enp|en\d)/i.test(name)) s += 8;
  if (VIRTUAL.test(name)) s -= 40;
  return s;
}

/** All candidate IPv4 LAN addresses, best first. */
function candidateAddresses() {
  const out = [];
  const ifaces = os.networkInterfaces();
  for (const [name, list] of Object.entries(ifaces)) {
    for (const a of list || []) {
      const fam = typeof a.family === 'string' ? a.family : a.family === 4 ? 'IPv4' : 'IPv6';
      if (fam !== 'IPv4' || a.internal) continue;
      out.push({ name, ip: a.address, score: scoreAddress(name, a.address) });
    }
  }
  out.sort((a, b) => b.score - a.score);
  return out;
}

module.exports = { candidateAddresses };
