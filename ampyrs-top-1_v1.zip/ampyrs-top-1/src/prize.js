'use strict';
/**
 * PRIZE ENGINE
 * All money is handled internally in integer paise so rounding can never
 * push the total paid above the configured prize pool.
 *
 * Rules (see README "Prize rules"):
 *  - Final prize pool = Total prize − all exit payouts actually paid.
 *  - An exit offer is a per-player amount (e.g. ₹2,000).
 *  - Each exit round may use at most `exitCapPct` % of the pool remaining at
 *    that moment (the "exit fund"). If the players who exit would together
 *    exceed that fund, the fund is shared equally among them.
 *  - Final winners split the final pool equally, floored to the paisa.
 *    Any leftover paise (at most winners−1) are reported as rounding residue.
 */

const toPaise = (rupees) => Math.round(Number(rupees) * 100);
const toRupees = (paise) => Math.round(paise) / 100;

function formatINR(paise) {
  const r = toRupees(paise);
  return '₹' + r.toLocaleString('en-IN', {
    minimumFractionDigits: Number.isInteger(r) ? 0 : 2,
    maximumFractionDigits: 2,
  });
}

/** Payout for one exit round. */
function exitRoundPayout({ remainingPaise, amountPaise, exiters, capPct }) {
  if (exiters <= 0 || amountPaise <= 0) {
    return { perPlayerPaise: 0, totalPaise: 0, fundPaise: 0, capped: false };
  }
  const fundPaise = Math.floor((remainingPaise * capPct) / 100);
  const fullCost = amountPaise * exiters;
  if (fullCost <= fundPaise) {
    return { perPlayerPaise: amountPaise, totalPaise: fullCost, fundPaise, capped: false };
  }
  const per = Math.floor(fundPaise / exiters);
  return { perPlayerPaise: per, totalPaise: per * exiters, fundPaise, capped: true };
}

/** Equal split of a pool among n winners, never exceeding the pool. */
function equalSplit(poolPaise, n) {
  if (n <= 0) return { eachPaise: 0, residuePaise: poolPaise };
  const each = Math.floor(poolPaise / n);
  return { eachPaise: each, residuePaise: poolPaise - each * n };
}

/** How many players can take a given exit at full value. */
function fullValueExitCapacity(remainingPaise, amountPaise, capPct) {
  if (amountPaise <= 0) return Infinity;
  return Math.floor(Math.floor((remainingPaise * capPct) / 100) / amountPaise);
}

const NO_WINNER_RULES = {
  split_last_standing: 'Split equally among the players who started the last question played',
  retained: 'Prize stays with the organiser (not awarded)',
};

/**
 * Validate config + questions before a game may start.
 * Returns { errors: string[], warnings: string[] }.
 */
function validateGame(config, questions) {
  const errors = [];
  const warnings = [];
  const c = config || {};
  const n = Number(c.questionCount);

  if (!Number.isInteger(n) || n < 3 || n > 30) {
    errors.push('Question count must be a whole number between 3 and 30.');
  }
  const qs = Array.isArray(questions) ? questions : [];
  if (Number.isInteger(n) && qs.length < n) {
    errors.push(`The game needs ${n} questions but only ${qs.length} exist. Add ${n - qs.length} more in the Questions tab.`);
  }
  qs.slice(0, Number.isInteger(n) ? n : qs.length).forEach((q, i) => {
    const label = `Question ${i + 1}`;
    if (!q || !String(q.question || '').trim()) errors.push(`${label} has no question text.`);
    const opts = ['optionA', 'optionB', 'optionC', 'optionD'].map((k) => String((q && q[k]) || '').trim());
    if (opts.some((o) => !o)) errors.push(`${label} must have exactly four filled options (A–D).`);
    const lower = opts.filter(Boolean).map((o) => o.toLowerCase());
    if (new Set(lower).size !== lower.length) errors.push(`${label} has two identical options.`);
    if (!['A', 'B', 'C', 'D'].includes(q && q.correctAnswer)) errors.push(`${label} needs exactly one correct answer (A, B, C or D).`);
    if (q && q.timer != null && q.timer !== '' && (!Number.isInteger(Number(q.timer)) || q.timer < 5 || q.timer > 600)) {
      errors.push(`${label} has an invalid timer override (use 5–600 seconds, or leave blank to use the default).`);
    }
  });

  const total = toPaise(c.totalPrize);
  const a1 = Number(c.exitOneAfter);
  const a2 = Number(c.exitTwoAfter);
  const e1 = toPaise(c.exitOneAmount);
  const e2 = toPaise(c.exitTwoAmount);
  const cap = Number(c.exitCapPct);
  const okPos = (a) => Number.isInteger(a) && a >= 1 && (!Number.isInteger(n) || a <= n - 1);
  if (!okPos(a1) || !okPos(a2)) {
    errors.push(`Exit offers must come after a question between 1 and ${Number.isInteger(n) ? n - 1 : 'the one before the final'} (there is no exit after the final question).`);
  } else if (a1 >= a2) {
    errors.push(`The first exit (after Q${a1}) must come before the second exit (after Q${a2}).`);
  }

  if (!Number.isFinite(total) || total < 100 || total > toPaise(10000000)) {
    errors.push('Total prize must be between ₹1 and ₹1,00,00,000.');
  }
  if (!(e1 >= 0) || !(e2 >= 0)) errors.push('Exit amounts cannot be negative.');
  if (!Number.isFinite(cap) || cap < 10 || cap > 90) errors.push('Exit fund cap must be between 10% and 90% of the remaining pool.');

  if (errors.length === 0) {
    if (e1 + e2 >= total) {
      errors.push(`Exit amounts (${formatINR(e1)} + ${formatINR(e2)}) leave nothing for the final prize of ${formatINR(total)}.`);
    }
    const fund1 = Math.floor((total * cap) / 100);
    if (e1 > fund1) {
      errors.push(`The exit after Q${a1} (${formatINR(e1)}) is larger than its exit fund (${cap}% of ${formatINR(total)} = ${formatINR(fund1)}). Even one exiting player could not be paid in full.`);
    }
    const worstRemaining = total - (e1 > 0 ? fund1 : 0);
    const fund2Worst = Math.floor((worstRemaining * cap) / 100);
    if (e2 > fund2Worst) {
      errors.push(`The exit after Q${a2} (${formatINR(e2)}) could exceed its exit fund in the worst case (${formatINR(fund2Worst)}). Lower it or raise the cap.`);
    }
    if (e1 > 0) {
      const k = fullValueExitCapacity(total, e1, cap);
      warnings.push(`After Q${a1}, up to ${k} player${k === 1 ? '' : 's'} can exit with the full ${formatINR(e1)}. If more choose to exit, the ${formatINR(fund1)} exit fund is shared equally among them.`);
    }
    if (e2 > 0) {
      const remainingIfNone = total;
      const kBest = fullValueExitCapacity(remainingIfNone, e2, cap);
      const kWorst = fullValueExitCapacity(worstRemaining, e2, cap);
      warnings.push(`After Q${a2}, between ${kWorst} and ${kBest} players can exit with the full ${formatINR(e2)}, depending on how much the first exit paid out. If more choose to exit, the exit fund is shared equally.`);
    }
    if (e1 > 0 && e2 > 0 && e2 < e1) {
      warnings.push(`The later exit (${formatINR(e2)} after Q${a2}) is worth less than the earlier one (${formatINR(e1)} after Q${a1}). Players usually expect the later exit to be worth more.`);
    }
  }

  const early = Number(c.timerEarly);
  const late = Number(c.timerLate);
  if (!Number.isInteger(early) || early < 5 || early > 600) errors.push('Q1–8 timer must be 5–600 seconds.');
  if (!Number.isInteger(late) || late < 5 || late > 600) errors.push('Q9–12 timer must be 5–600 seconds.');

  const every = Number(c.showActiveEvery);
  if (!Number.isInteger(every) || every < 0 || every > 30) errors.push('"Show players still in the game" must be every 0–30 questions (0 switches it off).');

  const limit = Number(c.playerLimit);
  if (!Number.isInteger(limit) || limit < 2 || limit > 200) errors.push('Player limit must be between 2 and 200.');
  if (!NO_WINNER_RULES[c.noWinnerRule]) errors.push('Choose what happens to the prize if nobody wins.');
  if (!String(c.gameName || '').trim()) errors.push('Game name cannot be empty.');

  return { errors, warnings };
}

module.exports = {
  toPaise, toRupees, formatINR, exitRoundPayout, equalSplit,
  fullValueExitCapacity, validateGame, NO_WINNER_RULES,
};
