'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_CONFIG = {
  gameName: "AMPYR'S TOP 1%",
  tagline: 'Think differently. Beat the room.',
  totalPrize: 10000,
  questionCount: 13,
  exitOneAfter: 10,     // first exit offer: after question 10
  exitOneAmount: 1000,
  exitTwoAfter: 12,     // second exit offer: after question 12, just before the final
  exitTwoAmount: 2000,
  exitCapPct: 50,
  showActiveEvery: 3,   // show the names still in the game after every 3rd question (0 = never)
  timerEarly: 30,
  timerLate: 60,
  playerLimit: 40,
  noWinnerRule: 'split_last_standing',
  departments: [
    'Asset Management', 'Commercial', 'Engineering', 'Finance', 'HR',
    'IT', 'Legal', 'Operations', 'Project Development', 'Strategy',
  ],
};

const QUESTION_FIELDS = [
  'id', 'questionNumber', 'question', 'optionA', 'optionB', 'optionC', 'optionD',
  'correctAnswer', 'explanation', 'category', 'difficulty', 'timer', 'trapAnswer',
];

function writeAtomic(file, data) {
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}

function readJSON(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function cleanText(v, max) {
  return String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}

function sanitizeQuestion(q, i) {
  const out = {};
  out.id = cleanText(q.id, 40) || 'q' + crypto.randomBytes(4).toString('hex');
  out.questionNumber = i + 1;
  out.question = cleanText(q.question, 600);
  for (const k of ['optionA', 'optionB', 'optionC', 'optionD']) out[k] = cleanText(q[k], 160);
  out.correctAnswer = ['A', 'B', 'C', 'D'].includes(q.correctAnswer) ? q.correctAnswer : '';
  out.explanation = cleanText(q.explanation, 1200);
  out.category = cleanText(q.category, 60);
  out.difficulty = cleanText(q.difficulty, 40);
  const t = q.timer === '' || q.timer == null ? null : Number(q.timer);
  out.timer = Number.isFinite(t) ? Math.round(t) : null;
  out.trapAnswer = ['A', 'B', 'C', 'D'].includes(q.trapAnswer) ? q.trapAnswer : null;
  return out;
}

function sanitizeConfig(c) {
  const d = DEFAULT_CONFIG;
  const num = (v, def) => (v === '' || v == null || !Number.isFinite(Number(v)) ? def : Number(v));
  const deps = Array.isArray(c.departments)
    ? c.departments.map((x) => cleanText(x, 40)).filter(Boolean).slice(0, 40)
    : d.departments;
  return {
    gameName: cleanText(c.gameName ?? d.gameName, 40),
    tagline: cleanText(c.tagline ?? d.tagline, 80),
    totalPrize: num(c.totalPrize, d.totalPrize),
    questionCount: Math.round(num(c.questionCount, d.questionCount)),
    exitOneAfter: Math.round(num(c.exitOneAfter, d.exitOneAfter)),
    exitOneAmount: num(c.exitOneAmount, d.exitOneAmount),
    exitTwoAfter: Math.round(num(c.exitTwoAfter, d.exitTwoAfter)),
    exitTwoAmount: num(c.exitTwoAmount, d.exitTwoAmount),
    exitCapPct: num(c.exitCapPct, d.exitCapPct),
    showActiveEvery: Math.round(num(c.showActiveEvery, d.showActiveEvery)),
    timerEarly: Math.round(num(c.timerEarly, d.timerEarly)),
    timerLate: Math.round(num(c.timerLate, d.timerLate)),
    playerLimit: Math.round(num(c.playerLimit, d.playerLimit)),
    noWinnerRule: c.noWinnerRule || d.noWinnerRule,
    departments: deps.length ? deps : d.departments,
  };
}

class Store {
  constructor(dir) {
    this.dir = dir;
    fs.mkdirSync(dir, { recursive: true });
    this.configFile = path.join(dir, 'config.json');
    this.questionsFile = path.join(dir, 'questions.json');
    this.defaultQuestionsFile = fs.existsSync(path.join(dir, 'questions.default.json'))
      ? path.join(dir, 'questions.default.json')
      : path.join(__dirname, '..', 'data', 'questions.default.json');
    this.config = sanitizeConfig({ ...DEFAULT_CONFIG, ...readJSON(this.configFile, {}) });
    const qs = readJSON(this.questionsFile, null) || readJSON(this.defaultQuestionsFile, []);
    this.questions = qs.map(sanitizeQuestion);
  }
  saveConfig(c) {
    this.config = sanitizeConfig({ ...this.config, ...c });
    writeAtomic(this.configFile, this.config);
    return this.config;
  }
  saveQuestions(list) {
    if (!Array.isArray(list)) throw new Error('Questions must be a list.');
    if (list.length > 60) throw new Error('A maximum of 60 questions can be stored.');
    this.questions = list.map(sanitizeQuestion);
    writeAtomic(this.questionsFile, this.questions);
    return this.questions;
  }
  restoreDefaultQuestions() {
    this.questions = readJSON(this.defaultQuestionsFile, []).map(sanitizeQuestion);
    writeAtomic(this.questionsFile, this.questions);
    return this.questions;
  }
  restoreDefaultConfig() {
    this.config = sanitizeConfig(DEFAULT_CONFIG);
    writeAtomic(this.configFile, this.config);
    return this.config;
  }
}

module.exports = { Store, DEFAULT_CONFIG, QUESTION_FIELDS, sanitizeQuestion, cleanText, writeAtomic, readJSON };
