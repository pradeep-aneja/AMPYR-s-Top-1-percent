@echo off
title AMPYR'S TOP 1% - game server
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Node.js is not installed on this laptop.
  echo  Install the LTS version from https://nodejs.org ^(needs internet once^), then double-click this file again.
  echo.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing components ^(needs internet once^)...
  call npm install --omit=dev
)
start "" "http://localhost:3000/host"
node server.js
pause
