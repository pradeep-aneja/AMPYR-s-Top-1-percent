#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo ""
  echo "  Node.js is not installed on this Mac."
  echo "  Install the LTS version from https://nodejs.org (needs internet once), then double-click this file again."
  echo ""
  read -n 1 -s -r -p "Press any key to close"
  exit 1
fi
[ -d node_modules ] || npm install --omit=dev
(sleep 1.5 && open "http://localhost:3000/host") &
node server.js
