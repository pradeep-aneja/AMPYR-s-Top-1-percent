'use strict';
/**
 * AMPYR'S TOP 1% — local multiplayer game server.
 * Runs entirely on the host laptop. Phones connect over the local Wi-Fi.
 * No internet connection is needed once `npm install` has been run (the zip
 * already ships with node_modules).
 */
const http = require('http');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { Server } = require('socket.io');
const QRCode = require('qrcode');
const { Store } = require('./src/store');
const { GameRoom } = require('./src/game');
const { candidateAddresses } = require('./src/network');
const { formatINR } = require('./src/prize');

const BASE_PORT = Number(process.env.PORT) || 3000;

/* Cloud mode: the game is reachable on the internet at a public https address.
   PUBLIC_URL can be set explicitly; Render and Railway provide it automatically. */
function detectPublicUrl() {
  const raw = process.env.PUBLIC_URL
    || process.env.RENDER_EXTERNAL_URL
    || (process.env.RAILWAY_PUBLIC_DOMAIN ? `https://${process.env.RAILWAY_PUBLIC_DOMAIN}` : '');
  return raw ? raw.trim().replace(/\/+$/, '') : null;
}
const PUBLIC_URL = detectPublicUrl();
const CLOUD = !!PUBLIC_URL;

if (CLOUD && !/^\d{6,12}$/.test(process.env.HOST_PIN || '')) {
  console.error('\n  HOST_PIN is missing or invalid.');
  console.error('  On the internet the host screen must be protected. Set the environment');
  console.error('  variable HOST_PIN to a number of 6–12 digits that only you know, then redeploy.\n');
  process.exit(1);
}
const HOST_PIN = process.env.HOST_PIN || String(100000 + crypto.randomInt(900000));
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');

const store = new Store(DATA_DIR);
const rooms = {
  live: new GameRoom({ kind: 'live', store, persistFile: path.join(DATA_DIR, 'state-live.json') }),
  demo: new GameRoom({ kind: 'demo', store }),
};
let port = BASE_PORT;
let chosenIp = process.env.HOST_IP || null;

/* ------------------------------------------------------------------ http */
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', true);
app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('Referrer-Policy', 'no-referrer');
  res.set('X-Frame-Options', 'DENY');
  next();
});
app.use(express.json({ limit: '200kb' }));
app.use(express.static(PUBLIC_DIR, { index: false, maxAge: 0 }));
app.get('/', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));
app.get('/host', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'host.html')));
app.get('/health', (req, res) => res.json({ ok: true }));

app.get('/api/qr.svg', async (req, res) => {
  const text = String(req.query.text || '').slice(0, 300);
  if (!text) return res.status(400).end();
  try {
    const svg = await QRCode.toString(text, {
      type: 'svg', margin: 1, errorCorrectionLevel: 'M',
      color: { dark: '#08101F', light: '#FFFFFF' },
    });
    res.type('image/svg+xml').set('Cache-Control', 'no-store').send(svg);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

function isLoopback(addr) {
  // In cloud mode traffic arrives through the host's proxy, so a loopback
  // address proves nothing: the PIN is always required there.
  if (CLOUD) return false;
  return ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(addr);
}

/* Simple per-IP rate limiter: protects the host PIN and room codes from guessing. */
const buckets = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || now > b.reset) { b = { n: 0, reset: now + windowMs }; buckets.set(key, b); }
  b.n += 1;
  return b.n > max;
}
setInterval(() => { const now = Date.now(); for (const [k, b] of buckets) if (now > b.reset) buckets.delete(k); }, 60000).unref();
function clientIp(socket) {
  const xff = String(socket.handshake.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return xff || socket.handshake.address;
}

app.get('/api/results.csv', (req, res) => {
  const addr = req.socket.remoteAddress;
  if (!isLoopback(addr) && req.query.pin !== HOST_PIN) return res.status(403).send('Host PIN required.');
  res.set('Cache-Control', 'no-store');
  const room = rooms[req.query.room === 'demo' ? 'demo' : 'live'];
  const r = room.results();
  if (!r) return res.status(404).send('No results yet.');
  const esc = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = [];
  lines.push(['Section', 'Item', 'Value', 'Detail'].map(esc).join(','));
  lines.push(['Summary', 'Game', room.s.config.gameName, room.kind === 'demo' ? 'DEMO DATA' : 'LIVE'].map(esc).join(','));
  lines.push(['Summary', 'Total players', r.totalPlayers, ''].map(esc).join(','));
  lines.push(['Summary', 'Reached final question', r.reachedFinal, ''].map(esc).join(','));
  lines.push(['Summary', 'Answered final correctly', r.finalCorrect ?? 0, ''].map(esc).join(','));
  r.questions.forEach((q) => {
    lines.push(['Question', `Q${q.number}`, `${q.correctPct ?? ''}% correct`,
      `Correct ${q.correct}; A ${q.counts?.A ?? 0}, B ${q.counts?.B ?? 0}, C ${q.counts?.C ?? 0}, D ${q.counts?.D ?? 0}, no answer ${q.counts?.none ?? 0}; eliminated ${q.eliminated ?? 0}; ${q.text}`].map(esc).join(','));
  });
  r.exits.forEach((x) => {
    lines.push(['Exit', `After Q${x.afterQuestion}`, `${x.exited} exited`, `${formatINR(x.perPlayerPaise)} each, ${formatINR(x.totalPaise)} total${x.capped ? ' (exit fund shared)' : ''}`].map(esc).join(','));
  });
  r.payouts.forEach((p) => lines.push(['Payout', p.name, formatINR(p.amountPaise), `${p.type}; ${p.dept}`].map(esc).join(',')));
  if (r.final) {
    lines.push(['Prize', 'Total prize', formatINR(r.final.totalPaise), ''].map(esc).join(','));
    lines.push(['Prize', 'Exit payouts', formatINR(r.final.exitPaidPaise), ''].map(esc).join(','));
    lines.push(['Prize', 'Final pool', formatINR(r.final.finalPoolPaise), r.final.mode].map(esc).join(','));
    lines.push(['Prize', 'Rounding residue', formatINR(r.final.residuePaise), ''].map(esc).join(','));
    lines.push(['Prize', 'Not awarded / retained', formatINR(r.final.retainedPaise), ''].map(esc).join(','));
  }
  r.players.forEach((p) => lines.push(['Player', p.name, p.status, `${p.dept}${p.eliminatedAt ? `; out at Q${p.eliminatedAt}` : ''}${p.exitedAfter ? `; exited after Q${p.exitedAfter}` : ''}`].map(esc).join(',')));
  const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  res.set('Content-Disposition', `attachment; filename="ampyrs-top-1-${room.kind}-results-${stamp}.csv"`);
  res.type('text/csv').send('\uFEFF' + lines.join('\r\n'));
});

const server = http.createServer(app);
const io = new Server(server, {
  pingInterval: 10000,
  pingTimeout: 20000,
  maxHttpBufferSize: 1e6,
  serveClient: true,
});

/* ------------------------------------------------------------- broadcast */
function addressInfo() {
  if (CLOUD) return { ip: null, port, candidates: [], url: PUBLIC_URL, manual: false, public: true };
  const cands = candidateAddresses();
  const ip = chosenIp || (cands[0] && cands[0].ip) || null;
  return {
    ip, port, candidates: cands,
    url: ip ? `http://${ip}:${port}` : null,
    manual: !!chosenIp,
  };
}

const pending = { live: null, demo: null };
function scheduleBroadcast(kind) {
  if (pending[kind]) return;
  pending[kind] = setTimeout(() => { pending[kind] = null; broadcast(kind); }, 60);
}

function broadcast(kind) {
  const room = rooms[kind];
  const hv = room.hostView();
  hv.address = addressInfo();
  hv.connected = connectedCount(kind);
  io.to(`h:${kind}`).emit('host:state', hv);
  for (const p of room.players()) {
    if (p.isBot) continue;
    io.to(`p:${kind}:${p.id}`).emit('player:state', room.playerView(p));
  }
}

function connectedCount(kind) {
  const room = rooms[kind];
  let n = 0;
  for (const p of room.players()) {
    if (p.isBot) { n += 1; continue; }
    const r = io.sockets.adapter.rooms.get(`p:${kind}:${p.id}`);
    if (r && r.size) n += 1;
  }
  return n;
}

for (const kind of ['live', 'demo']) {
  rooms[kind].on('change', () => scheduleBroadcast(kind));
  rooms[kind].on('kicked', (playerId) => {
    io.to(`p:${kind}:${playerId}`).emit('player:kicked', { reason: 'The host reset the game or removed you from the lobby. Join again with the new room code.' });
    io.in(`p:${kind}:${playerId}`).socketsLeave(`p:${kind}:${playerId}`);
  });
}

function roomByCode(code) {
  // Accept "ampyr-w4ks", "AMPYR W4KS" or "AMPYRW4KS" for the code AMPYR-W4KS.
  const norm = (x) => String(x || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const c = norm(code);
  return c ? Object.values(rooms).find((r) => norm(r.s.code) === c) || null : null;
}

/* ---------------------------------------------------------------- socket */
class UserError extends Error {}
io.on('connection', (socket) => {
  socket.data = { role: null };
  const safe = (fn) => (...args) => {
    const ack = typeof args[args.length - 1] === 'function' ? args.pop() : () => {};
    try { ack(fn(...args) || { ok: true }); } catch (err) {
      if (!(err instanceof UserError)) console.error(err);
      ack({ ok: false, error: err.message || 'Server error' });
    }
  };

  socket.on('time:ping', (clientSent, ack) => { if (typeof ack === 'function') ack({ clientSent, serverNow: Date.now() }); });

  /* ---- host ---- */
  socket.on('host:hello', safe((msg = {}) => {
    const loop = isLoopback(socket.handshake.address);
    const ip = clientIp(socket);
    if (!loop && buckets.get('pin:' + ip)?.n >= 8 && Date.now() < buckets.get('pin:' + ip).reset) {
      return { ok: false, needPin: true, error: 'Too many wrong PINs. Wait 15 minutes and try again.' };
    }
    if (!loop && String(msg.pin || '') !== HOST_PIN) {
      if (msg.pin) limited('pin:' + ip, 8, 15 * 60000);
      const where = CLOUD ? 'the HOST_PIN set in your hosting dashboard' : 'the PIN shown in the server window';
      return { ok: false, needPin: true, error: msg.pin ? `Incorrect host PIN. Use ${where}.` : `Enter ${where}.` };
    }
    const kind = msg.room === 'demo' ? 'demo' : 'live';
    socket.leave('h:live'); socket.leave('h:demo');
    socket.join(`h:${kind}`);
    socket.data.role = 'host';
    socket.data.kind = kind;
    socket.data.pin = msg.pin || null;
    setImmediate(() => broadcast(kind));
    return { ok: true, kind, pin: loop ? HOST_PIN : undefined };
  }));

  const requireHost = () => {
    if (socket.data.role !== 'host') throw new UserError('Host access required.');
    return rooms[socket.data.kind];
  };

  socket.on('host:action', safe((msg = {}) => {
    const room = requireHost();
    return room.action(String(msg.type || ''), msg.payload || {});
  }));

  socket.on('host:saveConfig', safe((cfg = {}) => {
    const room = requireHost();
    if (!['SETUP', 'LOBBY'].includes(room.s.phase)) throw new UserError('Settings are locked once the game starts.');
    if (rooms.live.s.phase !== 'SETUP' && rooms.live.s.phase !== 'LOBBY' && rooms.live.s.phase !== 'GAME_COMPLETE') {
      throw new UserError('A live game is running. Settings can be changed after it ends.');
    }
    store.saveConfig(cfg);
    scheduleBroadcast('live'); scheduleBroadcast('demo');
    return { ok: true };
  }));

  socket.on('host:saveQuestions', safe((list) => {
    const room = requireHost();
    if (!['SETUP', 'LOBBY'].includes(room.s.phase)) throw new UserError('Questions are locked once the game starts.');
    if (!['SETUP', 'LOBBY', 'GAME_COMPLETE'].includes(rooms.live.s.phase)) throw new UserError('A live game is running. Questions can be edited after it ends.');
    store.saveQuestions(list);
    scheduleBroadcast('live'); scheduleBroadcast('demo');
    return { ok: true };
  }));

  socket.on('host:restoreDefaults', safe((what) => {
    const room = requireHost();
    if (!['SETUP', 'LOBBY'].includes(room.s.phase)) throw new UserError('Only available before the game starts.');
    if (what === 'questions') store.restoreDefaultQuestions();
    if (what === 'config') store.restoreDefaultConfig();
    scheduleBroadcast('live'); scheduleBroadcast('demo');
    return { ok: true };
  }));

  socket.on('host:setIp', safe((ip) => {
    requireHost();
    if (CLOUD) throw new UserError('The public address is set by PUBLIC_URL on the server.');
    const v = String(ip || '').trim();
    if (v && !/^(\d{1,3}\.){3}\d{1,3}$|^[a-z0-9.-]+$/i.test(v)) throw new UserError('Enter an address like 192.168.1.15');
    chosenIp = v || null;
    scheduleBroadcast('live'); scheduleBroadcast('demo');
    return { ok: true };
  }));

  /* ---- player ---- */
  const bindPlayer = (room, p) => {
    if (socket.data.playerRoom) socket.leave(socket.data.playerRoom);
    socket.data.role = 'player';
    socket.data.kind = room.kind;
    socket.data.playerId = p.id;
    socket.data.playerRoom = `p:${room.kind}:${p.id}`;
    socket.join(socket.data.playerRoom);
    setImmediate(() => {
      socket.emit('player:state', room.playerView(p));
      scheduleBroadcast(room.kind); // update connected count for the host
    });
  };

  // Generous: a whole office often shares one public IP address.
  const tooFast = () => limited('join:' + clientIp(socket), 400, 60000);

  socket.on('player:lookup', safe((code) => {
    if (tooFast()) return { ok: false, error: 'Too many attempts. Wait a minute and try again.' };
    const room = roomByCode(code);
    if (!room) return { ok: false, error: 'Room code not found. Check the code on the big screen.' };
    return { ok: true, gameName: room.cfg.gameName, departments: store.config.departments, phase: room.s.phase, kind: room.kind };
  }));

  socket.on('player:join', safe((msg = {}) => {
    if (tooFast()) return { ok: false, error: 'Too many attempts. Wait a minute and try again.' };
    const room = roomByCode(msg.code);
    if (!room) return { ok: false, error: 'Room code not found. Check the code on the big screen.' };
    const r = room.join({ name: msg.name, dept: msg.dept });
    if (r.ok) bindPlayer(room, room.s.players[r.playerId]);
    return r.ok ? { ok: true, token: r.token, code: room.s.code } : r;
  }));

  socket.on('player:resume', safe((msg = {}) => {
    if (tooFast()) return { ok: false, error: 'Too many attempts. Wait a minute and try again.' };
    const room = roomByCode(msg.code);
    if (!room) return { ok: false, gone: true };
    const p = room.byToken(msg.token);
    if (!p) return { ok: false, gone: true };
    bindPlayer(room, p);
    return { ok: true };
  }));

  const myPlayer = () => {
    if (socket.data.role !== 'player') throw new UserError('Join the game first.');
    const room = rooms[socket.data.kind];
    const p = room.s.players[socket.data.playerId];
    if (!p) throw new UserError('You are no longer registered in this game.');
    return { room, p };
  };

  socket.on('player:answer', safe((option) => {
    const { room, p } = myPlayer();
    return room.answer(p.id, String(option || ''));
  }));

  socket.on('player:exit', safe((choice) => {
    const { room, p } = myPlayer();
    return room.decideExit(p.id, String(choice || ''));
  }));

  socket.on('disconnect', () => {
    if (socket.data.kind) scheduleBroadcast(socket.data.kind);
  });
});

/* ----------------------------------------------------------------- start */
function listen() {
  server.once('error', (err) => {
    if (err.code === 'EADDRINUSE' && port < BASE_PORT + 20) {
      console.log(`Port ${port} is busy, trying ${port + 1}…`);
      port += 1;
      setTimeout(listen, 100);
    } else {
      console.error('Could not start the server:', err.message);
      process.exit(1);
    }
  });
  server.listen(port, '0.0.0.0', () => {
    const a = addressInfo();
    const line = '─'.repeat(62);
    console.log(`\n${line}\n  AMPYR'S TOP 1%  —  game server running${CLOUD ? ' (internet mode)' : ''}\n${line}`);
    if (CLOUD) {
      console.log(`  Host screen:     ${PUBLIC_URL}/host   (enter your HOST_PIN)`);
      console.log(`  Players join at: ${PUBLIC_URL}`);
      console.log(`  Saved data:      ${DATA_DIR}`);
    } else {
      console.log(`  Host screen (open on THIS laptop):  http://localhost:${port}/host`);
      if (a.url) console.log(`  Players join at:                    ${a.url}`);
      else console.log('  No Wi-Fi/LAN address found. Connect this laptop to the network.');
      if (a.candidates.length > 1) {
        console.log('  Other addresses on this laptop:     ' + a.candidates.slice(1).map((c) => `${c.ip} (${c.name})`).join(', '));
      }
      console.log(`  Host PIN (only needed if you open /host from another device): ${HOST_PIN}`);
    }
    console.log(`${line}\n`);
  });
}

if (require.main === module) listen();

function shutdown() {
  if (rooms.live.persistFile) rooms.live._save();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

module.exports = { app, server, io, rooms, store, listen, HOST_PIN };
