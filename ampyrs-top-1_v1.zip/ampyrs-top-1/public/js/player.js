/* AMPYR'S TOP 1% — player phone */
(function () {
  const { esc, inr, wordmark, mmss, remainingMs } = T1;
  const $ = (id) => document.getElementById(id);
  const app = $('app');
  const OPTS = ['A', 'B', 'C', 'D'];

  const params = new URLSearchParams(location.search);
  let session = null;
  try { session = JSON.parse(localStorage.getItem('t1-session') || 'null'); } catch {}
  let code = (params.get('room') || (session && session.code) || '').toUpperCase();
  let S = null; // latest player state
  let room = null; // lookup info (departments)
  let key = '';
  let selected = null;
  let selectedQ = null;
  let exitPick = null;
  let busy = false;
  let joinError = '';
  let kickedMsg = '';

  const socket = T1.connect((up) => {
    $('offline').classList.toggle('hidden', up || !S);
    if (up) start();
  });

  function saveSession(s) {
    session = s;
    if (s) localStorage.setItem('t1-session', JSON.stringify(s)); else localStorage.removeItem('t1-session');
  }

  function start() {
    if (session && session.token && (!params.get('room') || session.code === code)) {
      socket.emit('player:resume', { code: session.code, token: session.token }, (res) => {
        if (res && res.ok) return; // state arrives via player:state
        saveSession(null);
        S = null;
        lookup();
      });
    } else {
      lookup();
    }
  }

  function lookup() {
    if (!code) { room = null; renderJoin(); return; }
    socket.emit('player:lookup', code, (res) => {
      if (res && res.ok) { room = res; joinError = ''; }
      else { room = null; joinError = (res && res.error) || ''; code = ''; }
      renderJoin();
    });
  }

  socket.on('player:state', (st) => {
    S = st;
    $('offline').classList.add('hidden');
    if (selectedQ !== st.qIndex) { selected = null; selectedQ = st.qIndex; }
    if (st.phase !== 'EXIT_DECISION') exitPick = null;
    render();
  });

  socket.on('player:kicked', (m) => {
    saveSession(null);
    S = null;
    kickedMsg = m && m.reason;
    code = '';
    key = '';
    renderJoin();
  });

  /* --------------------------------------------------------------- join */
  function renderJoin() {
    key = 'join';
    $('p-chip').textContent = '';
    const deps = (room && room.departments) || [];
    const needCode = !room;
    app.className = 'p-main';
    app.innerHTML = `<form class="join-form" id="join-form" autocomplete="off">
      <div>
        <h1>Join the game</h1>
        <p class="lead">${room && room.kind === 'demo' ? 'This is the practice room (demo mode).' : 'Think differently. Beat the room.'}</p>
      </div>
      ${kickedMsg ? `<p class="err-line">${esc(kickedMsg)}</p>` : ''}
      ${needCode ? `<div class="field"><label for="j-code">Room code (shown on the big screen)</label><input id="j-code" class="input" autocapitalize="characters" maxlength="14" required value="${esc(code)}"></div>` : ''}
      <div class="field"><label for="j-name">Name</label><input id="j-name" class="input" maxlength="24" required autocomplete="given-name" enterkeyhint="next"></div>
      <div class="field"><label for="j-dept">Department</label>
        <select id="j-dept" class="input" required>
          <option value="">Choose your department</option>
          ${deps.map((d) => `<option>${esc(d)}</option>`).join('')}
          <option value="__other">Other (type it)</option>
        </select>
        <input id="j-dept-other" class="input hidden" maxlength="40" placeholder="Your department" aria-label="Your department">
      </div>
      <p class="err-line" id="j-err" role="alert">${esc(joinError)}</p>
      <button class="btn btn-gold" type="submit" id="j-btn">Join game</button>
    </form>`;
    const sel = $('j-dept');
    const other = $('j-dept-other');
    if (needCode) { sel.innerHTML = '<option value="__other">Type your department</option>'; other.classList.remove('hidden'); }
    sel.addEventListener('change', () => other.classList.toggle('hidden', sel.value !== '__other'));
    $('join-form').addEventListener('submit', (e) => {
      e.preventDefault();
      if (busy) return;
      const name = $('j-name').value.trim();
      const dept = sel.value === '__other' ? other.value.trim() : sel.value;
      const c = needCode ? $('j-code').value.trim().toUpperCase() : code;
      if (!c) return showErr('Enter the room code from the big screen.');
      if (!name) return showErr('Enter your name.');
      if (!dept) return showErr('Choose your department.');
      busy = true;
      $('j-btn').disabled = true;
      socket.emit('player:join', { code: c, name, dept }, (res) => {
        busy = false;
        const b = $('j-btn'); if (b) b.disabled = false;
        if (res && res.ok) {
          kickedMsg = '';
          code = res.code;
          saveSession({ code: res.code, token: res.token });
          if (navigator.vibrate) navigator.vibrate(30);
        } else {
          showErr((res && res.error) || 'Could not join. Try again.');
        }
      });
    });
  }
  function showErr(m) { const el = $('j-err'); if (el) el.textContent = m; }

  /* ------------------------------------------------------------- render */
  function chip() {
    if (!S) return '';
    if (S.phase === 'LOBBY') return '';
    if (S.phase === 'GAME_COMPLETE') return '';
    return `<b>${S.remaining}</b> player${S.remaining === 1 ? '' : 's'} remain`;
  }

  function render() {
    if (!S) return;
    $('p-brand').innerHTML = wordmark(S.gameName);
    $('p-chip').innerHTML = chip();
    const me = S.me;
    const k = [S.phase, S.qIndex, S.paused, me.status, me.answer, me.exitDecision, selected, exitPick, S.remaining, S.exitOffer && S.exitOffer.confirmed].join('|');
    if (k === key) return;
    key = k;
    app.className = 'p-main';
    app.innerHTML = screen() + (S.paused ? '<div class="veil"><div><h2>Paused</h2><p class="sub">The host has paused the game. The clock is stopped.</p></div></div>' : '');
    bind();
  }

  const hero = (badge, cls, title, sub) => `<div class="p-hero"><div class="badge ${cls}" aria-hidden="true">${badge}</div><h1>${title}</h1>${sub ? `<p class="sub">${sub}</p>` : ''}</div>`;

  function screen() {
    const me = S.me;
    const ph = S.phase;

    if (ph === 'GAME_COMPLETE') return completeScreen();
    if (ph === 'LOBBY') return hero('✓', 'gold', "You're in!", `Welcome, ${esc(me.name)}.<br>Waiting for the host to start…`);

    // Results of the question just revealed take priority, so a player who
    // was just knocked out sees why.
    if (['ANSWER_REVEAL', 'EXPLANATION', 'SURVIVOR_UPDATE'].includes(ph) && me.result) {
      const q = S.question;
      const right = `Correct answer: <b>${esc(q.correct)}</b>, ${esc(q.options[q.correct])}`;
      if (me.result === 'correct') {
        return hero('✓', 'ok', S.isFinal ? 'Correct!' : 'Correct', S.isFinal ? 'Watch the big screen…' : `You survived question ${S.qNumber}.`);
      }
      const title = me.result === 'no-answer' ? "Time's up. You're out" : "Wrong. You're out";
      return hero('✕', 'out', title, `${right}<br><br>Game over. Better luck next time! Keep watching the big screen.`);
    }

    if (me.status === 'eliminated') {
      return hero('✕', 'mute', 'Game over', `Better luck next time! You went out on question ${me.eliminatedAt}. Keep watching the big screen.`);
    }
    if (me.status === 'exited') {
      return hero('↗', 'gold', 'You have exited', `You took the exit after question ${me.exitedAfter}. Your exit is confirmed. Enjoy the rest of the show.`);
    }

    switch (ph) {
      case 'QUESTION_READY':
        return hero(S.isFinal ? '1%' : S.qNumber, 'gold', S.isFinal ? 'The final question' : 'Get ready', S.isFinal ? 'No timer. Take your time when it opens.' : `Question ${S.qNumber} of ${S.qTotal} is next. ${S.timerSecs} seconds.`);
      case 'QUESTION_OPEN':
      case 'FINAL_QUESTION':
        if (!me.inQuestion) return hero('…', 'mute', 'Next question', 'You joined mid-question. You will play from the next one.');
        return me.answer ? lockedScreen() : answerScreen();
      case 'QUESTION_LOCKED':
      case 'ROOM_DISTRIBUTION':
        if (!me.answer && me.inQuestion) return hero('⏱', 'out', "Time's up", 'No answer was received. Waiting for the reveal…');
        return lockedScreen();
      case 'ANSWER_REVEAL':
      case 'EXPLANATION':
      case 'SURVIVOR_UPDATE':
        return hero('✓', 'ok', 'You survived', 'Watch the big screen.');
      case 'EXIT_DECISION':
        return exitScreen();
      case 'ACTIVE_LIST':
        return hero('✓', 'gold', "You're still in", `Your name is on the big screen with the ${S.remaining} player${S.remaining === 1 ? '' : 's'} still in the game.`);
      case 'EXIT_RESULT':
        return hero('→', 'gold', 'You are still in', `You chose to keep playing. ${S.remaining} player${S.remaining === 1 ? '' : 's'} remain.`);
      default:
        return hero('…', 'mute', 'Stand by', '');
    }
  }

  function answerScreen() {
    const q = S.question;
    const long = q.text.length > 140;
    const head = S.isFinal
      ? `<div class="q-head"><span>The final question</span><span style="color:var(--mute)">Take your time</span></div>`
      : `<div class="q-head"><span>Question ${S.qNumber} / ${S.qTotal}</span><span class="time" id="p-time">${mmss((S.timerSecs || 0) * 1000)}</span></div><div class="timebar" id="p-bar"><i></i></div>`;
    return `${head}
      <p class="p-question${long ? ' long' : ''}">${esc(q.text)}</p>
      <div class="answers" role="group" aria-label="Answer options">
        ${OPTS.map((o) => `<button class="ans" data-ans="${o}" aria-pressed="${selected === o}"><span class="l">${o}</span><span>${esc(q.options[o])}</span></button>`).join('')}
      </div>
      <button class="btn btn-gold lock-btn" id="lock" ${selected ? '' : 'disabled'}>${selected ? `Lock answer ${selected}` : 'Choose an answer'}</button>
      <p class="fine">Once locked, your answer cannot be changed. Speed does not matter, only right or wrong.</p>`;
  }

  function lockedScreen() {
    const q = S.question;
    const a = S.me.answer;
    return `<div class="q-head"><span>${S.isFinal ? 'The final question' : `Question ${S.qNumber} / ${S.qTotal}`}</span>${S.phase === 'QUESTION_OPEN' ? '<span class="time" id="p-time"></span>' : ''}</div>
      <div class="locked-card">
        <div class="big">Answer locked</div>
        <div class="your">You chose <b>${esc(a)}</b>: ${esc(q.options[a])}</div>
      </div>
      <div class="p-hero"><p class="sub">Waiting for the room…</p></div>`;
  }

  function exitScreen() {
    const x = S.exitOffer;
    if (!x) return hero('…', 'mute', 'Stand by', 'Survivors are making a decision.');
    if (S.me.exitDecision) {
      return hero('✓', 'gold', 'Decision locked', S.me.exitDecision === 'exit' ? `You chose to take ${inr(x.amountPaise)} and end your game. Waiting for the host to confirm.` : 'You chose to keep playing. Waiting for the others…');
    }
    return `<div class="p-hero"><h1>You survived!</h1><p class="sub">You now have a choice. Nobody else will see what you pick.</p></div>
      <div class="choice" role="group" aria-label="Exit decision">
        <button class="choice-btn" data-exit="exit" aria-pressed="${exitPick === 'exit'}"><span class="t">Take ${inr(x.amountPaise)}*</span><span class="s">End my game now</span></button>
        <button class="choice-btn" data-exit="continue" aria-pressed="${exitPick === 'continue'}"><span class="t">Continue</span><span class="s">I want to keep playing for the final prize</span></button>
      </div>
      <button class="btn btn-gold lock-btn" id="exit-lock" ${exitPick ? '' : 'disabled'}>${exitPick ? 'Lock my decision' : 'Choose one'}</button>
      <p class="fine">Your decision cannot be changed once locked. If you do not decide before the host confirms, you keep playing.<br>* An exit round can pay out at most ${x.capPct}% of the prize pool remaining. If more players exit than that allows, it is shared equally among them.</p>`;
  }

  function completeScreen() {
    const c = S.complete;
    const me = S.me;
    if (c.reason === 'ended_by_host') return hero('■', 'mute', 'Game ended', 'The host ended the game. Thanks for playing!');
    if (me.winner) {
      return hero('1%', 'gold', c.winners.length === 1 ? 'You are the Top 1%' : 'You made the Top 1%', c.winners.length === 1 ? 'Nobody else got there. Take a bow.' : `You share the final prize with ${c.winners.length - 1} other${c.winners.length === 2 ? '' : 's'}.`);
    }
    if (c.mode === 'winners') {
      return `<div class="p-hero"><div class="badge gold" aria-hidden="true">1%</div><h1>We have our Top 1%</h1></div>
        <div class="winner-list">${c.winners.map((n) => `<div>${esc(n)}</div>`).join('')}</div>
        <p class="sub" style="text-align:center;color:var(--mute)">Thanks for playing!</p>`;
    }
    return hero('○', 'mute', 'No one reached the Top 1%', c.mode === 'last_standing' ? `The final prize is shared by the players who reached question ${c.lastQuestion}.` : 'The final prize was not awarded this time. Thanks for playing!');
  }

  function bind() {
    app.querySelectorAll('[data-ans]').forEach((b) => b.addEventListener('click', () => {
      selected = b.dataset.ans;
      render();
    }));
    const lock = $('lock');
    if (lock) lock.addEventListener('click', () => {
      if (!selected || busy) return;
      busy = true;
      lock.disabled = true;
      socket.emit('player:answer', selected, (res) => {
        busy = false;
        if (!res || !res.ok) {
          lock.disabled = false;
          alert((res && res.error) || 'Your answer was not received. Try again.');
        } else if (navigator.vibrate) navigator.vibrate(40);
      });
    });
    app.querySelectorAll('[data-exit]').forEach((b) => b.addEventListener('click', () => { exitPick = b.dataset.exit; render(); }));
    const el = $('exit-lock');
    if (el) el.addEventListener('click', () => {
      if (!exitPick || busy) return;
      busy = true;
      el.disabled = true;
      socket.emit('player:exit', exitPick, (res) => {
        busy = false;
        if (!res || !res.ok) { el.disabled = false; alert((res && res.error) || 'Your decision was not received. Try again.'); }
      });
    });
  }

  /* ------------------------------------------------------------- timer */
  function loop() {
    requestAnimationFrame(loop);
    if (!S || S.phase !== 'QUESTION_OPEN') return;
    const t = $('p-time');
    if (!t) return;
    const ms = remainingMs(S) ?? 0;
    const crit = ms <= 5000;
    t.textContent = ms <= 0 ? "Time's up" : mmss(ms);
    t.classList.toggle('crit', crit);
    const bar = $('p-bar');
    if (bar) {
      bar.firstElementChild.style.transform = `scaleX(${Math.max(0, ms / ((S.timerSecs || 1) * 1000))})`;
      bar.classList.toggle('crit', crit);
    }
  }
  requestAnimationFrame(loop);
})();
