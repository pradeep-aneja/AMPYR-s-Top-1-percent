/* Original sound effects generated with the Web Audio API. No recordings or
   music from any TV programme are used. */
(function () {
  let ctx = null;
  let muted = false;
  try { muted = localStorage.getItem('t1-muted') === '1'; } catch {}

  function ac() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function tone(freq, start, dur, { type = 'sine', gain = 0.18, slideTo = null } = {}) {
    const c = ac();
    const t0 = c.currentTime + start;
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(c.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
  }

  const S = {
    questionStart() { tone(392, 0, 0.18, { type: 'triangle' }); tone(587, 0.12, 0.35, { type: 'triangle' }); },
    tick() { tone(1200, 0, 0.05, { type: 'square', gain: 0.05 }); },
    tickUrgent() { tone(1500, 0, 0.08, { type: 'square', gain: 0.09 }); },
    timeUp() { tone(220, 0, 0.6, { type: 'sawtooth', gain: 0.1, slideTo: 110 }); },
    lock() { tone(660, 0, 0.08, { type: 'square', gain: 0.07 }); tone(440, 0.08, 0.12, { type: 'square', gain: 0.07 }); },
    room() { [330, 415, 494].forEach((f, i) => tone(f, i * 0.09, 0.3, { type: 'triangle', gain: 0.1 })); },
    correct() { [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.08, 0.35, { type: 'triangle', gain: 0.14 })); },
    tricked() { tone(300, 0, 0.25, { type: 'triangle' }); tone(240, 0.22, 0.25, { type: 'triangle' }); tone(180, 0.44, 0.5, { type: 'triangle' }); },
    exit() { tone(587, 0, 0.4, { type: 'sine', gain: 0.12 }); tone(740, 0.2, 0.5, { type: 'sine', gain: 0.1 }); },
    finalOpen() { tone(110, 0, 2.2, { type: 'sine', gain: 0.2 }); tone(165, 0.4, 1.8, { type: 'sine', gain: 0.12 }); },
    winner() { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, i * 0.12, 0.9, { type: 'triangle', gain: 0.12 })); },
  };

  window.Sound = {
    play(name) { if (!muted && S[name]) { try { S[name](); } catch {} } },
    unlock() { try { ac(); } catch {} },
    get muted() { return muted; },
    toggle() {
      muted = !muted;
      try { localStorage.setItem('t1-muted', muted ? '1' : '0'); } catch {}
      return muted;
    },
  };
})();
