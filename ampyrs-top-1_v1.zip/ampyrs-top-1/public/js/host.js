/* AMPYR'S TOP 1% — host screen */
(function () {
  const { esc, inr, inrRupees, wordmark, mmss, remainingMs } = T1;
  const $ = (id) => document.getElementById(id);
  const OPTS = ['A', 'B', 'C', 'D'];

  let S = null; // latest host state
  let mode = localStorage.getItem('t1-mode') === 'demo' ? 'demo' : 'live';
  let pin = sessionStorage.getItem('t1-pin') || '';
  let stageKey = '';
  let prevPhase = null;
  let setupTab = 'game';
  let configDirty = false;
  let showResults = false;
  let lastTickSec = null;
  let editingIndex = null;

  const socket = T1.connect((up) => {
    if (up) hello();
    else toast('Connection to the game server lost. Reconnecting…');
  });

  function hello() {
    socket.emit('host:hello', { room: mode, pin }, (res) => {
      if (res && res.ok) {
        $('pin-gate').classList.add('hidden');
        hideToast();
      } else if (res && res.needPin) {
        $('pin-gate').classList.remove('hidden');
        $('pin-error').textContent = res.error || '';
        $('pin-input').focus();
      }
    });
  }

  $('pin-form').addEventListener('submit', (e) => {
    e.preventDefault();
    pin = $('pin-input').value.trim();
    sessionStorage.setItem('t1-pin', pin);
    hello();
  });

  socket.on('host:state', (st) => {
    S = st;
    render();
  });

  function act(type, payload = {}, cb) {
    socket.emit('host:action', { type, payload }, (res) => {
      if (!res || !res.ok) toast((res && res.error) || 'That action failed.');
      cb && cb(res);
    });
  }

  /* ------------------------------------------------------------- toasts */
  let toastT = null;
  function toast(msg, kind) {
    const t = $('toast');
    t.textContent = msg;
    t.className = 'toast' + (kind === 'info' ? ' info' : '');
    clearTimeout(toastT);
    toastT = setTimeout(hideToast, 5000);
  }
  function hideToast() { $('toast').classList.add('hidden'); }

  function confirmDialog(title, body, okLabel = 'Confirm') {
    return new Promise((resolve) => {
      const d = $('dlg-confirm');
      $('confirm-title').textContent = title;
      $('confirm-body').textContent = body;
      $('confirm-ok').textContent = okLabel;
      d.returnValue = '';
      d.onclose = () => resolve(d.returnValue === 'ok');
      d.showModal();
    });
  }

  /* -------------------------------------------------------------- render */
  function render() {
    if (!S) return;
    document.title = `${S.gameName} · Host`;
    $('brand').innerHTML = wordmark(S.gameName);
    $('mode-chip').classList.toggle('hidden', S.kind !== 'demo');
    $('qprogress').innerHTML = S.qIndex >= 0 && S.phase !== 'GAME_COMPLETE'
      ? (S.isFinal ? '<strong>The final question</strong>' : `Question <strong>${S.qNumber}</strong> / ${S.qTotal}`)
      : '';
    if (prevPhase !== S.phase) onPhaseChange(prevPhase, S.phase);
    renderStage();
    renderSurvival();
    renderDock();
    renderPrivate();
    prevPhase = S.phase;
  }

  function onPhaseChange(from, to) {
    lastTickSec = null;
    const grp = (p) => ['SETUP', 'GAME_COMPLETE'].includes(p);
    if (from === null || grp(from) !== grp(to) || to === 'QUESTION_READY') dockCollapsed = null;
    if (from === null) return; // first render: no sounds
    if (to !== 'GAME_COMPLETE') showResults = false;
    const play = (n) => Sound.play(n);
    if (to === 'QUESTION_OPEN') play('questionStart');
    if (to === 'FINAL_QUESTION') play('finalOpen');
    if (to === 'QUESTION_LOCKED') play(S.lockReason === 'timeup' ? 'timeUp' : 'lock');
    if (to === 'ROOM_DISTRIBUTION') play('room');
    if (to === 'ANSWER_REVEAL') play(S.result && S.result.tricked ? 'tricked' : 'correct');
    if (to === 'EXIT_DECISION') play('exit');
    if (to === 'ACTIVE_LIST') play('room');
    if (to === 'GAME_COMPLETE') play('winner');
  }

  function renderStage() {
    const st = $('stage');
    const ph = S.phase;
    let key = `${S.kind}|${ph}|${S.qIndex}|${S.paused}`;
    if (ph === 'SETUP') key += '|' + setupTab + '|' + mode + '|' + JSON.stringify(S.store) + '|' + JSON.stringify(S.address);
    if (ph === 'LOBBY') key += '|' + S.players.map((p) => p.id).join(',') + '|' + (S.address && S.address.url) + '|' + S.code;
    if (ph === 'ACTIVE_LIST') key += '|' + (S.activeNames || []).join(',');
    if (ph === 'GAME_COMPLETE') key += '|' + showResults;
    if (ph === 'SETUP') {
      // Rebuild setup only when switching tabs/mode; refresh pieces otherwise.
      if (stageKey !== key) { st.innerHTML = setupHTML(); bindSetup(); stageKey = key; }
      refreshSetup();
      return;
    }
    if (key !== stageKey) {
      stageKey = key;
      st.innerHTML = stageHTML();
      afterStage();
    }
    updateLive();
  }

  function stageHTML() {
    const ph = S.phase;
    let html = '';
    switch (ph) {
      case 'LOBBY': html = lobbyHTML(); break;
      case 'QUESTION_READY': html = readyHTML(); break;
      case 'QUESTION_OPEN':
      case 'FINAL_QUESTION':
      case 'QUESTION_LOCKED':
      case 'ROOM_DISTRIBUTION':
      case 'ANSWER_REVEAL': html = questionHTML(); break;
      case 'EXPLANATION': html = explanationHTML(); break;
      case 'SURVIVOR_UPDATE': html = survivorsHTML(); break;
      case 'EXIT_DECISION': html = exitDecisionHTML(); break;
      case 'EXIT_RESULT': html = exitResultHTML(); break;
      case 'ACTIVE_LIST': html = activeListHTML(); break;
      case 'GAME_COMPLETE': html = showResults ? resultsHTML() : completeHTML(); break;
      default: html = '';
    }
    if (S.paused) html += '<div class="paused-veil"><div class="stage-center"><div class="mega">Paused</div><p class="subline">The host has paused the game. The clock is stopped.</p></div></div>';
    return html;
  }

  function lobbyHTML() {
    const url = S.address && S.address.url;
    const joinUrl = url ? `${url}/?room=${encodeURIComponent(S.code)}` : null;
    const names = S.players.map((p) => `<span class="name-pill${p.isBot ? ' bot' : ''}">${esc(p.name)}<button title="Remove ${esc(p.name)}" aria-label="Remove ${esc(p.name)}" data-remove="${esc(p.id)}">×</button></span>`).join('');
    return `<div class="lobby">
      <div class="join-card">
        <h2>Are you ready?</h2>
        ${joinUrl ? `<div class="qr-frame"><img alt="QR code to join the game" src="/api/qr.svg?text=${encodeURIComponent(joinUrl)}"></div>` : '<p class="subline">No network address found. Connect this laptop to the Wi-Fi, or set the address manually in Setup → Join address.</p>'}
        <div class="kicker">Scan to join</div>
        <div class="room-code">Room: <span>${esc(S.code)}</span></div>
        ${url ? `<div class="join-url">${esc(url)}</div>` : ''}
      </div>
      <div class="names-panel">
        <div class="names-head"><span class="num" id="joined-num">${S.players.length}</span><span class="lbl">player${S.players.length === 1 ? '' : 's'} joined</span></div>
        <div class="names">${names || '<p class="subline" style="margin:0;text-align:left">Names appear here as people join.</p>'}</div>
      </div>
    </div>`;
  }

  function readyHTML() {
    const n = S.qNumber;
    let sub;
    if (S.isFinal) sub = 'No timer. No rush. Only the sharpest thinking counts.';
    else if (S.timerSecs >= 60 && n === 9) sub = `From here, every question gets ${S.timerSecs} seconds and they get much harder.`;
    else sub = `${S.timerSecs} seconds on the clock.`;
    return `<div class="stage-center">
      <div class="kicker">${S.remaining} player${S.remaining === 1 ? '' : 's'} remain</div>
      <div class="mega">${S.isFinal ? 'The final question' : `Question ${n} / ${S.qTotal}`}</div>
      <p class="subline">${esc(sub)}</p>
    </div>`;
  }

  function questionHTML() {
    const q = S.question;
    const ph = S.phase;
    const dist = S.distribution;
    const revealed = ph === 'ANSWER_REVEAL';
    const longQ = q.text.length > 150;
    const opts = OPTS.map((o) => {
      const isC = revealed && q.correct === o;
      const pct = dist ? dist.pct[o] : null;
      return `<div class="opt${revealed ? (isC ? ' correct' : ' dim') : ''}" data-opt="${o}">
        <span class="bar" data-w="${pct ?? 0}"></span>
        <span class="letter" aria-hidden="true">${o}</span>
        <span class="label"><span class="sr-only">Option ${o}: </span>${esc(q.options[o])}</span>
        ${isC ? '<span class="tag">✓ Correct</span>' : ''}
        ${pct != null ? `<span class="pct">${pct}%</span>` : '<span></span>'}
      </div>`;
    }).join('');
    let side = '';
    if (ph === 'QUESTION_OPEN' || (ph === 'QUESTION_LOCKED' && !S.isFinal && S.timerSecs)) {
      side = `<div class="timer" id="timer"><svg viewBox="0 0 120 120"><circle class="track" cx="60" cy="60" r="54" fill="none" stroke-width="6"/><circle id="t-prog" class="prog" cx="60" cy="60" r="54" fill="none" stroke-width="6" stroke-linecap="round" stroke-dasharray="339.3" stroke-dashoffset="0"/></svg><span class="t-num" id="t-num">${mmss((S.timerSecs || 0) * 1000)}</span></div>`;
    } else if (ph === 'FINAL_QUESTION') {
      side = `<div class="thinking"><div class="big num" id="think-answered">0</div><div class="small" id="think-line">have answered</div></div>`;
    }
    let overlay = '';
    if (ph === 'QUESTION_LOCKED') overlay = S.lockReason === 'timeup' ? `<div class="overlay-msg out">Time's up</div>` : `<div class="overlay-msg">Answers locked</div>`;
    if (ph === 'ROOM_DISTRIBUTION') overlay = `<div class="overlay-msg">What did the room think?</div>`;
    if (revealed && S.result && S.result.tricked) overlay = `<div class="overlay-msg">The room got tricked!</div>`;
    else if (revealed) overlay = `<div class="overlay-msg">Correct answer: ${esc(q.correct)}</div>`;
    const meta = S.isFinal
      ? `<div class="q-final-label">The final question</div><div class="q-meta">${ph === 'FINAL_QUESTION' ? 'Take your time.' : ''}</div>`
      : `<div class="q-meta">Question ${S.qNumber} / ${S.qTotal}</div>`;
    return `<div class="q-wrap">
      <div>${meta}<h1 class="q-text${longQ ? ' long' : ''}">${esc(q.text)}</h1></div>
      ${side}
      <div class="options">${opts}</div>
    </div>${overlay}`;
  }

  function explanationHTML() {
    const q = S.question;
    return `<div class="stage-center">
      <div class="kicker">Correct answer: ${esc(q.correct)}, ${esc(q.options[q.correct])}</div>
      <p class="explain">${esc(q.explanation || 'No explanation was added for this question.')}</p>
    </div>`;
  }

  function survivorsHTML() {
    const r = S.result;
    if (!r) return '';
    if (S.isFinal) {
      return `<div class="survivor-hero">
        <div class="kicker">The final question</div>
        <div class="mega">${r.survived}</div>
        <p class="subline">${r.survived === 1 ? 'player answered correctly.' : r.survived ? 'players answered correctly.' : 'Nobody answered correctly.'}</p>
      </div>`;
    }
    const head = r.tricked ? `<div class="tricked">The room got tricked!</div>` : `<div class="kicker">After question ${S.qNumber}</div>`;
    const line = r.tricked
      ? `Only ${r.survived} of ${r.activeAtStart} players survived this question.`
      : `${r.eliminated} player${r.eliminated === 1 ? '' : 's'} eliminated${r.noAnswer ? `, including ${r.noAnswer} who ran out of time` : ''}.`;
    return `<div class="survivor-hero">
      ${head}
      <div class="mega">${r.survived}</div>
      <p class="subline">${r.survived === 1 ? 'player survived.' : 'players survived.'} ${esc(line)}</p>
    </div>`;
  }

  function exitDecisionHTML() {
    const x = S.exitOffer;
    return `<div class="stage-center">
      <div class="kicker">Decision time</div>
      <div class="mega">Take ${inr(x.amountPaise)} or keep playing?</div>
      <p class="subline">Every survivor is choosing privately on their phone. Nobody will see what anyone else chose.</p>
      <p class="subline num" style="font-size:2rem;color:var(--white)"><span id="decided-num">${x.decided}</span> / ${x.offered} decisions received</p>
    </div>`;
  }

  function activeListHTML() {
    const names = S.activeNames || [];
    const big = names.length <= 12;
    return `<div class="active-list">
      <div class="active-head">
        <div class="kicker">After question ${S.qNumber}</div>
        <h1 class="mega" style="font-size:clamp(2.6rem,5vw,6rem)">Still in the game</h1>
        <p class="subline">${names.length} player${names.length === 1 ? '' : 's'} remaining${names.length && S.qNumber < S.qTotal - 1 ? `. ${S.qTotal - S.qNumber} question${S.qTotal - S.qNumber === 1 ? '' : 's'} to go` : ''}.</p>
      </div>
      <div class="active-names${big ? ' big' : names.length > 24 ? ' many' : ''}">${names.map((n, i) => `<span class="active-name" style="animation-delay:${Math.min(i * 60, 2400)}ms">${esc(n)}</span>`).join('')}</div>
    </div>`;
  }

  function exitResultHTML() {
    return `<div class="stage-center">
      <div class="kicker">Decisions locked</div>
      <div class="mega">${S.remaining}</div>
      <p class="subline">${S.remaining === 1 ? 'player continues' : 'players continue'} in the game.</p>
    </div>`;
  }

  function completeHTML() {
    const c = S.complete;
    if (c.reason === 'ended_by_host') {
      return `<div class="stage-center"><div class="kicker">Game ended</div><div class="mega">Thanks for playing</div><p class="subline">The host ended the game early. No final prize was awarded.</p></div>`;
    }
    if (c.mode === 'winners') {
      const one = c.winners.length === 1;
      return `<div class="stage-center">
        <div class="kicker">We have our Top 1%</div>
        <div class="winners">${c.winners.map((n, i) => `<div class="winner-name" style="animation-delay:${300 + i * 350}ms">${esc(n)}</div>`).join('')}</div>
        <p class="subline">${one ? `You are ${esc(S.gameName.replace(/\s*TOP\s*1%\s*$/i, '').replace(/'S$/i, "'s") || 'the')} Top 1%.` : 'Final prize split equally.'}</p>
        <div class="prize-line">Final prize: ${inr(c.finalPoolPaise)}${one ? '' : ` · ${inr(c.eachPaise)} each`}</div>
      </div>`;
    }
    const ruleLine = c.mode === 'last_standing'
      ? `The ${inr(c.finalPoolPaise)} final prize is shared equally by the ${c.recipients} player${c.recipients === 1 ? '' : 's'} who reached question ${c.lastQuestion}: ${inr(c.eachPaise)} each.`
      : `The ${inr(c.finalPoolPaise)} final prize is not awarded and stays with the organiser.`;
    return `<div class="stage-center">
      <div class="kicker">${esc(S.gameName)}</div>
      <div class="mega">No one reached the Top 1%</div>
      <p class="subline">${esc(ruleLine)}</p>
    </div>`;
  }

  function resultsHTML() {
    const r = S.results;
    if (!r) return '<p>No results.</p>';
    const f = r.final;
    const qRows = r.questions.map((q) => `<tr>
      <td>Q${q.number}</td><td class="q">${esc(q.text)}<div class="help">${esc(q.category || '')}${q.tricked ? ' · room tricked' : ''}</div></td>
      <td>${q.activeAtStart}</td><td>${q.survived ?? '–'}</td><td>${q.eliminated ?? '–'}${q.noAnswer ? ` <span class="help">(${q.noAnswer} no answer)</span>` : ''}</td>
      <td>${q.correctPct != null ? q.correctPct + '%' : '–'}</td>
      <td><div class="mini-bars">${OPTS.map((o) => `<span class="${o === q.correct ? 'c' : ''}">${o}: ${q.counts ? q.counts[o] : 0}</span>`).join('')}</div></td>
    </tr>`).join('');
    const exits = r.exits.map((x) => `<tr><td>After Q${x.afterQuestion}</td><td>${x.offered}</td><td>${x.exited}</td><td>${inr(x.perPlayerPaise)}${x.capped ? ' <span class="help">(fund shared)</span>' : ''}</td><td>${inr(x.totalPaise)}</td><td>${esc(x.names.join(', '))}</td></tr>`).join('');
    const pays = r.payouts.map((p) => `<tr><td>${esc(p.name)}</td><td>${esc(p.dept)}</td><td>${esc(p.type)}</td><td>${inr(p.amountPaise)}</td></tr>`).join('');
    const csv = `/api/results.csv?room=${S.kind}${pin ? `&pin=${encodeURIComponent(pin)}` : ''}`;
    return `<div class="results">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap">
        <h2>Host results${S.kind === 'demo' ? ' (demo data)' : ''}</h2>
        <a class="btn" href="${csv}" download>Download results (CSV)</a>
      </div>
      <div class="stat-row">
        <div class="stat"><div class="num">${r.totalPlayers}</div><div class="lbl">Total players</div></div>
        ${r.exitPoints.map((a) => `<div class="stat"><div class="num">${r.exits.find((x) => x.afterQuestion === a)?.exited ?? 0}</div><div class="lbl">Exited after Q${a}</div></div>`).join('')}
        <div class="stat"><div class="num">${r.reachedFinal}</div><div class="lbl">Reached the final question</div></div>
        <div class="stat"><div class="num">${r.finalCorrect ?? 0}</div><div class="lbl">Answered the final correctly</div></div>
      </div>
      ${f ? `<div class="stat-row">
        <div class="stat"><div class="num">${inr(f.totalPaise)}</div><div class="lbl">Total prize</div></div>
        <div class="stat"><div class="num">${inr(f.exitPaidPaise)}</div><div class="lbl">Paid as exits</div></div>
        <div class="stat"><div class="num">${inr(f.finalPoolPaise)}</div><div class="lbl">Final prize pool</div></div>
        <div class="stat"><div class="num">${inr(f.paidPaise)}</div><div class="lbl">Total paid out</div></div>
        <div class="stat"><div class="num">${inr(f.residuePaise + f.retainedPaise)}</div><div class="lbl">Not paid (rounding / retained)</div></div>
      </div>
      <p class="help">${f.mode === 'winners' ? `Winners: ${esc(f.winnerNames.join(', '))}, ${inr(f.eachPaise)} each.` : f.mode === 'last_standing' ? `No winner. Shared among: ${esc(f.recipientNames.join(', '))}, ${inr(f.eachPaise)} each.` : 'Final prize not awarded.'} Payouts reconcile to the total prize: ${f.reconciled ? 'yes' : 'NO — check'}.</p>` : ''}
      <h3>Question by question</h3>
      <table class="q-table"><thead><tr><th>#</th><th>Question</th><th>Playing</th><th>Survived</th><th>Eliminated</th><th>Correct</th><th>Answers</th></tr></thead><tbody>${qRows}</tbody></table>
      ${exits ? `<h3>Exit decisions</h3><table class="q-table"><thead><tr><th>Exit</th><th>Offered</th><th>Exited</th><th>Each</th><th>Total</th><th>Players</th></tr></thead><tbody>${exits}</tbody></table>` : ''}
      ${pays ? `<h3>Prize payouts</h3><table class="q-table"><thead><tr><th>Name</th><th>Department</th><th>Type</th><th>Amount</th></tr></thead><tbody>${pays}</tbody></table>` : ''}
    </div>`;
  }

  function afterStage() {
    // Animate distribution bars after insertion.
    requestAnimationFrame(() => {
      document.querySelectorAll('.opt .bar').forEach((b) => { b.style.width = (b.dataset.w || 0) + '%'; });
    });
    document.querySelectorAll('[data-remove]').forEach((b) => b.addEventListener('click', () => act('REMOVE_PLAYER', { playerId: b.dataset.remove })));
  }

  function updateLive() {
    const t = $('think-answered');
    if (t && S.phase === 'FINAL_QUESTION') {
      t.textContent = S.answered ?? 0;
      const still = Math.max(0, (S.answering || 0) - (S.answered || 0));
      $('think-line').textContent = `of ${S.answering} have answered. ${still ? `${still} ${still === 1 ? 'is' : 'are'} still thinking…` : 'Everyone has answered.'}`;
    }
    const d = $('decided-num');
    if (d && S.exitOffer) d.textContent = S.exitOffer.decided;
  }

  /* ----------------------------------------------------------- survival */
  function renderSurvival() {
    const el = $('survival');
    const hideIn = ['SETUP'];
    if (hideIn.includes(S.phase) || (S.phase === 'GAME_COMPLETE' && showResults)) { el.classList.add('hidden'); return; }
    el.classList.remove('hidden');
    if (S.phase === 'LOBBY') {
      el.innerHTML = `<div class="surv-count"><span class="num">${S.joined}</span><span class="lbl">players<br>joined</span></div>
        <div class="help" style="font-size:1rem">${S.connected} connected right now · registration ${S.allowLateJoin ? 'stays open after the start' : 'closes when the game starts'}</div><div></div>`;
      return;
    }
    const dots = S.dots.map((v) => `<span class="dot${v === 0 ? ' out' : v === 2 ? ' exit' : ''}"></span>`).join('');
    const open = S.phase === 'QUESTION_OPEN' || S.phase === 'FINAL_QUESTION';
    el.innerHTML = `<div class="surv-count"><span class="num">${S.remaining}</span><span class="lbl">player${S.remaining === 1 ? '' : 's'}<br>remaining</span></div>
      <div><div class="dots" aria-hidden="true">${dots}</div><div class="legend"><span><i style="background:var(--gold)"></i>In the game</span><span><i style="box-shadow:inset 0 0 0 2px var(--gold)"></i>Took the exit</span><span><i style="box-shadow:inset 0 0 0 2px #2C3B60"></i>Eliminated</span></div></div>
      <div class="answered">${open ? `<div class="num">${S.answered ?? 0} / ${S.answering ?? 0}</div><div class="lbl">answers received</div>` : ''}</div>`;
  }

  /* --------------------------------------------------------------- dock */
  let dockCollapsed = null; // null = automatic (compact during questions)
  function primary() {
    const ph = S.phase;
    const r = S.result;
    switch (ph) {
      case 'SETUP': return { label: S.kind === 'demo' ? 'Open demo lobby' : 'Open lobby', type: 'OPEN_LOBBY', disabled: S.validation && S.validation.errors.length > 0 };
      case 'LOBBY': return { label: 'Start game', type: 'START_GAME', disabled: S.joined < 1 };
      case 'QUESTION_READY': return { label: S.isFinal ? 'Open final question' : `Start question ${S.qNumber}`, type: 'START_QUESTION' };
      case 'QUESTION_OPEN': return { label: 'Lock answers', type: 'LOCK_ANSWERS' };
      case 'FINAL_QUESTION': return { label: 'Lock final answers', type: 'LOCK_ANSWERS', confirmIf: () => (S.answered || 0) < (S.answering || 0) };
      case 'QUESTION_LOCKED': return { label: 'Show what the room thought', type: 'SHOW_ROOM' };
      case 'ROOM_DISTRIBUTION': return { label: S.isFinal ? 'Reveal final answer' : 'Reveal answer', type: 'REVEAL_ANSWER' };
      case 'ANSWER_REVEAL': return { label: 'Show explanation', type: 'SHOW_EXPLANATION' };
      case 'EXPLANATION': return { label: S.isFinal ? 'Show who made it' : 'Show survivors', type: 'SHOW_SURVIVORS' };
      case 'SURVIVOR_UPDATE':
        if (S.remaining === 0) return { label: 'End game (nobody left)', type: 'DISTRIBUTE_FINAL' };
        if (S.isFinal) return { label: 'Distribute final prize', type: 'DISTRIBUTE_FINAL' };
        if (S.activeListDue) return { label: 'Show players still in', type: 'SHOW_ACTIVE' };
        // falls through to the same choices as the list screen
      case 'ACTIVE_LIST':
        if (S.prize.nextExit) return { label: `Offer exit (${inr(S.prize.nextExit.amountPaise)})`, type: 'OFFER_EXIT' };
        return { label: S.qNumber + 1 === S.qTotal ? 'Next: the final question' : 'Next question', type: 'NEXT_QUESTION' };
      case 'EXIT_DECISION': return { label: 'Confirm exits', type: 'CONFIRM_EXIT', confirmIf: () => S.exitOffer && S.exitOffer.decided < S.exitOffer.offered };
      case 'EXIT_RESULT':
        if (S.remaining === 0) return { label: 'End game (nobody left)', type: 'DISTRIBUTE_FINAL' };
        return { label: S.qNumber + 1 === S.qTotal ? 'Next: the final question' : 'Next question', type: 'NEXT_QUESTION' };
      case 'GAME_COMPLETE': return { label: showResults ? 'Show winners screen' : 'Show host results', local: () => { showResults = !showResults; render(); } };
      default: return null;
    }
  }

  async function runPrimary() {
    const p = primary();
    if (!p || p.disabled) return;
    if (p.local) return p.local();
    if (p.confirmIf && p.confirmIf()) {
      const isFinal = p.type === 'LOCK_ANSWERS';
      const still = isFinal ? (S.answering - S.answered) : (S.exitOffer.offered - S.exitOffer.decided);
      const ok = await confirmDialog(
        isFinal ? 'Lock the final answers now?' : 'Confirm exits now?',
        isFinal
          ? `${still} player${still === 1 ? ' is' : 's are'} still thinking. Anyone who has not answered will be eliminated.`
          : `${still} player${still === 1 ? ' has' : 's have'} not decided yet. Undecided players will continue playing.`,
        isFinal ? 'Lock answers' : 'Confirm exits');
      if (!ok) return;
    }
    Sound.unlock();
    act(p.type);
  }

  function renderDock() {
    const dock = $('dock');
    const p = primary();
    const ph = S.phase;
    const sec = [];
    const add = (label, fn, opts = {}) => sec.push({ label, fn, ...opts });
    if (ph === 'LOBBY') {
      add(`Late joining: ${S.allowLateJoin ? 'On' : 'Off'}`, () => act('SET_LATE_JOIN', { value: !S.allowLateJoin }));
      if (S.kind === 'demo') {
        add('Add 40 demo players', () => act('ADD_BOTS', { count: 40 }));
        add('Remove demo players', () => act('REMOVE_BOTS'));
      }
      add('Back to setup', () => act('BACK_TO_SETUP'));
    }
    if (ph === 'ANSWER_REVEAL') add('Skip to survivors', () => act('SHOW_SURVIVORS'));
    if (ph === 'QUESTION_LOCKED') add('Reveal answer now', () => act('REVEAL_ANSWER'));
    if ((ph === 'SURVIVOR_UPDATE' || ph === 'EXIT_RESULT') && S.question) add('Show explanation again', () => act('SHOW_EXPLANATION'));
    if (['SURVIVOR_UPDATE', 'EXIT_RESULT'].includes(ph) && !S.isFinal && S.remaining > 0 && !S.activeListDue) add('Show players still in', () => act('SHOW_ACTIVE'));
    if (ph === 'SURVIVOR_UPDATE' && S.activeListDue) add('Skip the player list', () => act(S.prize.nextExit ? 'OFFER_EXIT' : 'NEXT_QUESTION'));
    if (['SURVIVOR_UPDATE', 'ACTIVE_LIST'].includes(ph) && S.prize.nextExit && S.remaining > 0) {
      add('Skip this exit offer', async () => {
        if (await confirmDialog('Skip the exit offer?', `Players will not be offered ${inr(S.prize.nextExit.amountPaise)} after question ${S.qNumber}. This cannot be undone.`, 'Skip exit')) act('NEXT_QUESTION', { skipExit: true });
      });
    }
    if (!['SETUP', 'LOBBY', 'GAME_COMPLETE'].includes(ph)) {
      add(S.paused ? 'Resume (P)' : 'Pause (P)', () => act(S.paused ? 'RESUME' : 'PAUSE'));
      if (!S.isFinal) add(`Late joining: ${S.allowLateJoin ? 'On' : 'Off'}`, () => act('SET_LATE_JOIN', { value: !S.allowLateJoin }));
    }
    if (ph === 'FINAL_QUESTION') add('Who has answered? (H)', togglePrivate);
    if (!['SETUP', 'GAME_COMPLETE'].includes(ph)) {
      add('End game', async () => {
        if (await confirmDialog('End the game now?', 'The game stops immediately and no final prize is awarded. Exit payouts already confirmed still stand.', 'End game')) act('END_GAME');
      }, { danger: true });
    }
    if (ph !== 'SETUP') {
      add(ph === 'GAME_COMPLETE' ? 'New game (reset)' : 'Reset game', async () => {
        if (await confirmDialog('Reset the game?', 'All players, answers and results for this room are cleared and a new room code is created. Players will need to scan again.', 'Reset game')) act('RESET_GAME');
      }, { danger: true });
    }

    const status = dockStatus();
    const auto = !['SETUP', 'GAME_COMPLETE'].includes(ph);
    const collapsed = dockCollapsed == null ? auto : dockCollapsed;
    dock.className = 'dock' + (collapsed ? ' collapsed' : '');
    dock.innerHTML = `<div class="dock-head"><span>Host controls${S.kind === 'demo' ? ' · demo' : ''}</span><button class="btn btn-ghost icon-btn" id="dock-toggle" title="More or fewer controls (C)">${collapsed ? 'More (C)' : 'Less (C)'}</button></div>
      <div class="dock-body">
        ${status ? `<div class="status">${status}</div>` : ''}
        ${p ? `<button class="btn btn-gold primary" id="dock-primary" ${p.disabled ? 'disabled' : ''}>${esc(p.label)}</button><div class="hint">Press <kbd>Space</kbd> for the gold button · <kbd>P</kbd> pause · <kbd>M</kbd> mute · <kbd>F</kbd> full screen</div>` : ''}
        ${sec.length ? `<div class="row">${sec.map((s, i) => `<button class="btn${s.danger ? ' btn-danger' : ''}" data-sec="${i}">${esc(s.label)}</button>`).join('')}</div>` : ''}
      </div>`;
    $('dock-toggle').onclick = () => { dockCollapsed = !collapsed; renderDock(); };
    requestAnimationFrame(() => document.documentElement.style.setProperty('--dock-w', (dock.offsetWidth + 16) + 'px'));
    const pb = $('dock-primary');
    if (pb) pb.onclick = runPrimary;
    dock.querySelectorAll('[data-sec]').forEach((b) => { b.onclick = () => sec[Number(b.dataset.sec)].fn(); });
  }

  function dockStatus() {
    const ph = S.phase;
    const pz = S.prize;
    const pool = `Prize ${inr(pz.totalPaise)} · exits paid <b>${inr(pz.exitPaidPaise)}</b> · final pool <b>${inr(pz.poolPaise)}</b>`;
    if (ph === 'SETUP') return S.validation && S.validation.errors.length ? `<b>${S.validation.errors.length} issue${S.validation.errors.length === 1 ? '' : 's'}</b> to fix before the lobby can open.` : 'Configuration is valid.';
    if (ph === 'LOBBY') return `${S.connected} of ${S.joined} phones connected.`;
    if (ph === 'EXIT_RESULT' && S.exitResult) {
      const x = S.exitResult;
      return `${x.exited} player${x.exited === 1 ? '' : 's'} exited at ${inr(x.perPlayerPaise)} each${x.capped ? ' (exit fund shared equally)' : ''}${x.undecided ? `; ${x.undecided} undecided continued` : ''}.<br>${pool}`;
    }
    if (ph === 'GAME_COMPLETE') return pool;
    return pool;
  }

  /* -------------------------------------------- private "who's thinking" */
  let privateOpen = false;
  function togglePrivate() { privateOpen = !privateOpen; renderPrivate(); }
  function renderPrivate() {
    const el = $('private');
    if (!privateOpen || !S.finalThinking) { el.classList.add('hidden'); return; }
    el.classList.remove('hidden');
    el.innerHTML = `<h3>Visible on the big screen. Close with H.</h3><ul>${S.finalThinking.map((p) => `<li><span>${esc(p.name)}</span><span>${p.answered ? '✓ Answered' : '… Thinking'}</span></li>`).join('')}</ul>`;
  }

  /* -------------------------------------------------------------- timer */
  function loop() {
    requestAnimationFrame(loop);
    if (!S) return;
    const tn = $('t-num');
    if (!tn) return;
    const total = (S.timerSecs || 1) * 1000;
    let ms = S.phase === 'QUESTION_OPEN' ? remainingMs(S) : 0;
    if (ms == null) ms = 0;
    tn.textContent = mmss(ms);
    const frac = Math.max(0, Math.min(1, ms / total));
    const prog = $('t-prog');
    if (prog) prog.setAttribute('stroke-dashoffset', String(339.3 * (1 - frac)));
    const timer = $('timer');
    const sec = Math.ceil(ms / 1000);
    timer.classList.toggle('warn', sec <= 10 && sec > 5);
    timer.classList.toggle('crit', sec <= 5);
    if (S.phase === 'QUESTION_OPEN' && !S.paused && sec !== lastTickSec) {
      if (sec <= 5 && sec > 0) Sound.play('tickUrgent');
      else if (sec <= 10 && sec > 0) Sound.play('tick');
      lastTickSec = sec;
    }
  }
  requestAnimationFrame(loop);

  /* -------------------------------------------------------------- setup */
  function setupHTML() {
    const tab = (id, label) => `<button role="tab" aria-selected="${setupTab === id}" data-tab="${id}">${label}</button>`;
    return `<div class="setup">
      <div>
        <h2>Game setup</h2>
        <p class="lead">Check the settings and questions, then open the lobby. Players scan the QR code on the next screen.</p>
        <div class="mode-switch" role="group" aria-label="Game mode">
          <button data-mode="live" aria-pressed="${mode === 'live'}">Live game</button>
          <button data-mode="demo" aria-pressed="${mode === 'demo'}">Demo mode</button>
        </div>
        <p class="help" style="margin-top:-0.6rem">${mode === 'demo'
          ? 'Demo mode runs in a separate room with its own code. Add simulated players labelled DEMO PLAYER and play the whole game end to end. Nothing here touches the live game.'
          : 'Live game: the real event. Progress is saved on the server, so closing this browser does not lose anything.'}</p>
        <div class="tabs" role="tablist">${tab('game', 'Game settings')}${tab('questions', 'Questions')}${tab('network', 'Join address')}</div>
        <div id="tab-body">${setupTab === 'game' ? configFormHTML() : setupTab === 'questions' ? questionsHTML() : networkHTML()}</div>
      </div>
      <div class="side-card">
        <h3>Ready to start?</h3>
        <ul class="checks" id="checks"></ul>
      </div>
    </div>`;
  }

  function configFormHTML() {
    const c = S.store.config;
    const f = (id, label, val, extra = '', help = '') => `<div class="field"><label for="c-${id}">${label}</label><input id="c-${id}" class="input" value="${esc(val)}" ${extra}>${help ? `<span class="help">${help}</span>` : ''}</div>`;
    return `<form id="cfg-form" class="form-grid">
      ${f('gameName', 'Game name', c.gameName, 'maxlength="40"')}
      ${f('tagline', 'Tagline', c.tagline, 'maxlength="80"')}
      ${f('totalPrize', 'Total prize (₹)', c.totalPrize, 'type="number" min="1" step="1"')}
      ${f('questionCount', 'Question count', c.questionCount, 'type="number" min="6" max="30"', 'The last question is the final question.')}
      ${f('exitOneAfter', 'First exit: after question', c.exitOneAfter, 'type="number" min="1" max="29"')}
      ${f('exitOneAmount', 'First exit (₹ per player)', c.exitOneAmount, 'type="number" min="0" step="1"', 'Set 0 to switch this exit off.')}
      ${f('exitTwoAfter', 'Second exit: after question', c.exitTwoAfter, 'type="number" min="1" max="29"', `Use ${c.questionCount - 1} to offer it just before the final.`)}
      ${f('exitTwoAmount', 'Second exit (₹ per player)', c.exitTwoAmount, 'type="number" min="0" step="1"', 'Set 0 to switch this exit off.')}
      ${f('exitCapPct', 'Exit fund cap (% of remaining pool)', c.exitCapPct, 'type="number" min="10" max="90"', 'Most an exit round can pay out in total. Keeps money for the final.')}
      ${f('timerEarly', 'Q1–8 timer (seconds)', c.timerEarly, 'type="number" min="5" max="600"')}
      ${f('timerLate', `Q9–${c.questionCount - 1} timer (seconds)`, c.timerLate, 'type="number" min="5" max="600"')}
      <div class="field"><label>Q${c.questionCount} timer</label><input class="input" value="No limit" disabled><span class="help">The final question stays open until everyone answers or you lock it.</span></div>
      ${f('playerLimit', 'Player limit', c.playerLimit, 'type="number" min="2" max="200"')}
      ${f('showActiveEvery', 'Show players still in, every … questions', c.showActiveEvery, 'type="number" min="0" max="30"', 'Names appear on the big screen after these questions. 0 switches it off.')}
      <div class="field"><label for="c-noWinnerRule">If nobody answers the final correctly</label>
        <select id="c-noWinnerRule" class="input">
          <option value="split_last_standing" ${c.noWinnerRule === 'split_last_standing' ? 'selected' : ''}>Share it among the players who reached the last question played</option>
          <option value="retained" ${c.noWinnerRule === 'retained' ? 'selected' : ''}>Do not award it (stays with the organiser)</option>
        </select></div>
      <div class="field wide"><label for="c-departments">Departments (one per line; players can also type their own)</label><textarea id="c-departments" class="input" rows="4">${esc(c.departments.join('\n'))}</textarea></div>
      <div class="wide" style="display:flex;gap:0.6rem;flex-wrap:wrap">
        <button class="btn btn-gold" type="submit">Save settings</button>
        <button class="btn btn-ghost" type="button" id="cfg-defaults">Restore default settings</button>
        <span class="help" id="cfg-msg" style="align-self:center"></span>
      </div>
    </form>`;
  }

  function questionsHTML() {
    const qs = S.store.questions;
    const n = S.store.config.questionCount;
    const rows = qs.map((q, i) => `<tr class="${i >= n ? 'extra' : ''}">
      <td>${i + 1}${i === n - 1 ? '<div class="help">Final</div>' : ''}${i >= n ? '<div class="help">Not used</div>' : ''}</td>
      <td class="q">${esc(q.question)}<div class="help">${esc(q.category || '')}</div></td>
      <td>${esc(q.correctAnswer || '–')}</td>
      <td>${esc(q.difficulty || '')}</td>
      <td>${i === n - 1 ? 'No limit' : q.timer ? q.timer + 's*' : (i < 8 ? S.store.config.timerEarly : S.store.config.timerLate) + 's'}</td>
      <td class="actions">
        <button class="btn" data-qedit="${i}">Edit</button>
        <button class="btn" data-qup="${i}" ${i === 0 ? 'disabled' : ''} aria-label="Move up">↑</button>
        <button class="btn" data-qdown="${i}" ${i === qs.length - 1 ? 'disabled' : ''} aria-label="Move down">↓</button>
        <button class="btn btn-danger" data-qdel="${i}">Delete</button>
      </td></tr>`).join('');
    return `<div style="display:flex;gap:0.6rem;margin-bottom:1rem;flex-wrap:wrap">
        <button class="btn btn-gold" id="q-add">Add question</button>
        <button class="btn btn-ghost" id="q-defaults">Restore the 13 original questions</button>
      </div>
      <p class="help">The first ${n} questions are played in order. Correct answers are never sent to phones before the reveal. * = timer override.</p>
      <table class="q-table"><thead><tr><th>#</th><th>Question</th><th>Answer</th><th>Difficulty</th><th>Timer</th><th></th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  function networkHTML() {
    const a = S.address || {};
    if (a.public) {
      return `<div style="display:grid;gap:1rem;max-width:640px">
        <div><div class="help">Players open</div><div class="room-code" style="font-size:1.6rem">${esc(a.url)}</div></div>
        <p class="help">The game is running on the internet. Players can use mobile data or any Wi-Fi. This address comes from the server setting PUBLIC_URL (set automatically on Render and Railway).</p>
        <p class="help">If the address is wrong, change PUBLIC_URL in your hosting dashboard and redeploy.</p>
      </div>`;
    }
    const list = (a.candidates || []).map((c) => `<label><input type="radio" name="ip" value="${esc(c.ip)}" ${a.ip === c.ip ? 'checked' : ''}> <strong>${esc(c.ip)}</strong> <span class="help">${esc(c.name)}</span></label>`).join('');
    return `<div style="display:grid;gap:1.2rem;max-width:640px">
      <div><div class="help">Players will open</div><div class="room-code" style="font-size:1.6rem">${a.url ? esc(a.url) : 'No address found'}</div></div>
      ${list ? `<div class="addr-list">${list}</div><p class="help">If phones cannot open the address, pick the one that matches your Wi-Fi adapter (usually 192.168.x.x).</p>` : '<p class="help">This laptop has no Wi-Fi/LAN address. Connect it to the same Wi-Fi the phones will use, then refresh.</p>'}
      <div class="field"><label for="ip-manual">Or type the address manually</label>
        <div style="display:flex;gap:0.5rem"><input id="ip-manual" class="input" placeholder="192.168.1.15" value="${a.manual ? esc(a.ip) : ''}"><button class="btn" id="ip-save">Use address</button><button class="btn btn-ghost" id="ip-auto">Automatic</button></div>
        <span class="help">On Windows: run <code>ipconfig</code> and use the IPv4 address of the Wi-Fi adapter. On Mac: System Settings → Wi-Fi → Details.</span></div>
      <p class="help">If phones time out: allow Node.js through the Windows firewall on Private networks, and make sure the Wi-Fi does not use guest/client isolation.</p>
    </div>`;
  }

  function bindSetup() {
    document.querySelectorAll('[data-mode]').forEach((b) => b.addEventListener('click', () => {
      if (b.dataset.mode === mode) return;
      mode = b.dataset.mode;
      localStorage.setItem('t1-mode', mode);
      stageKey = '';
      hello();
    }));
    document.querySelectorAll('[data-tab]').forEach((b) => b.addEventListener('click', () => { setupTab = b.dataset.tab; stageKey = ''; render(); }));
    const form = $('cfg-form');
    if (form) {
      configDirty = false;
      form.addEventListener('input', () => { configDirty = true; $('cfg-msg').textContent = 'Unsaved changes'; });
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const v = (id) => $('c-' + id).value;
        const cfg = {
          gameName: v('gameName'), tagline: v('tagline'), totalPrize: v('totalPrize'), questionCount: v('questionCount'),
          exitOneAfter: v('exitOneAfter'), exitOneAmount: v('exitOneAmount'),
          exitTwoAfter: v('exitTwoAfter'), exitTwoAmount: v('exitTwoAmount'), exitCapPct: v('exitCapPct'),
          timerEarly: v('timerEarly'), timerLate: v('timerLate'), playerLimit: v('playerLimit'), showActiveEvery: v('showActiveEvery'),
          noWinnerRule: v('noWinnerRule'), departments: v('departments').split('\n').map((s) => s.trim()).filter(Boolean),
        };
        socket.emit('host:saveConfig', cfg, (res) => {
          if (res && res.ok) { configDirty = false; $('cfg-msg').textContent = 'Saved'; stageKey = ''; }
          else toast((res && res.error) || 'Could not save settings.');
        });
      });
      $('cfg-defaults').onclick = async () => {
        if (await confirmDialog('Restore default settings?', 'Prize, exit amounts, timers and limits go back to the defaults. Questions are not changed.', 'Restore')) {
          socket.emit('host:restoreDefaults', 'config', () => { stageKey = ''; });
        }
      };
    }
    const qadd = $('q-add');
    if (qadd) {
      qadd.onclick = () => openQuestion(null);
      $('q-defaults').onclick = async () => {
        if (await confirmDialog('Restore the original questions?', 'Your edited and added questions will be replaced by the 13 original questions.', 'Restore')) {
          socket.emit('host:restoreDefaults', 'questions', () => { stageKey = ''; });
        }
      };
      bindQuestionRows();
    }
    const ipSave = $('ip-save');
    if (ipSave) {
      ipSave.onclick = () => socket.emit('host:setIp', $('ip-manual').value, (r) => { if (!r.ok) toast(r.error); else stageKey = ''; });
      $('ip-auto').onclick = () => socket.emit('host:setIp', '', () => { stageKey = ''; });
      document.querySelectorAll('input[name="ip"]').forEach((r) => r.addEventListener('change', () => socket.emit('host:setIp', r.value, () => { stageKey = ''; })));
    }
  }

  function bindQuestionRows() {
    const qs = () => S.store.questions.map((q) => ({ ...q }));
    const save = (list) => socket.emit('host:saveQuestions', list, (r) => { if (!r.ok) toast(r.error); stageKey = ''; });
    document.querySelectorAll('[data-qedit]').forEach((b) => { b.onclick = () => openQuestion(Number(b.dataset.qedit)); });
    document.querySelectorAll('[data-qup]').forEach((b) => { b.onclick = () => { const l = qs(); const i = Number(b.dataset.qup); [l[i - 1], l[i]] = [l[i], l[i - 1]]; save(l); }; });
    document.querySelectorAll('[data-qdown]').forEach((b) => { b.onclick = () => { const l = qs(); const i = Number(b.dataset.qdown); [l[i + 1], l[i]] = [l[i], l[i + 1]]; save(l); }; });
    document.querySelectorAll('[data-qdel]').forEach((b) => {
      b.onclick = async () => {
        const i = Number(b.dataset.qdel);
        if (await confirmDialog(`Delete question ${i + 1}?`, S.store.questions[i].question, 'Delete')) { const l = qs(); l.splice(i, 1); save(l); }
      };
    });
  }

  const QF = ['question', 'optionA', 'optionB', 'optionC', 'optionD', 'correctAnswer', 'category', 'difficulty', 'timer', 'trapAnswer', 'explanation'];
  function openQuestion(i) {
    editingIndex = i;
    const q = i == null ? {} : S.store.questions[i];
    $('q-form-title').textContent = i == null ? 'Add question' : `Edit question ${i + 1}`;
    QF.forEach((k) => { $('f-' + k).value = q[k] == null ? '' : q[k]; });
    $('dlg-q').showModal();
  }
  $('q-form').addEventListener('submit', (e) => {
    if (e.submitter && e.submitter.value === 'cancel') return;
    const q = {};
    QF.forEach((k) => { q[k] = $('f-' + k).value; });
    const opts = ['optionA', 'optionB', 'optionC', 'optionD'].map((k) => q[k].trim().toLowerCase());
    if (new Set(opts).size !== 4) { e.preventDefault(); toast('The four options must all be different.'); return; }
    const list = S.store.questions.map((x) => ({ ...x }));
    if (editingIndex == null) list.push(q); else list[editingIndex] = { ...list[editingIndex], ...q };
    socket.emit('host:saveQuestions', list, (r) => { if (!r.ok) toast(r.error); stageKey = ''; });
  });

  function refreshSetup() {
    const ul = $('checks');
    if (ul && S.validation) {
      const v = S.validation;
      ul.innerHTML = (v.errors.length ? v.errors.map((m) => `<li class="err"><span aria-hidden="true">✕</span><span><span class="sr-only">Error: </span>${esc(m)}</span></li>`).join('')
        : `<li class="ok"><span aria-hidden="true">✓</span><span>${S.store.questions.length >= S.store.config.questionCount ? `${S.store.config.questionCount} questions ready, each with four options and one correct answer.` : ''} Prize and timers are valid.</span></li>`)
        + v.warnings.map((m) => `<li class="warn"><span aria-hidden="true">!</span><span><span class="sr-only">Note: </span>${esc(m)}</span></li>`).join('');
    }
  }

  /* ----------------------------------------------------------- keyboard */
  document.addEventListener('keydown', (e) => {
    if (e.target.closest('input, textarea, select, dialog')) return;
    if (e.key === ' ' || e.key === 'Enter') {
      if (e.target.closest('button') && e.key === 'Enter') return;
      e.preventDefault();
      runPrimary();
    } else if (e.key === 'p' || e.key === 'P') {
      if (S && !['SETUP', 'LOBBY', 'GAME_COMPLETE'].includes(S.phase)) act(S.paused ? 'RESUME' : 'PAUSE');
    } else if (e.key === 'm' || e.key === 'M') {
      toggleMute();
    } else if (e.key === 'f' || e.key === 'F') {
      toggleFull();
    } else if (e.key === 'c' || e.key === 'C') {
      const auto = S && !['SETUP', 'GAME_COMPLETE'].includes(S.phase);
      dockCollapsed = !(dockCollapsed == null ? auto : dockCollapsed); renderDock();
    } else if (e.key === 'h' || e.key === 'H') {
      togglePrivate();
    }
  });

  function toggleMute() {
    const m = Sound.toggle();
    $('btn-mute').textContent = m ? 'Sound off' : 'Sound on';
    $('btn-mute').setAttribute('aria-pressed', String(m));
  }
  function toggleFull() {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen?.();
    else document.exitFullscreen?.();
  }
  $('btn-mute').textContent = Sound.muted ? 'Sound off' : 'Sound on';
  $('btn-mute').onclick = () => { Sound.unlock(); toggleMute(); };
  $('btn-full').onclick = toggleFull;
  document.addEventListener('click', () => Sound.unlock(), { once: true });
})();
