/* Shared client helpers. Plain browser JS, no build step. */
(function () {
  const T1 = {};

  T1.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  T1.inr = (paise) => {
    const r = Math.round(paise) / 100;
    return '₹' + r.toLocaleString('en-IN', { minimumFractionDigits: Number.isInteger(r) ? 0 : 2, maximumFractionDigits: 2 });
  };
  T1.inrRupees = (r) => T1.inr(Math.round(Number(r) * 100));

  T1.wordmark = (name) => {
    // Renders the brand lockup. Falls back to plain text for a renamed game.
    const n = String(name || '');
    const m = n.match(/^(.*?)\s*TOP\s*1%\s*$/i);
    if (!m) return `<span class="wordmark"><span class="wm-top">${T1.esc(n)}</span></span>`;
    return `<span class="wordmark" aria-label="${T1.esc(n)}">${m[1] ? `<span class="wm-name">${T1.esc(m[1].trim())}</span>` : ''}<span class="wm-top">TOP</span><span class="wm-ring">1%</span></span>`;
  };

  /* Clock offset: serverTime ≈ Date.now() + offset. Best of several pings. */
  T1.offset = 0;
  T1.syncClock = (socket) => {
    let best = Infinity;
    let n = 0;
    const ping = () => {
      const sent = Date.now();
      socket.timeout(3000).emit('time:ping', sent, (err, res) => {
        if (!err && res) {
          const now = Date.now();
          const rtt = now - sent;
          if (rtt < best) { best = rtt; T1.offset = res.serverNow + rtt / 2 - now; }
        }
        if (++n < 5) setTimeout(ping, 150);
      });
    };
    ping();
  };
  T1.serverNow = () => Date.now() + T1.offset;

  T1.remainingMs = (state) => {
    if (!state) return null;
    if (state.paused && state.pausedRemaining != null) return state.pausedRemaining;
    if (!state.deadline) return null;
    return Math.max(0, state.deadline - T1.serverNow());
  };

  T1.mmss = (ms) => {
    const s = Math.ceil(ms / 1000);
    return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  };

  T1.connect = (onStatus) => {
    const socket = io({ transports: ['websocket', 'polling'], reconnectionDelay: 500, reconnectionDelayMax: 3000 });
    socket.on('connect', () => { onStatus && onStatus(true); T1.syncClock(socket); });
    socket.on('disconnect', () => onStatus && onStatus(false));
    return socket;
  };

  window.T1 = T1;
})();
