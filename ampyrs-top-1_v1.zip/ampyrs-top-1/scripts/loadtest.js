'use strict';
/**
 * Load test: starts a throwaway server (temporary data folder, port 3999),
 * connects N real Socket.IO "phones" and plays a complete game through the
 * same events the browser uses. Your real game data is never touched.
 *   npm run loadtest            (100 players)
 *   node scripts/loadtest.js 150
 */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { io } = require('socket.io-client');

const N = Number(process.argv[2]) || 100;
const PORT = 3999;
const URL = `http://127.0.0.1:${PORT}`;
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 't1-load-'));
fs.writeFileSync(path.join(dataDir, 'config.json'), JSON.stringify({ playerLimit: Math.min(200, Math.max(N, 2)), timerEarly: 6, timerLate: 6 }));

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const emit = (s, ev, ...args) => new Promise((res, rej) => s.timeout(8000).emit(ev, ...args, (err, r) => (err ? rej(err) : res(r))));

(async () => {
  const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, PORT: String(PORT), DATA_DIR: dataDir }, stdio: ['ignore', 'pipe', 'inherit'],
  });
  await new Promise((r) => srv.stdout.on('data', (d) => { if (String(d).includes('running')) r(); }));
  const t0 = Date.now();
  let hostState = null;
  const host = io(URL, { transports: ['websocket'] });
  host.on('host:state', (s) => { hostState = s; });
  await new Promise((r) => host.on('connect', r));
  const hello = await emit(host, 'host:hello', { room: 'live' });
  if (!hello.ok) throw new Error('host hello failed');
  const act = async (type, payload) => { const r = await emit(host, 'host:action', { type, payload }); if (!r.ok) throw new Error(`${type}: ${r.error}`); };

  // A non-host socket must not be able to drive the game.
  const rogue = io(URL, { transports: ['websocket'], forceNew: true });
  await new Promise((r) => rogue.on('connect', r));
  const rg = await emit(rogue, 'host:action', { type: 'OPEN_LOBBY' });
  console.log('non-host action refused:', !rg.ok);
  rogue.close();

  await act('OPEN_LOBBY');
  await wait(200);
  const code = hostState.code;
  const players = [];
  const states = new Map();
  await Promise.all(Array.from({ length: N }, async (_, i) => {
    const s = io(URL, { transports: ['websocket'], forceNew: true });
    s.on('player:state', (st) => states.set(i, st));
    await new Promise((r) => s.on('connect', r));
    const r = await emit(s, 'player:join', { code, name: `Load ${i}`, dept: 'QA' });
    if (!r.ok) throw new Error('join failed: ' + r.error);
    players.push({ i, s, token: r.token });
  }));
  await wait(400);
  console.log(`${players.length} players joined in ${Date.now() - t0} ms; host sees ${hostState.joined} joined, ${hostState.connected} connected`);

  const dupe = io(URL, { transports: ['websocket'], forceNew: true });
  await new Promise((r) => dupe.on('connect', r));
  const d = await emit(dupe, 'player:join', { code, name: 'load 0', dept: 'QA' });
  console.log('duplicate name rejected:', !d.ok);

  await act('START_GAME');
  const late = await emit(dupe, 'player:join', { code, name: 'Latecomer', dept: 'QA' });
  console.log('registration locked after start:', !late.ok);
  dupe.close();

  const correct = ['B', 'B', 'C', 'B', 'C', 'D', 'B', 'B', 'D', 'B', 'C', 'B', 'C'];
  for (let q = 0; q < 13; q++) {
    await act('START_QUESTION');
    await wait(150);
    const st0 = states.get(players[0].i);
    if (st0.question && st0.question.correct) throw new Error('correct answer leaked before reveal');
    const active = players.filter((p) => states.get(p.i)?.me.status === 'active');
    const wrongRate = q === 12 ? 0.5 : 0.15;
    const results = await Promise.all(active.map((p) => emit(p.s, 'player:answer', Math.random() < wrongRate ? (correct[q] === 'A' ? 'D' : 'A') : correct[q])));
    const okCount = results.filter((r) => r.ok).length;
    if (active[0]) { const again = await emit(active[0].s, 'player:answer', 'C'); if (again.ok) throw new Error('double answer accepted'); }
    if (q === 3 && active[1]) {
      const p = active[1];
      p.s.close();
      const s2 = io(URL, { transports: ['websocket'], forceNew: true });
      s2.on('player:state', (st) => states.set(p.i, st));
      await new Promise((r) => s2.on('connect', r));
      const r = await emit(s2, 'player:resume', { code, token: p.token });
      p.s = s2;
      await wait(150);
      console.log('  phone reconnected and resumed with answer kept:', r.ok && !!states.get(p.i).me.answer);
    }
    await wait(250);
    await act('LOCK_ANSWERS');
    await act('SHOW_ROOM');
    await act('REVEAL_ANSWER');
    await act('SHOW_SURVIVORS');
    await wait(300);
    console.log(`Q${q + 1}: ${okCount}/${active.length} answers accepted, ${hostState.remaining} remain`);
    if (q === 12 || hostState.remaining === 0) break;
    if (q === 9 || q === 11) { // default exits: after Q10 and after Q12
      await act('OFFER_EXIT');
      await wait(150);
      const act2 = players.filter((p) => states.get(p.i)?.me.status === 'active');
      await Promise.all(act2.map((p, k) => emit(p.s, 'player:exit', k % 9 === 0 ? 'exit' : 'continue')));
      await act('CONFIRM_EXIT');
      await wait(200);
      const x = hostState.exitResult;
      console.log(`  exit after Q${q + 1}: ${x.exited} exited at ₹${x.perPlayerPaise / 100} each${x.capped ? ' (exit fund shared)' : ''}`);
    }
    await act('NEXT_QUESTION');
  }
  await act('DISTRIBUTE_FINAL');
  await wait(300);
  const f = hostState.results.final;
  console.log(`Final: ${f.mode}, ${f.winners.length} winner(s), final pool ₹${f.finalPoolPaise / 100}, each ₹${f.eachPaise / 100}, paid ₹${f.paidPaise / 100} of ₹${f.totalPaise / 100}, reconciled=${f.reconciled}`);
  const leak = [...states.values()].some((st) => /prizePaise|exitPayoutPaise|"token"/.test(JSON.stringify(st)));
  console.log('player payloads free of money and tokens:', !leak);
  console.log(`Total ${Date.now() - t0} ms`);
  players.forEach((p) => p.s.close());
  host.close();
  srv.kill();
  fs.rmSync(dataDir, { recursive: true, force: true });
  process.exit(f.reconciled && !leak ? 0 : 1);
})().catch((e) => { console.error('LOAD TEST FAILED:', e); process.exit(1); });
