'use strict';
const crypto = require('crypto');
const EventEmitter = require('events');
const prize = require('./prize');
const { cleanText, writeAtomic, readJSON } = require('./store');

const OPTS = ['A', 'B', 'C', 'D'];
const GRACE_MS = 400; // network latency allowance after the deadline

const P = {
  SETUP: 'SETUP',
  LOBBY: 'LOBBY',
  QUESTION_READY: 'QUESTION_READY',
  QUESTION_OPEN: 'QUESTION_OPEN',
  FINAL_QUESTION: 'FINAL_QUESTION',
  QUESTION_LOCKED: 'QUESTION_LOCKED',
  ROOM_DISTRIBUTION: 'ROOM_DISTRIBUTION',
  ANSWER_REVEAL: 'ANSWER_REVEAL',
  EXPLANATION: 'EXPLANATION',
  SURVIVOR_UPDATE: 'SURVIVOR_UPDATE',
  EXIT_DECISION: 'EXIT_DECISION',
  EXIT_RESULT: 'EXIT_RESULT',
  ACTIVE_LIST: 'ACTIVE_LIST',
  GAME_COMPLETE: 'GAME_COMPLETE',
};
const OPEN_PHASES = new Set([P.QUESTION_OPEN, P.FINAL_QUESTION]);
const QUESTION_VISIBLE = new Set([
  P.QUESTION_OPEN, P.FINAL_QUESTION, P.QUESTION_LOCKED, P.ROOM_DISTRIBUTION,
  P.ANSWER_REVEAL, P.EXPLANATION, P.SURVIVOR_UPDATE,
]);
const REVEALED = new Set([P.ANSWER_REVEAL, P.EXPLANATION, P.SURVIVOR_UPDATE]);
const DIST_VISIBLE = new Set([P.ROOM_DISTRIBUTION, ...REVEALED]);

const DIFFICULTY_ACCURACY = {
  'very easy': 0.98, easy: 0.95, 'easy–moderate': 0.88, 'easy-moderate': 0.88, moderate: 0.88,
  'moderate–hard': 0.85, 'moderate-hard': 0.85, hard: 0.82, 'very hard': 0.8, elite: 0.78,
  'extremely difficult': 0.75, 'top 1%': 0.4,
};

const randId = (bytes = 9) => crypto.randomBytes(bytes).toString('hex');
const normName = (s) => String(s).toLowerCase().replace(/\s+/g, ' ').trim();
const CODE_CHARS = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // no 0/O, 1/I
const genCode = (prefix) => prefix + '-' + Array.from({ length: 4 }, () => CODE_CHARS[crypto.randomInt(CODE_CHARS.length)]).join('');

class GameRoom extends EventEmitter {
  constructor({ kind, store, persistFile = null }) {
    super();
    this.kind = kind; // 'live' | 'demo'
    this.store = store;
    this.persistFile = persistFile;
    this.timer = null;
    this.botTimers = [];
    this._persistT = null;
    this.reset();
    if (persistFile) this._load();
  }

  /* ---------------------------------------------------------------- state */
  reset() {
    this._clearTimers();
    this.s = {
      phase: P.SETUP,
      code: genCode(this.kind === 'demo' ? 'DEMO' : 'AMPYR'),
      config: null, // snapshot at START_GAME
      questions: null, // snapshot at START_GAME
      qIndex: -1,
      players: {}, // id -> player
      joinOrder: [],
      deadline: null,
      paused: false,
      pausedRemaining: null,
      allowLateJoin: false,
      history: [],
      exits: [],
      exitPaidPaise: 0,
      final: null,
      startedAt: null,
      endedAt: null,
      endReason: null,
      startingPlayers: 0,
      dotOrder: [],
    };
    this.tokens = new Map();
    this._changed('reset');
  }

  get cfg() { return this.s.config || this.store.config; }
  get questions() { return this.s.questions || this.store.questions.slice(0, this.store.config.questionCount); }
  get qCount() { return this.s.config ? this.s.config.questionCount : this.store.config.questionCount; }
  get isFinal() { return this.s.qIndex === this.qCount - 1; }
  get currentQ() { return this.s.qIndex >= 0 ? this.questions[this.s.qIndex] : null; }
  get entry() { return this.s.history[this.s.qIndex] || null; }
  players() { return this.s.joinOrder.map((id) => this.s.players[id]).filter(Boolean); }
  active() { return this.players().filter((p) => p.status === 'active'); }

  timerFor(i) {
    const n = this.qCount;
    if (i === n - 1) return null;
    const q = this.questions[i];
    if (q && Number.isInteger(q.timer) && q.timer > 0) return q.timer;
    return i < 8 ? this.cfg.timerEarly : this.cfg.timerLate;
  }

  exitOfferAfter(qNumber) {
    if (qNumber === this.cfg.exitOneAfter) return this.cfg.exitOneAmount;
    if (qNumber === this.cfg.exitTwoAfter) return this.cfg.exitTwoAmount;
    return 0;
  }

  /** Demo rooms allow extra seats so real test phones can join alongside simulated players. */
  joinLimit() { return this.kind === 'demo' ? 200 : this.store.config.playerLimit; }

  validation() {
    return prize.validateGame(this.store.config, this.store.questions);
  }

  /* -------------------------------------------------------------- players */
  join({ name, dept }) {
    name = cleanText(name, 24);
    dept = cleanText(dept, 40);
    if (!name) return { ok: false, error: 'Enter your name.' };
    if (!dept) return { ok: false, error: 'Choose your department.' };
    const ph = this.s.phase;
    if (ph === P.SETUP) return { ok: false, error: 'The host has not opened the lobby yet. Try again in a moment.' };
    if (ph === P.GAME_COMPLETE) return { ok: false, error: 'This game has finished.' };
    if (ph !== P.LOBBY) {
      if (!this.s.allowLateJoin) return { ok: false, error: 'The game has already started and registration is closed.' };
      if (this.isFinal) return { ok: false, error: 'The final question is under way. Registration is closed.' };
    }
    const limit = this.joinLimit();
    if (this.players().length >= limit) return { ok: false, error: `The room is full (${limit} players).` };
    const nn = normName(name);
    if (this.players().some((p) => normName(p.name) === nn)) {
      return { ok: false, error: `"${name}" is already playing. Add your surname initial, e.g. "${name} K".` };
    }
    const p = this._newPlayer(name, dept, false);
    // A late joiner who arrives while a question is open may answer it.
    if (OPEN_PHASES.has(ph) && this.entry) this.entry.ids.push(p.id);
    this._changed('join');
    return { ok: true, playerId: p.id, token: p.token };
  }

  _newPlayer(name, dept, isBot) {
    const p = {
      id: randId(6), token: randId(16), name, dept, isBot,
      status: 'active', answers: {}, exitDecisions: {},
      eliminatedAt: null, eliminatedReason: null, exitedAfter: null,
      exitPayoutPaise: 0, prizePaise: 0, joinedAt: Date.now(),
      lateJoin: this.s.phase !== P.LOBBY,
    };
    this.s.players[p.id] = p;
    this.s.joinOrder.push(p.id);
    this.tokens.set(p.token, p.id);
    if (this.s.phase !== P.LOBBY && this.s.phase !== P.SETUP) this.s.dotOrder.push(p.id);
    return p;
  }

  byToken(token) {
    const id = this.tokens.get(String(token || ''));
    return id ? this.s.players[id] : null;
  }

  answer(playerId, option) {
    const p = this.s.players[playerId];
    if (!p) return { ok: false, error: 'Player not found.' };
    if (!OPEN_PHASES.has(this.s.phase)) return { ok: false, error: 'Answers are closed.' };
    if (this.s.paused) return { ok: false, error: 'The game is paused.' };
    if (p.status !== 'active') return { ok: false, error: 'You are no longer in the game.' };
    if (!OPTS.includes(option)) return { ok: false, error: 'Invalid option.' };
    const e = this.entry;
    if (!e || !e.ids.includes(p.id)) return { ok: false, error: 'You are not playing this question.' };
    if (p.answers[this.s.qIndex]) return { ok: false, error: 'Your answer is already locked.' };
    if (this.s.deadline && Date.now() > this.s.deadline + GRACE_MS) return { ok: false, error: "Time's up." };
    p.answers[this.s.qIndex] = option;
    this._changed('answer');
    return { ok: true };
  }

  decideExit(playerId, choice) {
    const p = this.s.players[playerId];
    if (!p) return { ok: false, error: 'Player not found.' };
    if (this.s.phase !== P.EXIT_DECISION) return { ok: false, error: 'There is no exit decision open.' };
    if (this.s.paused) return { ok: false, error: 'The game is paused.' };
    if (p.status !== 'active') return { ok: false, error: 'You are no longer in the game.' };
    if (!['exit', 'continue'].includes(choice)) return { ok: false, error: 'Invalid choice.' };
    const round = this.s.qIndex + 1;
    if (p.exitDecisions[round]) return { ok: false, error: 'Your decision is already locked.' };
    p.exitDecisions[round] = choice;
    this._changed('decision');
    return { ok: true };
  }

  /* ------------------------------------------------------------- host ops */
  action(type, payload = {}) {
    const s = this.s;
    const fail = (error) => ({ ok: false, error });
    const ph = s.phase;

    switch (type) {
      case 'OPEN_LOBBY': {
        if (ph !== P.SETUP) return fail('The lobby is already open.');
        const v = this.validation();
        if (v.errors.length) return fail('Fix the configuration first: ' + v.errors[0]);
        s.phase = P.LOBBY;
        s.allowLateJoin = false;
        break;
      }
      case 'BACK_TO_SETUP': {
        if (ph !== P.LOBBY) return fail('Only available from the lobby.');
        s.phase = P.SETUP;
        break;
      }
      case 'REMOVE_PLAYER': {
        if (ph !== P.LOBBY) return fail('Players can only be removed in the lobby.');
        const p = s.players[payload.playerId];
        if (!p) return fail('Player not found.');
        delete s.players[p.id];
        s.joinOrder = s.joinOrder.filter((id) => id !== p.id);
        this.tokens.delete(p.token);
        this.emit('kicked', p.id);
        break;
      }
      case 'SET_LATE_JOIN': {
        s.allowLateJoin = !!payload.value;
        break;
      }
      case 'START_GAME': {
        if (ph !== P.LOBBY) return fail('Open the lobby first.');
        const v = this.validation();
        if (v.errors.length) return fail('Fix the configuration first: ' + v.errors[0]);
        if (this.players().length < 1) return fail('At least one player must join before you start.');
        s.config = JSON.parse(JSON.stringify(this.store.config));
        s.questions = JSON.parse(JSON.stringify(this.store.questions.slice(0, s.config.questionCount)));
        s.startedAt = Date.now();
        s.startingPlayers = this.players().length;
        s.dotOrder = this._shuffle(this.players().map((p) => p.id));
        s.qIndex = 0;
        s.phase = P.QUESTION_READY;
        break;
      }
      case 'START_QUESTION': {
        if (ph !== P.QUESTION_READY) return fail('No question is ready to start.');
        const act = this.active();
        if (!act.length) return fail('No active players remain.');
        const secs = this.timerFor(s.qIndex);
        s.history[s.qIndex] = {
          qIndex: s.qIndex, number: s.qIndex + 1, timer: secs,
          ids: act.map((p) => p.id), activeAtStart: act.length,
          counts: null, correct: null, survived: null, eliminated: null,
          noAnswer: null, tricked: false, startedAt: Date.now(), lockedAt: null,
        };
        s.paused = false;
        s.pausedRemaining = null;
        if (secs) {
          s.deadline = Date.now() + secs * 1000;
          this._armTimer(secs * 1000);
          s.phase = P.QUESTION_OPEN;
        } else {
          s.deadline = null;
          s.phase = P.FINAL_QUESTION;
        }
        if (this.kind === 'demo') this._botsAnswer();
        break;
      }
      case 'LOCK_ANSWERS': {
        if (!OPEN_PHASES.has(ph)) return fail('No question is open.');
        this._lock(payload.reason || 'host');
        return { ok: true };
      }
      case 'SHOW_ROOM': {
        if (ph !== P.QUESTION_LOCKED) return fail('Lock the answers first.');
        s.phase = P.ROOM_DISTRIBUTION;
        break;
      }
      case 'REVEAL_ANSWER': {
        if (ph === P.QUESTION_LOCKED) s.phase = P.ROOM_DISTRIBUTION; // allow skipping the separate step
        else if (ph !== P.ROOM_DISTRIBUTION) return fail('Show the room first.');
        this._reveal();
        s.phase = P.ANSWER_REVEAL;
        break;
      }
      case 'SHOW_EXPLANATION': {
        if (![P.ANSWER_REVEAL, P.SURVIVOR_UPDATE].includes(ph)) return fail('Reveal the answer first.');
        s.phase = P.EXPLANATION;
        break;
      }
      case 'SHOW_SURVIVORS': {
        if (![P.ANSWER_REVEAL, P.EXPLANATION].includes(ph)) return fail('Reveal the answer first.');
        s.phase = P.SURVIVOR_UPDATE;
        break;
      }
      case 'SHOW_ACTIVE': {
        if (![P.SURVIVOR_UPDATE, P.EXPLANATION, P.EXIT_RESULT].includes(ph)) return fail('Show the survivors first.');
        if (this.isFinal) return fail('The game is over: show the winners instead.');
        if (!this.active().length) return fail('Nobody is left in the game.');
        s.activeListShown = s.activeListShown || {};
        s.activeListShown[s.qIndex] = true;
        s.phase = P.ACTIVE_LIST;
        break;
      }
      case 'OFFER_EXIT': {
        if (![P.SURVIVOR_UPDATE, P.ACTIVE_LIST].includes(ph)) return fail('Show the survivors first.');
        if (this.isFinal) return fail('There is no exit after the final question.');
        const amount = this.exitOfferAfter(s.qIndex + 1);
        if (!(amount > 0)) return fail(`There is no exit offer after question ${s.qIndex + 1}.`);
        if (s.exits.some((x) => x.afterQuestion === s.qIndex + 1)) return fail('This exit has already been offered.');
        if (!this.active().length) return fail('No active players to offer the exit to.');
        s.exits.push({
          afterQuestion: s.qIndex + 1, amountPaise: prize.toPaise(amount),
          offeredTo: this.active().map((p) => p.id), confirmed: false,
          exiters: [], perPlayerPaise: 0, totalPaise: 0, fundPaise: 0, capped: false,
        });
        s.phase = P.EXIT_DECISION;
        if (this.kind === 'demo') this._botsDecide();
        break;
      }
      case 'CONFIRM_EXIT': {
        if (ph !== P.EXIT_DECISION) return fail('No exit decision is open.');
        this._confirmExit();
        s.phase = P.EXIT_RESULT;
        break;
      }
      case 'NEXT_QUESTION': {
        if (![P.SURVIVOR_UPDATE, P.EXIT_RESULT, P.EXPLANATION, P.ACTIVE_LIST].includes(ph)) return fail('Finish this question first.');
        if (this.isFinal) return fail('That was the final question. Distribute the final prize.');
        const pending = this.exitOfferAfter(s.qIndex + 1) > 0 && !s.exits.some((x) => x.afterQuestion === s.qIndex + 1);
        if (pending && !payload.skipExit && this.active().length) {
          return fail(`Offer the exit after question ${s.qIndex + 1} first (or confirm skipping it).`);
        }
        if (!this.active().length) return fail('Nobody is left in the game. End the game to apply the no-winner rule.');
        s.qIndex += 1;
        s.phase = P.QUESTION_READY;
        break;
      }
      case 'DISTRIBUTE_FINAL': {
        const endEarly = !this.active().length && [P.SURVIVOR_UPDATE, P.EXIT_RESULT, P.EXPLANATION, P.ACTIVE_LIST].includes(ph);
        const finalDone = this.isFinal && [P.SURVIVOR_UPDATE, P.EXPLANATION, P.ANSWER_REVEAL].includes(ph);
        if (!endEarly && !finalDone) return fail('The final answer has not been revealed yet.');
        this._finalize('complete');
        break;
      }
      case 'PAUSE': {
        if (s.paused) return fail('Already paused.');
        if (ph === P.SETUP || ph === P.GAME_COMPLETE) return fail('Nothing to pause.');
        s.paused = true;
        if (s.deadline) {
          s.pausedRemaining = Math.max(0, s.deadline - Date.now());
          s.deadline = null;
          this._clearTimer();
        }
        this._clearBots();
        break;
      }
      case 'RESUME': {
        if (!s.paused) return fail('The game is not paused.');
        s.paused = false;
        if (s.pausedRemaining != null && ph === P.QUESTION_OPEN) {
          const rem = Math.max(3000, s.pausedRemaining);
          s.deadline = Date.now() + rem;
          this._armTimer(rem);
        }
        s.pausedRemaining = null;
        if (this.kind === 'demo') {
          if (OPEN_PHASES.has(ph)) this._botsAnswer();
          if (ph === P.EXIT_DECISION) this._botsDecide();
        }
        break;
      }
      case 'END_GAME': {
        if (ph === P.SETUP) return fail('No game is running.');
        if (ph === P.GAME_COMPLETE) return fail('The game has already ended.');
        this._finalize('ended_by_host');
        break;
      }
      case 'RESET_GAME': {
        const ids = this.players().map((p) => p.id);
        this.reset();
        ids.forEach((id) => this.emit('kicked', id));
        return { ok: true };
      }
      case 'ADD_BOTS': {
        if (this.kind !== 'demo') return fail('Simulated players are only available in demo mode.');
        if (ph !== P.LOBBY) return fail('Open the demo lobby first.');
        const n = Math.max(1, Math.min(150, Number(payload.count) || 40));
        const deps = this.store.config.departments;
        const existing = this.players().filter((p) => p.isBot).length;
        const add = Math.min(n, this.joinLimit() - this.players().length);
        if (add <= 0) return fail('The demo room is full (200).');
        for (let i = 0; i < add; i++) {
          const k = existing + i + 1;
          this._newPlayer(`DEMO PLAYER ${String(k).padStart(2, '0')}`, deps[k % deps.length], true);
        }
        break;
      }
      case 'REMOVE_BOTS': {
        if (this.kind !== 'demo' || ph !== P.LOBBY) return fail('Only available in the demo lobby.');
        for (const p of this.players().filter((x) => x.isBot)) {
          delete s.players[p.id];
          this.tokens.delete(p.token);
        }
        s.joinOrder = s.joinOrder.filter((id) => s.players[id]);
        break;
      }
      default:
        return fail('Unknown action: ' + type);
    }
    this._changed(type);
    return { ok: true };
  }

  /* ------------------------------------------------------------ internals */
  _lock(reason) {
    const s = this.s;
    const e = this.entry;
    this._clearTimer();
    this._clearBots();
    s.deadline = null;
    s.paused = false;
    s.pausedRemaining = null;
    const counts = { A: 0, B: 0, C: 0, D: 0, none: 0 };
    for (const id of e.ids) {
      const p = s.players[id];
      const a = p && p.answers[s.qIndex];
      if (a) counts[a] += 1; else counts.none += 1;
    }
    e.counts = counts;
    e.lockedAt = Date.now();
    e.lockReason = reason;
    s.phase = P.QUESTION_LOCKED;
    this._changed('lock');
  }

  _reveal() {
    const s = this.s;
    const e = this.entry;
    const q = this.currentQ;
    e.correct = q.correctAnswer;
    let survived = 0;
    let eliminated = 0;
    let noAnswer = 0;
    for (const id of e.ids) {
      const p = s.players[id];
      if (!p || p.status !== 'active') continue;
      const a = p.answers[s.qIndex];
      if (a === q.correctAnswer) { survived += 1; continue; }
      p.status = 'eliminated';
      p.eliminatedAt = s.qIndex + 1;
      p.eliminatedReason = a ? 'wrong' : 'no-answer';
      if (!a) noAnswer += 1;
      eliminated += 1;
    }
    e.survived = survived;
    e.eliminated = eliminated;
    e.noAnswer = noAnswer;
    // "The room got tricked": the most popular answer was wrong.
    const c = e.counts;
    const top = OPTS.reduce((best, o) => (c[o] > c[best] ? o : best), 'A');
    e.mostPopular = c[top] > 0 ? top : null;
    e.tricked = !!e.mostPopular && e.mostPopular !== q.correctAnswer && c[top] > c[q.correctAnswer];
  }

  _confirmExit() {
    const s = this.s;
    const round = s.qIndex + 1;
    const x = s.exits.find((r) => r.afterQuestion === round);
    const exiters = x.offeredTo
      .map((id) => s.players[id])
      .filter((p) => p && p.status === 'active' && p.exitDecisions[round] === 'exit');
    const undecided = x.offeredTo.map((id) => s.players[id]).filter((p) => p && p.status === 'active' && !p.exitDecisions[round]);
    undecided.forEach((p) => { p.exitDecisions[round] = 'continue'; p.exitDefaulted = true; });
    const remaining = prize.toPaise(s.config.totalPrize) - s.exitPaidPaise;
    const pay = prize.exitRoundPayout({
      remainingPaise: remaining, amountPaise: x.amountPaise,
      exiters: exiters.length, capPct: s.config.exitCapPct,
    });
    for (const p of exiters) {
      p.status = 'exited';
      p.exitedAfter = round;
      p.exitPayoutPaise = pay.perPlayerPaise;
    }
    Object.assign(x, {
      confirmed: true, exiters: exiters.map((p) => p.id), undecided: undecided.length,
      perPlayerPaise: pay.perPlayerPaise, totalPaise: pay.totalPaise, fundPaise: pay.fundPaise, capped: pay.capped,
    });
    s.exitPaidPaise += pay.totalPaise;
    this._clearBots();
  }

  _finalize(reason) {
    const s = this.s;
    this._clearTimers();
    if (s.config == null) { // ended before the game started
      s.config = JSON.parse(JSON.stringify(this.store.config));
      s.questions = JSON.parse(JSON.stringify(this.store.questions.slice(0, s.config.questionCount)));
    }
    const total = prize.toPaise(s.config.totalPrize);
    const pool = total - s.exitPaidPaise;
    const finished = reason === 'complete';
    const winners = finished && this.isFinal && s.history[s.qIndex] && s.history[s.qIndex].correct
      ? this.active() : [];
    const f = {
      reason, totalPaise: total, exitPaidPaise: s.exitPaidPaise, finalPoolPaise: pool,
      winners: winners.map((p) => p.id), mode: null, recipients: [],
      eachPaise: 0, residuePaise: 0, retainedPaise: 0,
    };
    if (winners.length) {
      const sp = prize.equalSplit(pool, winners.length);
      winners.forEach((p) => { p.prizePaise = sp.eachPaise; p.winner = true; });
      Object.assign(f, { mode: 'winners', recipients: f.winners, eachPaise: sp.eachPaise, residuePaise: sp.residuePaise });
    } else if (finished && s.config.noWinnerRule === 'split_last_standing') {
      const last = s.history.filter(Boolean).slice(-1)[0];
      const ids = last ? last.ids.filter((id) => s.players[id] && s.players[id].status !== 'exited') : [];
      if (ids.length) {
        const sp = prize.equalSplit(pool, ids.length);
        ids.forEach((id) => { s.players[id].prizePaise = sp.eachPaise; });
        Object.assign(f, { mode: 'last_standing', recipients: ids, lastQuestion: last.number, eachPaise: sp.eachPaise, residuePaise: sp.residuePaise });
      } else {
        Object.assign(f, { mode: 'retained', retainedPaise: pool });
      }
    } else {
      Object.assign(f, { mode: finished ? 'retained' : 'not_awarded', retainedPaise: pool });
    }
    // Reconciliation: never pay more than the configured prize.
    const paid = s.exitPaidPaise + f.eachPaise * f.recipients.length;
    f.paidPaise = paid;
    f.unpaidPaise = total - paid;
    f.reconciled = paid <= total && paid + f.residuePaise + f.retainedPaise === total;
    if (!f.reconciled) throw new Error('Prize reconciliation failed: payouts exceed or mismatch the pool.');
    s.final = f;
    s.endedAt = Date.now();
    s.endReason = reason;
    s.phase = P.GAME_COMPLETE;
  }

  _shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = crypto.randomInt(i + 1);
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  _armTimer(ms) {
    this._clearTimer();
    this.timer = setTimeout(() => {
      this.timer = null;
      if (this.s.phase === P.QUESTION_OPEN && !this.s.paused) this._lock('timeup');
    }, ms + GRACE_MS);
  }
  _clearTimer() { if (this.timer) clearTimeout(this.timer); this.timer = null; }
  _clearBots() { this.botTimers.forEach(clearTimeout); this.botTimers = []; }
  _clearTimers() { this._clearTimer(); this._clearBots(); }

  /* ------------------------------------------------------- demo players */
  _botsAnswer() {
    this._clearBots();
    const q = this.currentQ;
    const e = this.entry;
    const secs = this.timerFor(this.s.qIndex);
    const remainingMs = this.s.deadline ? this.s.deadline - Date.now() : 18000;
    const window = Math.max(1500, Math.min(remainingMs - 1500, (secs || 18) * 1000 * 0.8));
    const acc = DIFFICULTY_ACCURACY[String(q.difficulty || '').toLowerCase()] ?? 0.6;
    for (const id of e.ids) {
      const p = this.s.players[id];
      if (!p || !p.isBot || p.status !== 'active' || p.answers[this.s.qIndex]) continue;
      if (Math.random() < 0.02 && secs) continue; // the odd demo player forgets to answer
      let pick = q.correctAnswer;
      if (Math.random() > acc) {
        const wrong = OPTS.filter((o) => o !== q.correctAnswer);
        pick = q.trapAnswer && q.trapAnswer !== q.correctAnswer && Math.random() < 0.75
          ? q.trapAnswer : wrong[crypto.randomInt(wrong.length)];
      }
      const t = setTimeout(() => this.answer(id, pick), 600 + Math.random() * window);
      this.botTimers.push(t);
    }
  }

  _botsDecide() {
    this._clearBots();
    const round = this.s.qIndex + 1;
    const pExit = round === this.cfg.exitOneAfter ? 0.12 : 0.2;
    for (const p of this.active()) {
      if (!p.isBot || p.exitDecisions[round]) continue;
      const choice = Math.random() < pExit ? 'exit' : 'continue';
      this.botTimers.push(setTimeout(() => this.decideExit(p.id, choice), 500 + Math.random() * 5000));
    }
  }

  /* ---------------------------------------------------------- persistence */
  _changed(reason) {
    this.emit('change', reason);
    if (this.persistFile) {
      clearTimeout(this._persistT);
      this._persistT = setTimeout(() => this._save(), 150);
    }
  }

  _save() {
    try {
      writeAtomic(this.persistFile, { savedAt: Date.now(), s: this.s });
    } catch (err) {
      console.error('Could not save game state:', err.message);
    }
  }

  _load() {
    const saved = readJSON(this.persistFile, null);
    if (!saved || !saved.s || !saved.s.phase) return;
    this.s = saved.s;
    this.tokens = new Map(Object.values(this.s.players).map((p) => [p.token, p.id]));
    if (OPEN_PHASES.has(this.s.phase) && this.s.deadline) {
      // Server restarted mid-question: pause with the time that was left.
      this.s.pausedRemaining = Math.max(5000, this.s.deadline - saved.savedAt);
      this.s.deadline = null;
      this.s.paused = true;
    }
    console.log(`Restored live game ${this.s.code} (phase ${this.s.phase}, ${this.players().length} players).`);
  }

  /* --------------------------------------------------------------- views */
  _questionPublic(withAnswer) {
    const q = this.currentQ;
    if (!q) return null;
    const out = {
      number: this.s.qIndex + 1, text: q.question,
      options: { A: q.optionA, B: q.optionB, C: q.optionC, D: q.optionD },
      category: q.category, difficulty: q.difficulty,
    };
    if (withAnswer) {
      out.correct = q.correctAnswer;
      out.explanation = q.explanation;
    }
    return out;
  }

  _distribution() {
    const e = this.entry;
    if (!e || !e.counts) return null;
    const answered = OPTS.reduce((n, o) => n + e.counts[o], 0);
    const pct = {};
    OPTS.forEach((o) => { pct[o] = answered ? Math.round((e.counts[o] / answered) * 100) : 0; });
    return { pct, answered, noAnswer: e.counts.none, total: e.ids.length };
  }

  _common() {
    const s = this.s;
    const ph = s.phase;
    const showQ = QUESTION_VISIBLE.has(ph);
    const revealed = REVEALED.has(ph);
    const e = this.entry;
    const answeredCount = e && OPEN_PHASES.has(ph)
      ? e.ids.filter((id) => s.players[id] && s.players[id].answers[s.qIndex]).length : null;
    const exitRound = s.exits.find((x) => x.afterQuestion === s.qIndex + 1) || null;
    return {
      kind: this.kind,
      code: s.code,
      gameName: this.cfg.gameName,
      tagline: this.cfg.tagline,
      phase: ph,
      paused: s.paused,
      serverNow: Date.now(),
      qIndex: s.qIndex,
      qNumber: s.qIndex + 1,
      qTotal: this.qCount,
      isFinal: s.qIndex >= 0 && this.isFinal,
      timerSecs: s.qIndex >= 0 ? this.timerFor(s.qIndex) : null,
      deadline: s.deadline,
      pausedRemaining: s.pausedRemaining,
      question: showQ ? this._questionPublic(revealed) : null,
      distribution: DIST_VISIBLE.has(ph) ? this._distribution() : null,
      result: revealed && e ? {
        correct: e.correct, survived: e.survived, eliminated: e.eliminated,
        activeAtStart: e.activeAtStart, tricked: e.tricked, noAnswer: e.noAnswer,
      } : null,
      lockReason: e && e.lockReason,
      remaining: this.active().length,
      joined: this.players().length,
      answered: answeredCount,
      answering: e && OPEN_PHASES.has(ph) ? e.ids.filter((id) => s.players[id]?.status === 'active').length : null,
      exitOffer: ph === P.EXIT_DECISION || ph === P.EXIT_RESULT ? exitRound && {
        afterQuestion: exitRound.afterQuestion, amountPaise: exitRound.amountPaise,
        offered: exitRound.offeredTo.length,
        decided: exitRound.offeredTo.filter((id) => s.players[id]?.exitDecisions[exitRound.afterQuestion]).length,
        confirmed: exitRound.confirmed,
      } : null,
      allowLateJoin: s.allowLateJoin,
      complete: ph === P.GAME_COMPLETE ? {
        reason: s.final.reason, mode: s.final.mode,
        winners: s.final.winners.map((id) => s.players[id]?.name).filter(Boolean),
        finalPoolPaise: s.final.finalPoolPaise,
        eachPaise: s.final.eachPaise,
        recipients: s.final.recipients.length,
        lastQuestion: s.final.lastQuestion || null,
        noWinnerRule: s.config.noWinnerRule,
      } : null,
    };
  }

  playerView(p) {
    const c = this._common();
    const s = this.s;
    const e = this.entry;
    const inQ = !!(e && e.ids.includes(p.id));
    const myAnswer = s.qIndex >= 0 ? p.answers[s.qIndex] || null : null;
    const view = {
      ...c,
      me: {
        id: p.id, name: p.name, dept: p.dept, status: p.status,
        eliminatedAt: p.eliminatedAt, eliminatedReason: p.eliminatedReason,
        exitedAfter: p.exitedAfter, winner: !!p.winner,
        inQuestion: inQ, answer: inQ ? myAnswer : null,
        exitDecision: s.qIndex >= 0 ? p.exitDecisions[s.qIndex + 1] || null : null,
      },
    };
    if (c.result && inQ) {
      view.me.result = myAnswer === c.result.correct ? 'correct' : myAnswer ? 'wrong' : 'no-answer';
    }
    // The exit offer and its rules are only meaningful to players it was offered to.
    if (c.exitOffer) {
      const x = s.exits.find((r) => r.afterQuestion === c.exitOffer.afterQuestion);
      view.exitOffer = x.offeredTo.includes(p.id) ? { afterQuestion: x.afterQuestion, amountPaise: x.amountPaise, capPct: s.config.exitCapPct, confirmed: x.confirmed } : null;
    }
    delete view.joined;
    delete view.answering;
    if (view.complete) view.complete = { reason: view.complete.reason, mode: view.complete.mode, winners: view.complete.winners };
    if (s.phase !== P.LOBBY) delete view.allowLateJoin;
    return view;
  }

  hostView() {
    const s = this.s;
    const c = this._common();
    const editable = s.phase === P.SETUP || s.phase === P.LOBBY;
    const e = this.entry;
    const totalPaise = prize.toPaise(this.cfg.totalPrize);
    return {
      ...c,
      validation: editable ? this.validation() : null,
      store: editable ? { config: this.store.config, questions: this.store.questions } : null,
      players: this.players().map((p) => ({
        id: p.id, name: p.name, dept: p.dept, status: p.status, isBot: p.isBot,
      })),
      dots: (s.dotOrder.length ? s.dotOrder : s.joinOrder).map((id) => {
        const p = s.players[id];
        return p ? (p.status === 'active' ? 1 : p.status === 'exited' ? 2 : 0) : 0;
      }),
      startingPlayers: s.startingPlayers,
      // Who has answered the final question (host private panel only).
      finalThinking: s.phase === P.FINAL_QUESTION && e ? e.ids.map((id) => s.players[id]).filter((p) => p && p.status === 'active')
        .map((p) => ({ name: p.name, answered: !!p.answers[s.qIndex] })) : null,
      prize: {
        totalPaise, exitPaidPaise: s.exitPaidPaise, poolPaise: totalPaise - s.exitPaidPaise,
        exitCapPct: this.cfg.exitCapPct,
        nextExit: (() => {
          const n = s.qIndex + 1;
          const amt = this.exitOfferAfter(n);
          return amt > 0 && !s.exits.some((x) => x.afterQuestion === n) ? { afterQuestion: n, amountPaise: prize.toPaise(amt) } : null;
        })(),
      },
      exitResult: s.phase === P.EXIT_RESULT ? (() => {
        const x = s.exits.find((r) => r.afterQuestion === s.qIndex + 1);
        return x && { exited: x.exiters.length, perPlayerPaise: x.perPlayerPaise, totalPaise: x.totalPaise, capped: x.capped, undecided: x.undecided };
      })() : null,
      results: s.phase === P.GAME_COMPLETE ? this.results() : null,
      revealCorrect: REVEALED.has(s.phase) && this.currentQ ? this.currentQ.correctAnswer : null,
      activeNames: s.phase === P.ACTIVE_LIST ? this.active().map((p) => p.name).sort((x, y) => x.localeCompare(y, 'en', { sensitivity: 'base' })) : null,
      activeListDue: (() => {
        const every = this.cfg.showActiveEvery;
        return !!every && s.qIndex >= 0 && !this.isFinal && (s.qIndex + 1) % every === 0
          && !(s.activeListShown && s.activeListShown[s.qIndex]) && this.active().length > 0;
      })(),
    };
  }

  /** Detailed analytics, host only. */
  results() {
    const s = this.s;
    if (!s.config) return null;
    const qs = s.questions;
    return {
      totalPlayers: this.players().length,
      startingPlayers: s.startingPlayers,
      questions: s.history.filter(Boolean).map((e) => {
        const answered = e.counts ? OPTS.reduce((n, o) => n + e.counts[o], 0) : 0;
        return {
          number: e.number, text: qs[e.qIndex].question, category: qs[e.qIndex].category,
          correct: qs[e.qIndex].correctAnswer, activeAtStart: e.activeAtStart,
          counts: e.counts, answered, survived: e.survived, eliminated: e.eliminated,
          noAnswer: e.noAnswer, tricked: e.tricked,
          correctPct: e.activeAtStart && e.survived != null ? Math.round((e.survived / e.activeAtStart) * 100) : null,
        };
      }),
      exits: s.exits.map((x) => ({
        afterQuestion: x.afterQuestion, offered: x.offeredTo.length, exited: x.exiters.length,
        amountPaise: x.amountPaise, perPlayerPaise: x.perPlayerPaise, totalPaise: x.totalPaise,
        fundPaise: x.fundPaise, capped: x.capped, names: x.exiters.map((id) => s.players[id]?.name),
      })),
      exitPoints: [s.config.exitOneAfter, s.config.exitTwoAfter].filter((a, i) => (i ? s.config.exitTwoAmount : s.config.exitOneAmount) > 0),
      reachedFinal: s.history[s.questions.length - 1] ? s.history[s.questions.length - 1].activeAtStart : 0,
      finalCorrect: s.history[s.questions.length - 1] ? s.history[s.questions.length - 1].survived : 0,
      final: s.final && {
        ...s.final,
        winnerNames: s.final.winners.map((id) => s.players[id]?.name),
        recipientNames: s.final.recipients.map((id) => s.players[id]?.name),
      },
      payouts: this.players().filter((p) => p.exitPayoutPaise || p.prizePaise).map((p) => ({
        name: p.name, dept: p.dept, type: p.exitedAfter ? `Exit after Q${p.exitedAfter}` : p.winner ? 'Final winner' : 'No-winner rule share',
        amountPaise: p.exitPayoutPaise || p.prizePaise, isBot: p.isBot,
      })),
      players: this.players().map((p) => ({
        name: p.name, dept: p.dept, status: p.winner ? 'winner' : p.status,
        eliminatedAt: p.eliminatedAt, exitedAfter: p.exitedAfter, isBot: p.isBot,
      })),
    };
  }
}

module.exports = { GameRoom, P, OPTS };
