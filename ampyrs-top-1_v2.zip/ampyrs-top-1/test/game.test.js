'use strict';
const test = require('node:test');
const assert = require('node:assert');
const os = require('os');
const fs = require('fs');
const path = require('path');
const { Store } = require('../src/store');
const { GameRoom } = require('../src/game');
const prize = require('../src/prize');

function freshStore() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 't1-'));
  fs.copyFileSync(path.join(__dirname, '..', 'data', 'questions.default.json'), path.join(dir, 'questions.default.json'));
  return new Store(dir);
}

function must(r) { assert.ok(r.ok, r.error); return r; }

test('default configuration is valid, with honest warnings', () => {
  const st = freshStore();
  const v = prize.validateGame(st.config, st.questions);
  assert.deepStrictEqual(v.errors, []);
  assert.ok(v.warnings.some((w) => w.includes('After Q10, up to 5 players can exit with the full ₹1,000')));
  assert.ok(!v.warnings.some((w) => w.includes('worth less')), 'later exit is worth more by default');
});

test('invalid prize configurations are blocked', () => {
  const st = freshStore();
  const bad = prize.validateGame({ ...st.config, exitOneAmount: 6000, exitTwoAmount: 5000 }, st.questions);
  assert.ok(bad.errors.length > 0);
  const tooFew = prize.validateGame(st.config, st.questions.slice(0, 10));
  assert.ok(tooFew.errors.some((e) => e.includes('needs 13 questions')));
  const dupOpt = st.questions.map((q) => ({ ...q }));
  dupOpt[0].optionB = dupOpt[0].optionA;
  assert.ok(prize.validateGame(st.config, dupOpt).errors.some((e) => e.includes('identical')));
});

test('exit fund is shared and never exceeds the pool', () => {
  const r = prize.exitRoundPayout({ remainingPaise: 1000000, amountPaise: 200000, exiters: 10, capPct: 50 });
  assert.strictEqual(r.capped, true);
  assert.strictEqual(r.perPlayerPaise, 50000);
  assert.ok(r.totalPaise <= 500000);
  const ok = prize.exitRoundPayout({ remainingPaise: 1000000, amountPaise: 200000, exiters: 2, capPct: 50 });
  assert.strictEqual(ok.perPlayerPaise, 200000);
  const split = prize.equalSplit(800000, 3);
  assert.strictEqual(split.eachPaise, 266666);
  assert.strictEqual(split.eachPaise * 3 + split.residuePaise, 800000);
});

test('full game: eliminations, both exits, final split, reconciliation', () => {
  const st = freshStore();
  // Engine test with early exit points, so both exits happen while many players remain.
  st.saveConfig({ exitOneAfter: 2, exitOneAmount: 2000, exitTwoAfter: 5, exitTwoAmount: 1000 });
  const g = new GameRoom({ kind: 'live', store: st });
  must(g.action('OPEN_LOBBY'));
  const ids = [];
  for (let i = 0; i < 40; i++) ids.push(must(g.join({ name: `Player ${i}`, dept: 'Finance' })).playerId);
  assert.strictEqual(g.join({ name: 'player 0', dept: 'HR' }).ok, false, 'duplicate names rejected');
  assert.strictEqual(g.join({ name: 'Overflow', dept: 'HR' }).ok, false, 'player limit enforced');
  must(g.action('START_GAME'));
  assert.strictEqual(g.join({ name: 'Late', dept: 'HR' }).ok, false, 'registration locked');

  const qs = st.questions;
  const wrong = (q) => ['A', 'B', 'C', 'D'].find((o) => o !== q.correctAnswer);
  const play = (qi, wrongIds, silentIds = []) => {
    must(g.action('START_QUESTION'));
    // Correct answer must not leak before the reveal.
    const pv = g.playerView(g.s.players[ids[0]]);
    assert.strictEqual(pv.question.correct, undefined);
    for (const id of ids) {
      const p = g.s.players[id];
      if (p.status !== 'active' || silentIds.includes(id)) continue;
      must(g.answer(id, wrongIds.includes(id) ? wrong(qs[qi]) : qs[qi].correctAnswer));
      assert.strictEqual(g.answer(id, 'A').ok, false, 'no double answers');
    }
    must(g.action('LOCK_ANSWERS'));
    must(g.action('SHOW_ROOM'));
    must(g.action('REVEAL_ANSWER'));
    must(g.action('SHOW_SURVIVORS'));
  };

  play(0, ids.slice(0, 4), [ids[4]]); // 4 wrong + 1 no answer
  assert.strictEqual(g.active().length, 35);
  assert.strictEqual(g.s.players[ids[4]].eliminatedReason, 'no-answer');
  assert.strictEqual(g.answer(ids[0], 'A').ok, false, 'eliminated players cannot answer');
  must(g.action('NEXT_QUESTION'));

  play(1, ids.slice(5, 25)); // 20 wrong: majority wrong → tricked
  assert.strictEqual(g.history ? 0 : 0, 0);
  assert.strictEqual(g.s.history[1].tricked, true);
  assert.strictEqual(g.active().length, 15);
  assert.strictEqual(g.action('NEXT_QUESTION').ok, false, 'exit must be offered first');
  must(g.action('OFFER_EXIT'));
  // 3 exit after Q2 at ₹2,000: fund = ₹5,000 → shared at ₹1,666.66
  for (const id of ids.slice(25, 28)) must(g.decideExit(id, 'exit'));
  assert.strictEqual(g.decideExit(ids[25], 'continue').ok, false, 'decision is final');
  must(g.action('CONFIRM_EXIT'));
  assert.strictEqual(g.s.exits[0].capped, true);
  assert.strictEqual(g.s.exits[0].perPlayerPaise, 166666);
  assert.strictEqual(g.active().length, 12);
  assert.strictEqual(g.playerView(g.s.players[ids[26]]).me.status, 'exited');
  must(g.action('NEXT_QUESTION'));

  play(2, []); must(g.action('NEXT_QUESTION'));
  play(3, [ids[28]]); must(g.action('NEXT_QUESTION'));
  play(4, []);
  must(g.action('OFFER_EXIT'));
  must(g.decideExit(ids[29], 'exit'));
  must(g.action('CONFIRM_EXIT'));
  assert.strictEqual(g.s.exits[1].perPlayerPaise, 100000);
  must(g.action('NEXT_QUESTION'));

  for (let qi = 5; qi < 12; qi++) {
    play(qi, qi === 8 ? [ids[30], ids[31]] : []);
    must(g.action('NEXT_QUESTION'));
  }
  assert.strictEqual(g.s.phase, 'QUESTION_READY');
  must(g.action('START_QUESTION'));
  assert.strictEqual(g.s.phase, 'FINAL_QUESTION');
  assert.strictEqual(g.s.deadline, null, 'final question has no timer');
  const finalists = g.active().map((p) => p.id);
  finalists.forEach((id, i) => must(g.answer(id, i < 3 ? qs[12].correctAnswer : wrong(qs[12]))));
  must(g.action('LOCK_ANSWERS'));
  must(g.action('REVEAL_ANSWER'));
  must(g.action('SHOW_SURVIVORS'));
  must(g.action('DISTRIBUTE_FINAL'));
  const f = g.s.final;
  assert.strictEqual(g.s.phase, 'GAME_COMPLETE');
  assert.strictEqual(f.mode, 'winners');
  assert.strictEqual(f.winners.length, 3);
  const expectedPool = 1000000 - 3 * 166666 - 100000;
  assert.strictEqual(f.finalPoolPaise, expectedPool);
  assert.ok(f.reconciled);
  assert.ok(f.paidPaise <= 1000000);
  const r = g.results();
  assert.strictEqual(r.reachedFinal, finalists.length);
  assert.strictEqual(r.finalCorrect, 3);
  // Player views never contain money.
  const view = JSON.stringify(g.playerView(g.s.players[ids[26]]));
  assert.ok(!/prizePaise|exitPayoutPaise/.test(view));
});

test('no winner: split among last standing, or retained', () => {
  for (const rule of ['split_last_standing', 'retained']) {
    const st = freshStore();
    st.saveConfig({ noWinnerRule: rule, questionCount: 6, exitOneAfter: 2, exitTwoAfter: 4 });
    const g = new GameRoom({ kind: 'live', store: st });
    must(g.action('OPEN_LOBBY'));
    const a = must(g.join({ name: 'A', dept: 'X' })).playerId;
    const b = must(g.join({ name: 'B', dept: 'X' })).playerId;
    must(g.action('START_GAME'));
    must(g.action('START_QUESTION'));
    // Nobody answers → both eliminated at Q1 by timeout-equivalent lock.
    must(g.action('LOCK_ANSWERS'));
    must(g.action('REVEAL_ANSWER'));
    must(g.action('SHOW_SURVIVORS'));
    assert.strictEqual(g.active().length, 0);
    must(g.action('DISTRIBUTE_FINAL'));
    const f = g.s.final;
    assert.deepStrictEqual(Object.keys(g.playerView(g.s.players[a]).complete).sort(), ['mode', 'reason', 'winners'], 'phones get no prize-distribution details');
    if (rule === 'retained') assert.strictEqual(f.retainedPaise, 1000000);
    else { assert.strictEqual(f.mode, 'last_standing'); assert.strictEqual(f.eachPaise, 500000); assert.deepStrictEqual(f.recipients.sort(), [a, b].sort()); }
    assert.ok(f.reconciled);
  }
});

test('pause stops the clock and blocks answers; resume restores time', () => {
  const st = freshStore();
  const g = new GameRoom({ kind: 'live', store: st });
  must(g.action('OPEN_LOBBY'));
  const a = must(g.join({ name: 'A', dept: 'X' })).playerId;
  must(g.action('START_GAME'));
  must(g.action('START_QUESTION'));
  must(g.action('PAUSE'));
  assert.ok(g.s.pausedRemaining > 25000);
  assert.strictEqual(g.answer(a, 'B').ok, false);
  must(g.action('RESUME'));
  assert.ok(g.s.deadline > Date.now() + 25000);
  must(g.answer(a, 'B'));
  g._clearTimers();
});

test('timer auto-locks a question and treats silence as wrong', async () => {
  const st = freshStore();
  st.saveConfig({ timerEarly: 5 });
  const g = new GameRoom({ kind: 'live', store: st });
  must(g.action('OPEN_LOBBY'));
  must(g.join({ name: 'A', dept: 'X' }));
  must(g.action('START_GAME'));
  must(g.action('START_QUESTION'));
  await new Promise((r) => setTimeout(r, 5600));
  assert.strictEqual(g.s.phase, 'QUESTION_LOCKED');
  assert.strictEqual(g.entry.lockReason, 'timeup');
  must(g.action('REVEAL_ANSWER'));
  assert.strictEqual(g.active().length, 0);
});

test('demo mode bots play a whole game and end cleanly', async () => {
  const st = freshStore();
  st.saveConfig({ timerEarly: 5, timerLate: 5, playerLimit: 100 });
  const g = new GameRoom({ kind: 'demo', store: st });
  must(g.action('OPEN_LOBBY'));
  must(g.action('ADD_BOTS', { count: 60 }));
  assert.strictEqual(g.players().length, 60);
  assert.ok(g.players().every((p) => p.name.startsWith('DEMO PLAYER')));
  must(g.action('START_GAME'));
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  for (let qi = 0; qi < 13; qi++) {
    if (!g.active().length) break;
    must(g.action('START_QUESTION'));
    await wait(qi === 12 ? 16000 : 5700);
    if (g.s.phase !== 'QUESTION_LOCKED') must(g.action('LOCK_ANSWERS'));
    must(g.action('REVEAL_ANSWER'));
    must(g.action('SHOW_SURVIVORS'));
    if (qi === 12) break;
    if ((qi === 9 || qi === 11) && g.active().length) {
      must(g.action('OFFER_EXIT'));
      await wait(5800);
      must(g.action('CONFIRM_EXIT'));
    }
    if (!g.active().length) break;
    must(g.action('NEXT_QUESTION'));
  }
  must(g.action('DISTRIBUTE_FINAL'));
  assert.strictEqual(g.s.phase, 'GAME_COMPLETE');
  assert.ok(g.s.final.reconciled);
  console.log('    demo result:', g.s.final.mode, 'winners', g.s.final.winners.length,
    'survivors per Q', g.s.history.filter(Boolean).map((e) => e.survived).join(','));
});

test('default exits: ₹1,000 after Q10 and ₹2,000 after Q12 (just before the final)', () => {
  const st = freshStore();
  assert.strictEqual(st.config.exitOneAfter, 10);
  assert.strictEqual(st.config.exitOneAmount, 1000);
  assert.strictEqual(st.config.exitTwoAfter, 12);
  assert.strictEqual(st.config.exitTwoAmount, 2000);
  const g = new GameRoom({ kind: 'live', store: st });
  must(g.action('OPEN_LOBBY'));
  const ids = [];
  for (let i = 0; i < 20; i++) ids.push(must(g.join({ name: `P${i}`, dept: 'X' })).playerId);
  must(g.action('START_GAME'));
  const offers = [];
  for (let qi = 0; qi < 12; qi++) {
    must(g.action('START_QUESTION'));
    ids.forEach((id) => { if (g.s.players[id].status === 'active') must(g.answer(id, st.questions[qi].correctAnswer)); });
    must(g.action('LOCK_ANSWERS')); must(g.action('REVEAL_ANSWER')); must(g.action('SHOW_SURVIVORS'));
    const r = g.action('OFFER_EXIT');
    if (r.ok) {
      offers.push([qi + 1, g.s.exits.slice(-1)[0].amountPaise / 100]);
      const exiter = ids.find((id) => g.s.players[id].status === 'active');
      must(g.decideExit(exiter, 'exit'));
      must(g.action('CONFIRM_EXIT'));
    }
    must(g.action('NEXT_QUESTION'));
  }
  assert.deepStrictEqual(offers, [[10, 1000], [12, 2000]]);
  assert.strictEqual(g.s.phase, 'QUESTION_READY');
  assert.ok(g.isFinal, 'the ₹2,000 exit comes immediately before the final question');
  assert.strictEqual(g.s.exitPaidPaise, 300000);
  assert.deepStrictEqual(g.results().exitPoints, [10, 12]);
});

test('exit positions are validated', () => {
  const st = freshStore();
  const v1 = prize.validateGame({ ...st.config, exitOneAfter: 12, exitTwoAfter: 10 }, st.questions);
  assert.ok(v1.errors.some((e) => e.includes('must come before')));
  const v2 = prize.validateGame({ ...st.config, exitTwoAfter: 13 }, st.questions);
  assert.ok(v2.errors.some((e) => e.includes('no exit after the final')));
});

test('players still in the game are listed after every 3rd question', () => {
  const st = freshStore();
  const g = new GameRoom({ kind: 'live', store: st });
  must(g.action('OPEN_LOBBY'));
  const ids = [];
  for (let i = 0; i < 16; i++) ids.push(must(g.join({ name: `Name ${String.fromCharCode(80 - i)}`, dept: 'X' })).playerId);
  must(g.action('START_GAME'));
  const shownAfter = [];
  for (let qi = 0; qi < 12; qi++) {
    must(g.action('START_QUESTION'));
    // One player goes out on every question.
    const act = ids.filter((id) => g.s.players[id].status === 'active');
    act.forEach((id, k) => must(g.answer(id, k === 0 ? (st.questions[qi].correctAnswer === 'A' ? 'B' : 'A') : st.questions[qi].correctAnswer)));
    must(g.action('LOCK_ANSWERS')); must(g.action('REVEAL_ANSWER')); must(g.action('SHOW_SURVIVORS'));
    const hv = g.hostView();
    if (hv.activeListDue) {
      must(g.action('SHOW_ACTIVE'));
      const v = g.hostView();
      assert.strictEqual(v.phase, 'ACTIVE_LIST');
      assert.strictEqual(v.activeNames.length, g.active().length);
      assert.deepStrictEqual(v.activeNames, [...v.activeNames].sort(), 'alphabetical, not a ranking');
      const pv = g.playerView(g.active()[0]);
      assert.strictEqual(pv.activeNames, undefined, 'phones never receive other names');
      assert.strictEqual(g.hostView().activeListDue, false);
      shownAfter.push(qi + 1);
    }
    if (g.action('OFFER_EXIT').ok) must(g.action('CONFIRM_EXIT'));
    must(g.action('NEXT_QUESTION'));
  }
  assert.deepStrictEqual(shownAfter, [3, 6, 9, 12]);
});
